//! OfferMate 导入服务 - HTTP 服务器
//!
//! 在 localhost:9420 启动轻量 HTTP 服务，接收浏览器扩展抓取的岗位信息。
//! 接口：
//!   - POST /api/import  接收 JSON 岗位数据，写入数据库
//!   - GET  /api/health  返回连接状态（供扩展探活）

use std::io::{BufRead, BufReader, Read, Write};
use tauri::{AppHandle, Emitter, Manager};
use sqlx::SqlitePool;
use uuid::Uuid;

const PORT: u16 = 9420;

#[derive(serde::Deserialize, serde::Serialize, Debug, Clone)]
#[allow(dead_code)]
pub struct JobPayload {
    pub company: Option<String>,
    pub position: Option<String>,
    pub salary: Option<String>,
    pub location: Option<String>,
    pub description: Option<String>,
    pub source: Option<String>,
    pub url: Option<String>,
    pub posted_at: Option<String>,
    pub is_remote: Option<bool>,
    pub requirements: Option<String>,
}

static STARTED: std::sync::Once = std::sync::Once::new();

/// 同步 Tauri command - 供前端手动调用启动
#[tauri::command]
pub fn start_import_server(_app: AppHandle) -> Result<(), String> {
    Ok(()) // 服务器已在 setup 中自动启动
}

/// 异步启动导入 HTTP 服务器（在 setup 中调用）
pub async fn start_import_server_async(app: AppHandle) -> Result<(), String> {
    let mut started = false;
    STARTED.call_once(|| { started = true; });

    if !started {
        return Ok(()); // 已启动过
    }

    let listener = std::net::TcpListener::bind(format!("127.0.0.1:{}", PORT))
        .map_err(|e| format!("无法绑定端口 {}: {}", PORT, e))?;
    listener.set_nonblocking(true)
        .map_err(|e| format!("设置非阻塞失败: {}", e))?;

    println!("[OfferMate] 导入服务已启动：http://localhost:{}", PORT);

    let app_handle = app.clone();
    std::thread::spawn(move || {
        loop {
            match listener.accept() {
                Ok((stream, _)) => {
                    let handle = app_handle.clone();
                    std::thread::spawn(move || {
                        let _ = handle_connection_sync(stream, handle);
                    });
                }
                Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    std::thread::sleep(std::time::Duration::from_millis(50));
                }
                Err(e) => {
                    eprintln!("[OfferMate] 接受连接失败: {}", e);
                    std::thread::sleep(std::time::Duration::from_millis(100));
                }
            }
        }
    });

    Ok(())
}

/// 同步处理单个 HTTP 请求
fn handle_connection_sync(
    mut stream: std::net::TcpStream,
    app: AppHandle,
) -> Result<(), String> {
    let mut reader = BufReader::new(stream.try_clone().map_err(|e| e.to_string())?);

    let mut request_line = String::new();
    reader.read_line(&mut request_line).map_err(|e| format!("读取请求行失败: {}", e))?;

    let parts: Vec<&str> = request_line.trim().split_whitespace().collect();
    if parts.len() < 3 {
        send_response(&mut stream, 400, "Bad Request", "{\"error\":\"invalid request\"}")?;
        return Ok(());
    }

    let method = parts[0];
    let path = parts[1];

    let mut content_length: usize = 0;
    loop {
        let mut line = String::new();
        reader.read_line(&mut line).map_err(|e| format!("读取请求头失败: {}", e))?;
        if line == "\r\n" || line.is_empty() { break; }
        let lower = line.to_lowercase();
        if lower.starts_with("content-length:") {
            content_length = lower.trim_start_matches("content-length:").trim().parse().unwrap_or(0);
        }
    }

    let mut body = vec![0u8; content_length];
    if content_length > 0 {
        reader.read_exact(&mut body).map_err(|e| format!("读取请求体失败: {}", e))?;
    }
    let body_str = String::from_utf8_lossy(&body).to_string();

    match (method, path) {
        ("GET", "/api/health") => {
            let resp = serde_json::json!({
                "status": "ok",
                "service": "OfferMate",
                "version": "1.0.0"
            });
            send_response(&mut stream, 200, "OK", &resp.to_string())?;
        }

        ("POST", "/api/import") => {
            match serde_json::from_str::<JobPayload>(&body_str) {
                Ok(payload) => {
                    let payload_clone = payload.clone();
                    let app_clone = app.clone();
                    let result = tauri::async_runtime::block_on(async move {
                        persist_job(&app_clone, &payload).await
                    });

                    match result {
                        Ok(job_id) => {
                            let resp = serde_json::json!({
                                "success": true,
                                "message": "导入成功",
                                "jobId": job_id
                            });
                            let _ = app.emit("offermate://job-imported", &payload_clone);
                            send_response(&mut stream, 200, "OK", &resp.to_string())?;
                        }
                        Err((status, msg)) => {
                            eprintln!("[OfferMate] 导入失败 ({}): {}", status, msg);
                            let resp = serde_json::json!({
                                "success": false,
                                "message": msg
                            });
                            let status_text = match status {
                                400 => "Bad Request",
                                409 => "Conflict",
                                _ => "Internal Server Error",
                            };
                            send_response(&mut stream, status, status_text, &resp.to_string())?;
                        }
                    }
                }
                Err(e) => {
                    let resp = serde_json::json!({
                        "success": false,
                        "message": format!("JSON 解析失败: {}", e)
                    });
                    send_response(&mut stream, 400, "Bad Request", &resp.to_string())?;
                }
            }
        }

        // 批量导入端点（扩展监控模式批量推送岗位列表）
        ("POST", "/api/import-batch") => {
            match serde_json::from_str::<serde_json::Value>(&body_str) {
                Ok(payload) => {
                    let jobs = payload["jobs"].as_array().cloned().unwrap_or_default();
                    let subscription_id = payload["subscription_id"].as_str().map(|s| s.to_string());

                    let app_clone = app.clone();
                    let result = tauri::async_runtime::block_on(async move {
                        let pool = app_clone.state::<SqlitePool>();
                        crate::commands::monitor::import_batch_jobs_inner(
                            app_clone.clone(),
                            &pool,
                            jobs,
                            subscription_id,
                        ).await
                    });

                    match result {
                        Ok(batch_result) => {
                            let resp = serde_json::json!({
                                "success": true,
                                "new_count": batch_result.new_jobs.len(),
                                "duplicate_count": batch_result.duplicate_count,
                            });
                            let _ = app.emit("offermate://job-imported", &payload);
                            send_response(&mut stream, 200, "OK", &resp.to_string())?;
                        }
                        Err(e) => {
                            let resp = serde_json::json!({
                                "success": false,
                                "message": e,
                            });
                            send_response(&mut stream, 500, "Internal Server Error", &resp.to_string())?;
                        }
                    }
                }
                Err(e) => {
                    let resp = serde_json::json!({
                        "success": false,
                        "message": format!("JSON 解析失败: {}", e)
                    });
                    send_response(&mut stream, 400, "Bad Request", &resp.to_string())?;
                }
            }
        }

        // 获取订阅规则（供扩展同步监控任务）
        ("GET", "/api/subscriptions") => {
            let app_clone = app.clone();
            let result = tauri::async_runtime::block_on(async move {
                let pool = app_clone.state::<SqlitePool>();
                sqlx::query_as::<_, crate::commands::monitor::SubscriptionRowPublic>(
                    "SELECT id, name, platform, keywords, companies, location FROM job_subscriptions WHERE enabled = 1"
                )
                .fetch_all(&*pool).await
            });

            match result {
                Ok(rows) => {
                    let resp = serde_json::json!({
                        "success": true,
                        "subscriptions": rows,
                    });
                    send_response(&mut stream, 200, "OK", &resp.to_string())?;
                }
                Err(e) => {
                    let resp = serde_json::json!({
                        "success": false,
                        "message": format!("查询失败: {}", e),
                    });
                    send_response(&mut stream, 500, "Internal Server Error", &resp.to_string())?;
                }
            }
        }

        ("OPTIONS", _) => {
            send_cors_preflight(&mut stream)?;
        }

        _ => {
            send_response(&mut stream, 404, "Not Found", "{\"error\":\"not found\"}")?;
        }
    }

    Ok(())
}

/// 将岗位数据写入数据库
/// 错误类型为 (HTTP状态码, 错误消息)
async fn persist_job(app: &AppHandle, payload: &JobPayload) -> Result<String, (u16, String)> {
    let pool = app.state::<SqlitePool>();
    let id = Uuid::new_v4().to_string();
    let now = chrono::Utc::now().to_rfc3339();

    let company = payload.company.as_deref().unwrap_or("").trim();
    let position = payload.position.as_deref().unwrap_or("").trim();

    if company.is_empty() && position.is_empty() {
        return Err((400, "未识别到公司和职位信息，请在岗位详情页使用".to_string()));
    }
    if company.is_empty() {
        return Err((400, "未识别到公司名称，请在岗位详情页使用".to_string()));
    }
    if position.is_empty() {
        return Err((400, "未识别到职位名称，请在岗位详情页使用".to_string()));
    }

    // 去重检查
    let existing: Option<String> = sqlx::query_scalar("SELECT id FROM jobs WHERE company=? AND position=?")
        .bind(company).bind(position)
        .fetch_optional(&*pool).await
        .map_err(|e| (500, format!("查询失败: {}", e)))?;

    if existing.is_some() {
        return Err((409, format!("已存在「{} - {}」的记录", company, position)));
    }

    sqlx::query("INSERT INTO jobs (id, company, position, url, salary, location, description, source, created_at, posted_at, is_remote, requirements) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(&id)
        .bind(company)
        .bind(position)
        .bind(&payload.url)
        .bind(&payload.salary)
        .bind(&payload.location)
        .bind(&payload.description)
        .bind(payload.source.as_deref().unwrap_or("extension"))
        .bind(&now)
        .bind(&payload.posted_at)
        .bind(payload.is_remote.map(|b| if b { 1i64 } else { 0 }))
        .bind(&payload.requirements)
        .execute(&*pool).await
        .map_err(|e| (500, format!("插入岗位失败: {}", e)))?;

    Ok(id)
}

fn send_response(
    stream: &mut std::net::TcpStream,
    status_code: u16,
    status_text: &str,
    body: &str,
) -> Result<(), String> {
    let response = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type, Authorization\r\nConnection: close\r\n\r\n{}",
        status_code, status_text, body.len(), body
    );
    stream.write_all(response.as_bytes()).map_err(|e| format!("写入响应失败: {}", e))?;
    stream.flush().map_err(|e| format!("刷新响应失败: {}", e))?;
    Ok(())
}

fn send_cors_preflight(stream: &mut std::net::TcpStream) -> Result<(), String> {
    let response = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type, Authorization\r\nAccess-Control-Max-Age: 86400\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
    stream.write_all(response.as_bytes()).map_err(|e| format!("写入预检响应失败: {}", e))?;
    stream.flush().map_err(|e| format!("刷新预检响应失败: {}", e))?;
    Ok(())
}
