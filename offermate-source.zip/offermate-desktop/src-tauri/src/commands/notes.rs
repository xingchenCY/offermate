// 求职笔记 Commands
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Note {
    pub id: String,
    pub title: String,
    pub content: String,
    pub tags: Vec<String>,
    pub category: String,
    pub application_id: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(sqlx::FromRow)]
struct NoteRow {
    id: String,
    title: String,
    content: String,
    tags: Option<String>,
    category: String,
    application_id: Option<String>,
    created_at: String,
    updated_at: String,
}

impl From<NoteRow> for Note {
    fn from(r: NoteRow) -> Self {
        let tags: Vec<String> = r.tags
            .map(|s| s.split(',').map(|t| t.trim().to_string()).filter(|t| !t.is_empty()).collect())
            .unwrap_or_default();
        Self {
            id: r.id, title: r.title, content: r.content, tags,
            category: r.category, application_id: r.application_id,
            created_at: r.created_at, updated_at: r.updated_at,
        }
    }
}

#[tauri::command]
pub async fn list_notes(
    pool: tauri::State<'_, SqlitePool>,
    category: Option<String>,
) -> Result<Vec<Note>, String> {
    let rows: Vec<NoteRow> = if category.is_some() {
        sqlx::query_as("SELECT * FROM notes WHERE category = ? ORDER BY updated_at DESC")
            .bind(category).fetch_all(&*pool).await
    } else {
        sqlx::query_as("SELECT * FROM notes ORDER BY updated_at DESC").fetch_all(&*pool).await
    }.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

#[tauri::command]
pub async fn create_note(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<Note, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let title = input["title"].as_str().unwrap_or("无标题").to_string();
    let content = input["content"].as_str().unwrap_or("").to_string();
    let category = input["category"].as_str().unwrap_or("general").to_string();
    let application_id = input["application_id"].as_str().map(|s| s.to_string());
    let tags = input["tags"].as_array().map(|arr| {
        arr.iter().filter_map(|v| v.as_str()).collect::<Vec<_>>().join(",")
    });

    sqlx::query("INSERT INTO notes (id, title, content, tags, category, application_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(&id).bind(&title).bind(&content).bind(&tags)
        .bind(&category).bind(&application_id).bind(&now).bind(&now)
        .execute(&*pool).await.map_err(|e| format!("创建失败: {}", e))?;

    let row: NoteRow = sqlx::query_as("SELECT * FROM notes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn update_note(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    input: serde_json::Value,
) -> Result<Note, String> {
    let now = Utc::now().to_rfc3339();
    let title = input["title"].as_str();
    let content = input["content"].as_str();
    let category = input["category"].as_str();
    let application_id = input["application_id"].as_str();
    let tags = input["tags"].as_array().map(|arr| {
        arr.iter().filter_map(|v| v.as_str()).collect::<Vec<_>>().join(",")
    });

    sqlx::query(
        "UPDATE notes SET title=COALESCE(?, title), content=COALESCE(?, content), tags=COALESCE(?, tags), category=COALESCE(?, category), application_id=COALESCE(?, application_id), updated_at=? WHERE id=?"
    )
    .bind(title).bind(content).bind(tags).bind(category).bind(application_id).bind(&now).bind(&id)
    .execute(&*pool).await.map_err(|e| format!("更新失败: {}", e))?;

    let row: NoteRow = sqlx::query_as("SELECT * FROM notes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn delete_note(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<(), String> {
    sqlx::query("DELETE FROM notes WHERE id = ?").bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}
