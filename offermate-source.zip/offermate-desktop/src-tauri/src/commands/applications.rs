// 投递记录 CRUD Commands
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;

use crate::state_machine::ApplicationStatus;

#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct Application {
    pub id: String,
    pub company: String,
    pub position: String,
    pub job_url: Option<String>,
    pub salary: Option<String>,
    pub location: Option<String>,
    pub source: String,
    pub status: String,
    pub priority: String,
    pub applied_at: Option<String>,
    pub next_interview_at: Option<String>,
    pub notes: Option<String>,
    pub job_id: Option<String>,
    pub resume_id: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CreateApplicationInput {
    pub company: String,
    pub position: String,
    pub job_url: Option<String>,
    pub salary: Option<String>,
    pub location: Option<String>,
    pub source: Option<String>,
    pub status: Option<String>,
    pub priority: Option<String>,
    pub next_interview_at: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct StatusLog {
    pub id: i64,
    pub application_id: String,
    pub from_status: Option<String>,
    pub to_status: String,
    pub note: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DashboardStats {
    pub total: i64,
    pub saved: i64,
    pub applied: i64,
    pub written: i64,
    pub phone_screen: i64,
    pub onsite: i64,
    pub offer: i64,
    pub rejected: i64,
    pub withdrawn: i64,
    pub interviewing: i64,
    pub conversion_rate: f64,
    pub by_status: serde_json::Value,
    pub trend: Vec<serde_json::Value>,
}

/// 列出所有投递记录
#[tauri::command]
pub async fn list_applications(
    pool: tauri::State<'_, SqlitePool>,
    status_filter: Option<String>,
) -> Result<Vec<Application>, String> {
    let sql = if status_filter.is_some() {
        "SELECT * FROM applications WHERE status = ? ORDER BY created_at DESC"
    } else {
        "SELECT * FROM applications ORDER BY created_at DESC"
    };

    let rows = if let Some(ref status) = status_filter {
        sqlx::query_as::<_, Application>(sql).bind(status).fetch_all(&*pool).await
    } else {
        sqlx::query_as::<_, Application>(sql).fetch_all(&*pool).await
    };

    let rows = rows.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows)
}

/// 获取单个投递记录
#[tauri::command]
pub async fn get_application(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
) -> Result<Application, String> {
    sqlx::query_as::<_, Application>("SELECT * FROM applications WHERE id = ?")
        .bind(&id)
        .fetch_one(&*pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))
}

/// 创建投递记录
#[tauri::command]
pub async fn create_application(
    pool: tauri::State<'_, SqlitePool>,
    input: CreateApplicationInput,
) -> Result<Application, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let status = input.status.unwrap_or_else(|| "saved".to_string());
    let priority = input.priority.unwrap_or_else(|| "none".to_string());
    let source = input.source.unwrap_or_else(|| "manual".to_string());

    sqlx::query(
        "INSERT INTO applications (id, company, position, job_url, salary, location, source, status, priority, next_interview_at, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )
    .bind(&id)
    .bind(&input.company)
    .bind(&input.position)
    .bind(&input.job_url)
    .bind(&input.salary)
    .bind(&input.location)
    .bind(&source)
    .bind(&status)
    .bind(&priority)
    .bind(&input.next_interview_at)
    .bind(&input.notes)
    .bind(&now)
    .bind(&now)
    .execute(&*pool)
    .await
    .map_err(|e| format!("创建失败: {}", e))?;

    // 记录初始状态日志
    sqlx::query(
        "INSERT INTO status_logs (application_id, from_status, to_status, note, created_at) VALUES (?, NULL, ?, '创建记录', ?)"
    )
    .bind(&id).bind(&status).bind(&now)
    .execute(&*pool).await.ok();

    sqlx::query_as::<_, Application>("SELECT * FROM applications WHERE id = ?")
        .bind(&id)
        .fetch_one(&*pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))
}

/// 更新投递记录
#[tauri::command]
pub async fn update_application(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    input: serde_json::Value,
) -> Result<Application, String> {
    let now = Utc::now().to_rfc3339();

    sqlx::query(
        "UPDATE applications SET
            company=COALESCE(?, company),
            position=COALESCE(?, position),
            job_url=COALESCE(?, job_url),
            salary=COALESCE(?, salary),
            location=COALESCE(?, location),
            source=COALESCE(?, source),
            status=COALESCE(?, status),
            priority=COALESCE(?, priority),
            next_interview_at=COALESCE(?, next_interview_at),
            notes=COALESCE(?, notes),
            resume_id=COALESCE(?, resume_id),
            updated_at=?
         WHERE id=?"
    )
    .bind(input["company"].as_str())
    .bind(input["position"].as_str())
    .bind(input["job_url"].as_str())
    .bind(input["salary"].as_str())
    .bind(input["location"].as_str())
    .bind(input["source"].as_str())
    .bind(input["status"].as_str())
    .bind(input["priority"].as_str())
    .bind(input["next_interview_at"].as_str())
    .bind(input["notes"].as_str())
    .bind(input["resume_id"].as_str())
    .bind(&now)
    .bind(&id)
    .execute(&*pool)
    .await
    .map_err(|e| format!("更新失败: {}", e))?;

    sqlx::query_as::<_, Application>("SELECT * FROM applications WHERE id = ?")
        .bind(&id)
        .fetch_one(&*pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))
}

/// 删除投递记录
#[tauri::command]
pub async fn delete_application(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
) -> Result<(), String> {
    sqlx::query("DELETE FROM status_logs WHERE application_id = ?")
        .bind(&id).execute(&*pool).await.ok();
    sqlx::query("DELETE FROM applications WHERE id = ?")
        .bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}

/// 状态转换（验证合法性 + 记录日志）
#[tauri::command]
pub async fn transition_status(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    to_status: String,
    note: Option<String>,
) -> Result<StatusLog, String> {
    let now = Utc::now().to_rfc3339();

    // 获取当前状态
    let current: Option<String> = sqlx::query_scalar("SELECT status FROM applications WHERE id = ?")
        .bind(&id)
        .fetch_optional(&*pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))?;

    let from_status = current.ok_or("记录不存在")?;

    // 验证状态转换
    let from = ApplicationStatus::from_str(&from_status)
        .ok_or_else(|| format!("无效状态: {}", from_status))?;
    let to = ApplicationStatus::from_str(&to_status)
        .ok_or_else(|| format!("无效目标状态: {}", to_status))?;

    if !from.can_transition_to(&to) {
        return Err(format!("不允许从 {} 转换到 {}", from.label(), to.label()));
    }

    // 更新状态
    let applied_at = if to == ApplicationStatus::Applied { Some(&now) } else { None };
    sqlx::query("UPDATE applications SET status=?, applied_at=COALESCE(?, applied_at), updated_at=? WHERE id=?")
        .bind(&to_status).bind(applied_at).bind(&now).bind(&id)
        .execute(&*pool).await
        .map_err(|e| format!("更新失败: {}", e))?;

    // 记录日志
    let row = sqlx::query_as::<_, StatusLog>(
        "INSERT INTO status_logs (application_id, from_status, to_status, note, created_at) VALUES (?, ?, ?, ?, ?) RETURNING *"
    )
    .bind(&id).bind(&from_status).bind(&to_status).bind(&note).bind(&now)
    .fetch_one(&*pool).await
    .map_err(|e| format!("记录日志失败: {}", e))?;

    Ok(row)
}

/// 获取状态时间线
#[tauri::command]
pub async fn get_timeline(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
) -> Result<Vec<StatusLog>, String> {
    let rows = sqlx::query_as::<_, StatusLog>(
        "SELECT * FROM status_logs WHERE application_id = ? ORDER BY created_at ASC"
    )
    .bind(&id)
    .fetch_all(&*pool)
    .await
    .map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows)
}

/// 获取仪表盘统计
#[tauri::command]
pub async fn get_stats(
    pool: tauri::State<'_, SqlitePool>,
) -> Result<DashboardStats, String> {
    use sqlx::Row;
    let rows = sqlx::query(
        "SELECT status, COUNT(*) as count FROM applications GROUP BY status"
    )
    .fetch_all(&*pool)
    .await
    .map_err(|e| format!("查询失败: {}", e))?;

    let counts: Vec<(String, i64)> = rows.iter().map(|r| {
        (r.try_get::<String, _>("status").unwrap_or_default(),
         r.try_get::<i64, _>("count").unwrap_or(0))
    }).collect();

    let mut stats = DashboardStats {
        saved: 0, applied: 0, written: 0, phone_screen: 0,
        onsite: 0, offer: 0, rejected: 0, withdrawn: 0,
        total: 0, interviewing: 0, conversion_rate: 0.0,
        by_status: serde_json::json!({
            "saved": 0, "applied": 0, "written": 0, "phone_screen": 0,
            "onsite": 0, "offer": 0, "rejected": 0, "withdrawn": 0
        }),
        trend: vec![],
    };

    for (status, count) in counts {
        match status.as_str() {
            "saved" => { stats.saved = count; stats.by_status["saved"] = serde_json::json!(count); }
            "applied" => { stats.applied = count; stats.by_status["applied"] = serde_json::json!(count); }
            "written" => { stats.written = count; stats.by_status["written"] = serde_json::json!(count); }
            "phone_screen" => { stats.phone_screen = count; stats.by_status["phone_screen"] = serde_json::json!(count); }
            "onsite" => { stats.onsite = count; stats.by_status["onsite"] = serde_json::json!(count); }
            "offer" => { stats.offer = count; stats.by_status["offer"] = serde_json::json!(count); }
            "rejected" => { stats.rejected = count; stats.by_status["rejected"] = serde_json::json!(count); }
            "withdrawn" => { stats.withdrawn = count; stats.by_status["withdrawn"] = serde_json::json!(count); }
            _ => {}
        }
    }

    stats.total = stats.saved + stats.applied + stats.written + stats.phone_screen
        + stats.onsite + stats.offer + stats.rejected + stats.withdrawn;

    stats.interviewing = stats.written + stats.phone_screen + stats.onsite;

    let applied_total = stats.applied + stats.written + stats.phone_screen + stats.onsite + stats.offer + stats.rejected;
    if applied_total > 0 {
        stats.conversion_rate = (stats.offer as f64 / applied_total as f64) * 100.0;
    }

    Ok(stats)
}
