// 岗位聚合 Commands
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Job {
    pub id: String,
    pub company: String,
    pub position: String,
    pub url: Option<String>,
    pub salary: Option<String>,
    pub location: Option<String>,
    pub description: Option<String>,
    pub source: Option<String>,
    pub match_score: Option<f64>,
    pub tags: Option<String>,
    pub created_at: String,
    pub posted_at: Option<String>,
    pub is_remote: Option<bool>,
    pub requirements: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct JobRow {
    id: String,
    company: String,
    position: String,
    url: Option<String>,
    salary: Option<String>,
    location: Option<String>,
    description: Option<String>,
    source: Option<String>,
    match_score: Option<f64>,
    tags: Option<String>,
    created_at: String,
    posted_at: Option<String>,
    is_remote: Option<i64>,
    requirements: Option<String>,
}

impl From<JobRow> for Job {
    fn from(r: JobRow) -> Self {
        Self {
            id: r.id, company: r.company, position: r.position,
            url: r.url, salary: r.salary, location: r.location,
            description: r.description, source: r.source,
            match_score: r.match_score, tags: r.tags, created_at: r.created_at,
            posted_at: r.posted_at,
            is_remote: r.is_remote.map(|v| v != 0),
            requirements: r.requirements,
        }
    }
}

#[tauri::command]
pub async fn list_jobs(
    pool: tauri::State<'_, SqlitePool>,
    source_filter: Option<String>,
) -> Result<Vec<Job>, String> {
    let rows: Vec<JobRow> = if source_filter.is_some() {
        sqlx::query_as("SELECT * FROM jobs WHERE source = ? ORDER BY created_at DESC")
            .bind(source_filter).fetch_all(&*pool).await
    } else {
        sqlx::query_as("SELECT * FROM jobs ORDER BY created_at DESC").fetch_all(&*pool).await
    }.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

#[tauri::command]
pub async fn create_job(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<Job, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let company = input["company"].as_str().unwrap_or("").to_string();
    let position = input["position"].as_str().unwrap_or("").to_string();

    // 去重检查
    let existing: Option<String> = sqlx::query_scalar("SELECT id FROM jobs WHERE company=? AND position=?")
        .bind(&company).bind(&position)
        .fetch_optional(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;

    if existing.is_some() {
        return Err("已存在相同公司和职位的记录".to_string());
    }

    let url = input["url"].as_str().map(|s| s.to_string());
    let salary = input["salary"].as_str().map(|s| s.to_string());
    let location = input["location"].as_str().map(|s| s.to_string());
    let description = input["description"].as_str().map(|s| s.to_string());
    let source = input["source"].as_str().unwrap_or("manual").to_string();
    let match_score = input["match_score"].as_f64();
    let tags = input["tags"].as_array().map(|arr| {
        arr.iter().filter_map(|v| v.as_str()).collect::<Vec<_>>().join(",")
    });
    let posted_at = input["posted_at"].as_str().map(|s| s.to_string());
    let is_remote = input["is_remote"].as_bool().map(|b| if b { 1i64 } else { 0 });
    let requirements = input["requirements"].as_str().map(|s| s.to_string());

    sqlx::query("INSERT INTO jobs (id, company, position, url, salary, location, description, source, match_score, tags, created_at, posted_at, is_remote, requirements) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(&id).bind(&company).bind(&position).bind(&url)
        .bind(&salary).bind(&location).bind(&description)
        .bind(&source).bind(match_score).bind(&tags).bind(&now)
        .bind(&posted_at).bind(is_remote).bind(&requirements)
        .execute(&*pool).await.map_err(|e| format!("创建失败: {}", e))?;

    let row: JobRow = sqlx::query_as("SELECT * FROM jobs WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn delete_job(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<(), String> {
    sqlx::query("DELETE FROM jobs WHERE id = ?").bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}

#[tauri::command]
pub async fn import_jobs(
    pool: tauri::State<'_, SqlitePool>,
    jobs: Vec<serde_json::Value>,
) -> Result<Vec<Job>, String> {
    let mut imported = Vec::new();
    for job in jobs {
        let id = Uuid::new_v4().to_string();
        let now = Utc::now().to_rfc3339();
        let company = job["company"].as_str().unwrap_or("").to_string();
        let position = job["position"].as_str().unwrap_or("").to_string();

        // 去重
        let existing: Option<String> = sqlx::query_scalar("SELECT id FROM jobs WHERE company=? AND position=?")
            .bind(&company).bind(&position)
            .fetch_optional(&*pool).await.ok().flatten();
        if existing.is_some() { continue; }

        let url = job["url"].as_str().map(|s| s.to_string());
        let salary = job["salary"].as_str().map(|s| s.to_string());
        let location = job["location"].as_str().map(|s| s.to_string());
        let description = job["description"].as_str().map(|s| s.to_string());
        let source = job["source"].as_str().unwrap_or("extension").to_string();
        let match_score = job["match_score"].as_f64();
        let posted_at = job["posted_at"].as_str().map(|s| s.to_string());
        let is_remote = job["is_remote"].as_bool().map(|b| if b { 1i64 } else { 0 });
        let requirements = job["requirements"].as_str().map(|s| s.to_string());

        let result = sqlx::query("INSERT INTO jobs (id, company, position, url, salary, location, description, source, match_score, created_at, posted_at, is_remote, requirements) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            .bind(&id).bind(&company).bind(&position).bind(&url)
            .bind(&salary).bind(&location).bind(&description)
            .bind(&source).bind(match_score).bind(&now)
            .bind(&posted_at).bind(is_remote).bind(&requirements)
            .execute(&*pool).await;

        if result.is_ok() {
            if let Ok(row) = sqlx::query_as::<_, JobRow>("SELECT * FROM jobs WHERE id = ?")
                .bind(&id).fetch_one(&*pool).await {
                imported.push(row.into());
            }
        }
    }
    Ok(imported)
}

#[tauri::command]
pub async fn search_jobs(
    pool: tauri::State<'_, SqlitePool>,
    query: String,
) -> Result<Vec<Job>, String> {
    let pattern = format!("%{}%", query);
    let rows: Vec<JobRow> = sqlx::query_as(
        "SELECT * FROM jobs WHERE company LIKE ? OR position LIKE ? OR description LIKE ? ORDER BY created_at DESC"
    )
    .bind(&pattern).bind(&pattern).bind(&pattern)
    .fetch_all(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

/// 列出指定时间之后入库的岗位（监控仪表盘用）
#[tauri::command]
pub async fn list_recent_jobs(
    pool: tauri::State<'_, SqlitePool>,
    since: Option<String>,
    hours: Option<i64>,
) -> Result<Vec<Job>, String> {
    let cutoff = if let Some(h) = hours {
        let dt = Utc::now() - chrono::Duration::hours(h);
        dt.to_rfc3339()
    } else if let Some(s) = since {
        s
    } else {
        let dt = Utc::now() - chrono::Duration::hours(24);
        dt.to_rfc3339()
    };

    let rows: Vec<JobRow> = sqlx::query_as(
        "SELECT * FROM jobs WHERE created_at >= ? ORDER BY created_at DESC"
    )
    .bind(&cutoff)
    .fetch_all(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}
