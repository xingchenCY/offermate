// 简历管理 Commands
// content 字段存储完整 JSON（basic_info, education, experience, projects, skills, awards）
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Resume {
    pub id: String,
    pub name: String,
    pub template: String,
    pub content: serde_json::Value,
    pub is_primary: bool,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubResume {
    pub id: String,
    pub parent_id: String,
    pub name: String,
    pub content: serde_json::Value,
    pub target_company: Option<String>,
    pub target_position: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(sqlx::FromRow)]
struct ResumeRow {
    id: String,
    name: String,
    template: String,
    content: String,
    is_primary: i64,
    created_at: String,
    updated_at: String,
}

impl From<ResumeRow> for Resume {
    fn from(r: ResumeRow) -> Self {
        let content: serde_json::Value = serde_json::from_str(&r.content).unwrap_or(serde_json::json!({}));
        Self {
            id: r.id, name: r.name, template: r.template, content,
            is_primary: r.is_primary != 0, created_at: r.created_at, updated_at: r.updated_at,
        }
    }
}

#[derive(sqlx::FromRow)]
struct SubResumeRow {
    id: String,
    parent_id: String,
    name: String,
    content: String,
    target_company: Option<String>,
    target_position: Option<String>,
    created_at: String,
    updated_at: String,
}

impl From<SubResumeRow> for SubResume {
    fn from(r: SubResumeRow) -> Self {
        let content: serde_json::Value = serde_json::from_str(&r.content).unwrap_or(serde_json::json!({}));
        Self {
            id: r.id, parent_id: r.parent_id, name: r.name, content,
            target_company: r.target_company, target_position: r.target_position,
            created_at: r.created_at, updated_at: r.updated_at,
        }
    }
}

#[tauri::command]
pub async fn list_resumes(pool: tauri::State<'_, SqlitePool>) -> Result<Vec<Resume>, String> {
    let rows: Vec<ResumeRow> = sqlx::query_as(
        "SELECT * FROM resumes ORDER BY is_primary DESC, updated_at DESC"
    )
    .fetch_all(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

#[tauri::command]
pub async fn get_resume(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<Resume, String> {
    let row: ResumeRow = sqlx::query_as("SELECT * FROM resumes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn create_resume(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<Resume, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let name = input["name"].as_str().unwrap_or("未命名简历").to_string();
    let template = input["template"].as_str().unwrap_or("modern").to_string();
    let content = serde_json::to_string(&input).unwrap_or_else(|_| "{}".to_string());

    sqlx::query("INSERT INTO resumes (id, name, template, content, is_primary, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?)")
        .bind(&id).bind(&name).bind(&template).bind(&content).bind(&now).bind(&now)
        .execute(&*pool).await.map_err(|e| format!("创建失败: {}", e))?;

    let row: ResumeRow = sqlx::query_as("SELECT * FROM resumes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn update_resume(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    input: serde_json::Value,
) -> Result<Resume, String> {
    let now = Utc::now().to_rfc3339();
    let content = serde_json::to_string(&input).unwrap_or_else(|_| "{}".to_string());
    let name = input["name"].as_str();
    let template = input["template"].as_str();

    sqlx::query(
        "UPDATE resumes SET content=?, name=COALESCE(?, name), template=COALESCE(?, template), updated_at=? WHERE id=?"
    )
    .bind(&content).bind(name).bind(template).bind(&now).bind(&id)
    .execute(&*pool).await.map_err(|e| format!("更新失败: {}", e))?;

    let row: ResumeRow = sqlx::query_as("SELECT * FROM resumes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn delete_resume(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<(), String> {
    sqlx::query("DELETE FROM sub_resumes WHERE parent_id = ?").bind(&id).execute(&*pool).await.ok();
    sqlx::query("DELETE FROM resumes WHERE id = ?").bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}

#[tauri::command]
pub async fn list_sub_resumes(
    pool: tauri::State<'_, SqlitePool>,
    parent_id: String,
) -> Result<Vec<SubResume>, String> {
    let rows: Vec<SubResumeRow> = sqlx::query_as(
        "SELECT * FROM sub_resumes WHERE parent_id = ? ORDER BY created_at DESC"
    )
    .bind(&parent_id).fetch_all(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

#[tauri::command]
pub async fn create_sub_resume(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<SubResume, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let parent_id = input["parent_id"].as_str().unwrap_or("").to_string();
    let name = input["name"].as_str().unwrap_or("子简历").to_string();
    let target_company = input["target_company"].as_str().map(|s| s.to_string());
    let target_position = input["target_position"].as_str().map(|s| s.to_string());
    let content = serde_json::to_string(&input.get("overrides").cloned().unwrap_or(serde_json::json!({})))
        .unwrap_or_else(|_| "{}".to_string());

    sqlx::query("INSERT INTO sub_resumes (id, parent_id, name, content, target_company, target_position, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(&id).bind(&parent_id).bind(&name).bind(&content)
        .bind(&target_company).bind(&target_position).bind(&now).bind(&now)
        .execute(&*pool).await.map_err(|e| format!("创建失败: {}", e))?;

    let row: SubResumeRow = sqlx::query_as("SELECT * FROM sub_resumes WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn delete_sub_resume(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<(), String> {
    sqlx::query("DELETE FROM sub_resumes WHERE id = ?").bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}
