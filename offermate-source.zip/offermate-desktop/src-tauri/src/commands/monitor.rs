//! 岗位监控模块
//!
//! 融合开源方案优势：
//! - JobSpy: hours_old 增量过滤 + 结构化 JobPost schema
//! - ai-job-search: AI 匹配评分自动过滤
//! - get_jobs: 配置化筛选规则 + 企业微信/飞书推送
//! - job_feishu_bot: 新岗位 → 通知推送闭环

use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;
use tauri::{AppHandle, Emitter, Manager};

use crate::ai::AIProviderFactory;
use crate::db;
use crate::commands::jobs::Job;

// ============================================================
// 数据结构
// ============================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JobSubscription {
    pub id: String,
    pub name: String,
    pub platform: String,
    pub keywords: Option<String>,
    pub companies: Option<String>,
    pub location: Option<String>,
    pub salary_min: Option<String>,
    pub salary_max: Option<String>,
    pub is_remote_only: bool,
    pub interval_minutes: i64,
    pub ai_filter_enabled: bool,
    pub ai_threshold: f64,
    pub webhook_url: Option<String>,
    pub enabled: bool,
    pub last_run_at: Option<String>,
    pub last_new_count: i64,
    pub total_new_count: i64,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(sqlx::FromRow)]
struct SubscriptionRow {
    id: String,
    name: String,
    platform: String,
    keywords: Option<String>,
    companies: Option<String>,
    location: Option<String>,
    salary_min: Option<String>,
    salary_max: Option<String>,
    is_remote_only: i64,
    interval_minutes: i64,
    ai_filter_enabled: i64,
    ai_threshold: f64,
    webhook_url: Option<String>,
    enabled: i64,
    last_run_at: Option<String>,
    last_new_count: i64,
    total_new_count: i64,
    created_at: String,
    updated_at: String,
}

impl From<SubscriptionRow> for JobSubscription {
    fn from(r: SubscriptionRow) -> Self {
        Self {
            id: r.id, name: r.name, platform: r.platform,
            keywords: r.keywords, companies: r.companies, location: r.location,
            salary_min: r.salary_min, salary_max: r.salary_max,
            is_remote_only: r.is_remote_only != 0,
            interval_minutes: r.interval_minutes,
            ai_filter_enabled: r.ai_filter_enabled != 0,
            ai_threshold: r.ai_threshold,
            webhook_url: r.webhook_url,
            enabled: r.enabled != 0,
            last_run_at: r.last_run_at,
            last_new_count: r.last_new_count,
            total_new_count: r.total_new_count,
            created_at: r.created_at, updated_at: r.updated_at,
        }
    }
}

/// 批量导入结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchImportResult {
    pub new_jobs: Vec<Job>,
    pub duplicate_count: usize,
    pub subscription_id: Option<String>,
}

/// 订阅规则的精简版（供扩展同步用）
#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct SubscriptionRowPublic {
    pub id: String,
    pub name: String,
    pub platform: String,
    pub keywords: Option<String>,
    pub companies: Option<String>,
    pub location: Option<String>,
}

// ============================================================
// 订阅规则 CRUD
// ============================================================

#[tauri::command]
pub async fn list_subscriptions(pool: tauri::State<'_, SqlitePool>) -> Result<Vec<JobSubscription>, String> {
    let rows: Vec<SubscriptionRow> = sqlx::query_as(
        "SELECT * FROM job_subscriptions ORDER BY created_at DESC"
    )
    .fetch_all(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}

#[tauri::command]
pub async fn create_subscription(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<JobSubscription, String> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();

    let name = input["name"].as_str().unwrap_or("未命名订阅").to_string();
    let platform = input["platform"].as_str().unwrap_or("boss").to_string();
    let keywords = input["keywords"].as_str().map(|s| s.to_string());
    let companies = input["companies"].as_str().map(|s| s.to_string());
    let location = input["location"].as_str().map(|s| s.to_string());
    let salary_min = input["salary_min"].as_str().map(|s| s.to_string());
    let salary_max = input["salary_max"].as_str().map(|s| s.to_string());
    let is_remote_only = input["is_remote_only"].as_bool().unwrap_or(false);
    let interval_minutes = input["interval_minutes"].as_i64().unwrap_or(60);
    let ai_filter_enabled = input["ai_filter_enabled"].as_bool().unwrap_or(false);
    let ai_threshold = input["ai_threshold"].as_f64().unwrap_or(60.0);
    let webhook_url = input["webhook_url"].as_str().map(|s| s.to_string());
    let enabled = input["enabled"].as_bool().unwrap_or(true);

    sqlx::query(
        "INSERT INTO job_subscriptions (id, name, platform, keywords, companies, location, salary_min, salary_max, is_remote_only, interval_minutes, ai_filter_enabled, ai_threshold, webhook_url, enabled, last_new_count, total_new_count, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)"
    )
    .bind(&id).bind(&name).bind(&platform)
    .bind(&keywords).bind(&companies).bind(&location)
    .bind(&salary_min).bind(&salary_max)
    .bind(if is_remote_only { 1i64 } else { 0 })
    .bind(interval_minutes)
    .bind(if ai_filter_enabled { 1i64 } else { 0 })
    .bind(ai_threshold)
    .bind(&webhook_url)
    .bind(if enabled { 1i64 } else { 0 })
    .bind(&now).bind(&now)
    .execute(&*pool).await
    .map_err(|e| format!("创建订阅失败: {}", e))?;

    let row: SubscriptionRow = sqlx::query_as("SELECT * FROM job_subscriptions WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn update_subscription(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    input: serde_json::Value,
) -> Result<JobSubscription, String> {
    let now = Utc::now().to_rfc3339();

    sqlx::query(
        "UPDATE job_subscriptions SET name=?, platform=?, keywords=?, companies=?, location=?, salary_min=?, salary_max=?, is_remote_only=?, interval_minutes=?, ai_filter_enabled=?, ai_threshold=?, webhook_url=?, enabled=?, updated_at=? WHERE id=?"
    )
    .bind(input["name"].as_str().unwrap_or("未命名订阅"))
    .bind(input["platform"].as_str().unwrap_or("boss"))
    .bind(input["keywords"].as_str())
    .bind(input["companies"].as_str())
    .bind(input["location"].as_str())
    .bind(input["salary_min"].as_str())
    .bind(input["salary_max"].as_str())
    .bind(input["is_remote_only"].as_bool().unwrap_or(false) as i64)
    .bind(input["interval_minutes"].as_i64().unwrap_or(60))
    .bind(input["ai_filter_enabled"].as_bool().unwrap_or(false) as i64)
    .bind(input["ai_threshold"].as_f64().unwrap_or(60.0))
    .bind(input["webhook_url"].as_str())
    .bind(input["enabled"].as_bool().unwrap_or(true) as i64)
    .bind(&now)
    .bind(&id)
    .execute(&*pool).await
    .map_err(|e| format!("更新失败: {}", e))?;

    let row: SubscriptionRow = sqlx::query_as("SELECT * FROM job_subscriptions WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

#[tauri::command]
pub async fn delete_subscription(pool: tauri::State<'_, SqlitePool>, id: String) -> Result<(), String> {
    sqlx::query("DELETE FROM job_seen_cache WHERE subscription_id = ?")
        .bind(&id).execute(&*pool).await.ok();
    sqlx::query("DELETE FROM job_subscriptions WHERE id = ?")
        .bind(&id).execute(&*pool).await
        .map_err(|e| format!("删除失败: {}", e))?;
    Ok(())
}

#[tauri::command]
pub async fn toggle_subscription(
    pool: tauri::State<'_, SqlitePool>,
    id: String,
    enabled: bool,
) -> Result<(), String> {
    sqlx::query("UPDATE job_subscriptions SET enabled=?, updated_at=? WHERE id=?")
        .bind(if enabled { 1i64 } else { 0 })
        .bind(Utc::now().to_rfc3339())
        .bind(&id)
        .execute(&*pool).await
        .map_err(|e| format!("更新失败: {}", e))?;
    Ok(())
}

// ============================================================
// 批量导入 + 新岗位检测（核心：借鉴 JobSpy 增量检测 + job_feishu_bot 推送闭环）
// ============================================================

/// 批量导入岗位（来自扩展监控抓取），返回真正新增的岗位
#[tauri::command]
pub async fn import_batch_jobs(
    app: AppHandle,
    pool: tauri::State<'_, SqlitePool>,
    jobs: Vec<serde_json::Value>,
    subscription_id: Option<String>,
) -> Result<BatchImportResult, String> {
    import_batch_jobs_inner(app, &pool, jobs, subscription_id).await
}

/// 批量导入的内部实现（可从 server.rs 调用，不需要 tauri::State）
pub async fn import_batch_jobs_inner(
    app: AppHandle,
    pool: &SqlitePool,
    jobs: Vec<serde_json::Value>,
    subscription_id: Option<String>,
) -> Result<BatchImportResult, String> {
    let mut new_jobs = Vec::new();
    let mut duplicate_count = 0;

    for job_data in &jobs {
        let company = job_data["company"].as_str().unwrap_or("").to_string();
        let position = job_data["position"].as_str().unwrap_or("").to_string();

        if company.is_empty() || position.is_empty() {
            continue;
        }

        let job_key = format!("{}|{}", company.to_lowercase(), position.to_lowercase());

        // 检查是否已在 seen_cache 中（针对该订阅的去重）
        if let Some(ref sub_id) = subscription_id {
            let seen: Option<i64> = sqlx::query_scalar(
                "SELECT COUNT(*) FROM job_seen_cache WHERE subscription_id=? AND job_key=?"
            )
            .bind(sub_id).bind(&job_key)
            .fetch_optional(&*pool).await
            .map_err(|e| format!("查询缓存失败: {}", e))?;

            if seen.unwrap_or(0) > 0 {
                duplicate_count += 1;
                continue;
            }
        }

        // 检查是否已在 jobs 表中（全局去重）
        let existing: Option<String> = sqlx::query_scalar(
            "SELECT id FROM jobs WHERE company=? AND position=?"
        )
        .bind(&company).bind(&position)
        .fetch_optional(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;

        if existing.is_some() {
            duplicate_count += 1;
            // 即使已存在，也标记为已见
            if let Some(ref sub_id) = subscription_id {
                mark_job_seen(pool, sub_id, &job_key).await;
            }
            continue;
        }

        // 插入新岗位
        let id = Uuid::new_v4().to_string();
        let now = Utc::now().to_rfc3339();
        let url = job_data["url"].as_str().map(|s| s.to_string());
        let salary = job_data["salary"].as_str().map(|s| s.to_string());
        let location = job_data["location"].as_str().map(|s| s.to_string());
        let description = job_data["description"].as_str().map(|s| s.to_string());
        let source = job_data["source"].as_str().unwrap_or("monitor").to_string();
        let posted_at = job_data["posted_at"].as_str().map(|s| s.to_string());
        let is_remote = job_data["is_remote"].as_bool().map(|b| if b { 1i64 } else { 0 });
        let requirements = job_data["requirements"].as_str().map(|s| s.to_string());

        let insert_result = sqlx::query(
            "INSERT INTO jobs (id, company, position, url, salary, location, description, source, created_at, posted_at, is_remote, requirements) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        .bind(&id).bind(&company).bind(&position).bind(&url)
        .bind(&salary).bind(&location).bind(&description)
        .bind(&source).bind(&now)
        .bind(&posted_at).bind(is_remote).bind(&requirements)
        .execute(&*pool).await;

        if insert_result.is_ok() {
            // 查回完整记录
            if let Ok(row) = sqlx::query_as::<_, crate::commands::jobs::JobRow>(
                "SELECT * FROM jobs WHERE id = ?"
            ).bind(&id).fetch_one(&*pool).await {
                let job: Job = row.into();
                new_jobs.push(job);
            }

            // 标记为已见
            if let Some(ref sub_id) = subscription_id {
                mark_job_seen(pool, sub_id, &job_key).await;
            }
        }
    }

    // 更新订阅统计
    if let Some(ref sub_id) = subscription_id {
        let new_count = new_jobs.len() as i64;
        sqlx::query(
            "UPDATE job_subscriptions SET last_run_at=?, last_new_count=?, total_new_count=total_new_count+?, updated_at=? WHERE id=?"
        )
        .bind(Utc::now().to_rfc3339())
        .bind(new_count)
        .bind(new_count)
        .bind(Utc::now().to_rfc3339())
        .bind(sub_id)
        .execute(&*pool).await.ok();
    }

    // 有新岗位时：AI 自动评分 + 发送事件 + Webhook 推送
    if !new_jobs.is_empty() {
        // 异步执行 AI 评分（不阻塞返回）
        let app_clone = app.clone();
        let pool_clone = pool.clone();
        let sub_clone = subscription_id.clone();
        let jobs_clone = new_jobs.clone();
        tauri::async_runtime::spawn(async move {
            auto_score_and_notify(app_clone, pool_clone, jobs_clone, sub_clone).await;
        });

        // 发送 Tauri 事件供前端实时更新
        let _ = app.emit("offermate://new-jobs-detected", &serde_json::json!({
            "count": new_jobs.len(),
            "subscription_id": subscription_id,
        }));
    }

    Ok(BatchImportResult {
        new_jobs,
        duplicate_count,
        subscription_id,
    })
}

/// 标记岗位为已见
async fn mark_job_seen(pool: &SqlitePool, subscription_id: &str, job_key: &str) {
    sqlx::query("INSERT INTO job_seen_cache (subscription_id, job_key, seen_at) VALUES (?, ?, ?)")
        .bind(subscription_id)
        .bind(job_key)
        .bind(Utc::now().to_rfc3339())
        .execute(pool).await.ok();
}

// ============================================================
// AI 自动评分（借鉴 ai-job-search 的 fit evaluation）
// ============================================================

/// 对新岗位自动进行 AI 匹配评分，并更新 match_score
async fn auto_score_and_notify(
    app: AppHandle,
    pool: SqlitePool,
    jobs: Vec<Job>,
    subscription_id: Option<String>,
) {
    // 读取订阅配置
    let (ai_filter_enabled, ai_threshold, webhook_url) = if let Some(ref sub_id) = subscription_id {
        let row: Option<SubscriptionRow> = sqlx::query_as(
            "SELECT * FROM job_subscriptions WHERE id = ?"
        )
        .bind(sub_id).fetch_optional(&pool).await.ok().flatten();

        if let Some(r) = row {
            (r.ai_filter_enabled != 0, r.ai_threshold, r.webhook_url)
        } else {
            (false, 0.0, None)
        }
    } else {
        (false, 0.0, None)
    };

    // 如果启用 AI 过滤，对每个新岗位评分
    let mut filtered_jobs: Vec<Job> = Vec::new();

    if ai_filter_enabled {
        let (provider_type, api_key, model, base_url) = load_ai_config(&pool).await;

        // 获取主简历内容
        let resume_content: Option<String> = sqlx::query_scalar(
            "SELECT content FROM resumes WHERE is_primary = 1 LIMIT 1"
        )
        .fetch_optional(&pool).await.ok().flatten();

        if let Some(resume) = resume_content {
            let provider = AIProviderFactory::create(&provider_type, &api_key, &model, &base_url);

            for mut job in jobs {
                let job_desc = job.description.as_deref().unwrap_or(&job.position);
                match provider.match_job(&resume, job_desc).await {
                    Ok(result) => {
                        job.match_score = Some(result.score);
                        // 更新数据库中的评分
                        sqlx::query("UPDATE jobs SET match_score = ? WHERE id = ?")
                            .bind(result.score)
                            .bind(&job.id)
                            .execute(&pool).await.ok();

                        // 仅保留达到阈值的岗位
                        if result.score >= ai_threshold {
                            filtered_jobs.push(job);
                        }
                    }
                    Err(_) => {
                        // AI 评分失败，保留岗位不过滤
                        filtered_jobs.push(job);
                    }
                }
            }
        } else {
            // 没有主简历，不过滤
            filtered_jobs = jobs;
        }
    } else {
        filtered_jobs = jobs;
    }

    // 发送桌面通知
    let notify_count = filtered_jobs.len();
    if notify_count > 0 {
        let _ = app.emit("offermate://jobs-scored", &serde_json::json!({
            "count": notify_count,
            "jobs": &filtered_jobs,
        }));

        // 使用 Tauri 通知插件
        use tauri_plugin_notification::NotificationExt;
        let _ = app.notification().builder()
            .title("OfferMate 发现新岗位")
            .body(format!("检测到 {} 个新岗位，点击查看", notify_count))
            .show();
    }

    // Webhook 推送（借鉴 get_jobs 的企业微信推送 + job_feishu_bot 的飞书推送）
    if let Some(url) = webhook_url {
        if !url.is_empty() && !filtered_jobs.is_empty() {
            push_webhook(&url, &filtered_jobs).await;
        }
    }
}

/// 读取 AI 配置
async fn load_ai_config(pool: &SqlitePool) -> (String, String, String, String) {
    let provider = db::get_setting(pool, "ai_provider").await;
    let api_key = db::get_setting(pool, "ai_api_key").await;
    let model = db::get_setting(pool, "ai_model").await;
    let base_url = db::get_setting(pool, "ai_base_url").await;

    let provider = if provider.is_empty() { "ollama".to_string() } else { provider };
    (provider, api_key, model, base_url)
}

// ============================================================
// Webhook 推送（飞书/企业微信兼容格式）
// ============================================================

async fn push_webhook(webhook_url: &str, jobs: &[Job]) {
    // 判断 webhook 类型：飞书 (open.feishu.cn / lark) vs 企业微信 (qyapi.weixin.qq.com)
    let is_feishu = webhook_url.contains("feishu.cn") || webhook_url.contains("lark");

    let payload = if is_feishu {
        build_feishu_payload(jobs)
    } else {
        build_wechat_work_payload(jobs)
    };

    let client = reqwest::Client::new();
    let _ = client
        .post(webhook_url)
        .header("Content-Type", "application/json")
        .json(&payload)
        .timeout(std::time::Duration::from_secs(10))
        .send()
        .await;
}

/// 构建飞书机器人消息体
fn build_feishu_payload(jobs: &[Job]) -> serde_json::Value {
    let mut lines = String::new();
    for (i, job) in jobs.iter().enumerate() {
        lines.push_str(&format!(
            "{}. **{}** - {} | {} | {}\n",
            i + 1,
            job.position,
            job.company,
            job.salary.as_deref().unwrap_or("薪资面议"),
            job.location.as_deref().unwrap_or(""),
        ));
        if let Some(ref url) = job.url {
            lines.push_str(&format!("   [查看详情]({})\n", url));
        }
    }

    serde_json::json!({
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": format!("🔍 OfferMate 发现 {} 个新岗位", jobs.len())
                },
                "template": "blue"
            },
            "elements": [{
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": lines
                }
            }]
        }
    })
}

/// 构建企业微信机器人消息体
fn build_wechat_work_payload(jobs: &[Job]) -> serde_json::Value {
    let mut content = format!("🔍 OfferMate 发现 {} 个新岗位\n\n", jobs.len());
    for (i, job) in jobs.iter().enumerate() {
        content.push_str(&format!(
            "{}. {} - {} | {} | {}\n",
            i + 1,
            job.position,
            job.company,
            job.salary.as_deref().unwrap_or("薪资面议"),
            job.location.as_deref().unwrap_or(""),
        ));
        if let Some(ref url) = job.url {
            content.push_str(&format!("   链接: {}\n", url));
        }
        content.push('\n');
    }

    serde_json::json!({
        "msgtype": "text",
        "text": {
            "content": content
        }
    })
}

// ============================================================
// 监控调度器（借鉴 ai-job-search 的 /scrape 周期抓取思路）
// ============================================================

/// 启动后台监控调度器
/// 每分钟检查一次是否有到期的订阅需要执行，并通过 Tauri 事件通知前端
pub fn start_monitor_scheduler(app: AppHandle) {
    let app_clone = app.clone();
    tauri::async_runtime::spawn(async move {
        loop {
            // 每分钟检查一次
            tokio::time::sleep(std::time::Duration::from_secs(60)).await;

            let pool = match app_clone.try_state::<SqlitePool>() {
                Some(p) => p.inner().clone(),
                None => continue,
            };

            // 查询所有启用的订阅
            let subscriptions: Vec<SubscriptionRow> = match sqlx::query_as(
                "SELECT * FROM job_subscriptions WHERE enabled = 1"
            )
            .fetch_all(&pool).await {
                Ok(rows) => rows,
                Err(_) => continue,
            };

            let now = Utc::now();
            for sub in subscriptions {
                let should_run = match &sub.last_run_at {
                    None => true,
                    Some(last) => {
                        if let Ok(last_dt) = chrono::DateTime::parse_from_rfc3339(last) {
                            let elapsed = now.signed_duration_since(last_dt.with_timezone(&Utc));
                            elapsed.num_minutes() >= sub.interval_minutes
                        } else {
                            true
                        }
                    }
                };

                if should_run {
                    // 通知前端：该订阅需要执行抓取
                    // 前端会指导浏览器扩展去抓取对应搜索页
                    let _ = app_clone.emit("offermate://subscription-due", &serde_json::json!({
                        "subscription_id": sub.id,
                        "name": sub.name,
                        "platform": sub.platform,
                        "keywords": sub.keywords,
                        "companies": sub.companies,
                        "location": sub.location,
                    }));

                    // 更新 last_run_at
                    sqlx::query("UPDATE job_subscriptions SET last_run_at = ? WHERE id = ?")
                        .bind(now.to_rfc3339())
                        .bind(&sub.id)
                        .execute(&pool).await.ok();
                }
            }
        }
    });
}

// ============================================================
// 监控统计
// ============================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitorStats {
    pub total_subscriptions: i64,
    pub active_subscriptions: i64,
    pub total_new_jobs: i64,
    pub jobs_last_24h: i64,
    pub jobs_last_7d: i64,
}

#[tauri::command]
pub async fn get_monitor_stats(pool: tauri::State<'_, SqlitePool>) -> Result<MonitorStats, String> {
    let total_subscriptions: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM job_subscriptions"
    )
    .fetch_one(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;

    let active_subscriptions: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM job_subscriptions WHERE enabled = 1"
    )
    .fetch_one(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;

    let total_new: i64 = sqlx::query_scalar(
        "SELECT COALESCE(SUM(total_new_count), 0) FROM job_subscriptions"
    )
    .fetch_one(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;

    let now = Utc::now();
    let cutoff_24h = (now - chrono::Duration::hours(24)).to_rfc3339();
    let cutoff_7d = (now - chrono::Duration::days(7)).to_rfc3339();

    let jobs_24h: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM jobs WHERE source = 'monitor' AND created_at >= ?"
    )
    .bind(&cutoff_24h)
    .fetch_one(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;

    let jobs_7d: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM jobs WHERE source = 'monitor' AND created_at >= ?"
    )
    .bind(&cutoff_7d)
    .fetch_one(&*pool).await
    .map_err(|e| format!("查询失败: {}", e))?;

    Ok(MonitorStats {
        total_subscriptions,
        active_subscriptions,
        total_new_jobs: total_new,
        jobs_last_24h: jobs_24h,
        jobs_last_7d: jobs_7d,
    })
}
