// AI 调用 Commands
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use chrono::Utc;
use uuid::Uuid;

use crate::ai::{AIProviderFactory, ChatMessage, ResumeAnalysis, MatchResult};
use crate::db;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Conversation {
    pub id: String,
    pub title: String,
    pub mode: String,
    pub messages: serde_json::Value,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(sqlx::FromRow)]
struct ConversationRow {
    id: String,
    title: String,
    mode: String,
    messages: String,
    created_at: String,
    updated_at: String,
}

impl From<ConversationRow> for Conversation {
    fn from(r: ConversationRow) -> Self {
        let messages: serde_json::Value = serde_json::from_str(&r.messages).unwrap_or(serde_json::json!([]));
        Self {
            id: r.id, title: r.title, mode: r.mode, messages,
            created_at: r.created_at, updated_at: r.updated_at,
        }
    }
}

/// 从数据库读取 AI 配置
async fn load_ai_config(pool: &SqlitePool) -> (String, String, String, String) {
    let provider = db::get_setting(pool, "ai_provider").await;
    let api_key = db::get_setting(pool, "ai_api_key").await;
    let model = db::get_setting(pool, "ai_model").await;
    let base_url = db::get_setting(pool, "ai_base_url").await;

    let provider = if provider.is_empty() { "ollama".to_string() } else { provider };
    (provider, api_key, model, base_url)
}

/// AI 对话
#[tauri::command]
pub async fn ai_chat(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<String, String> {
    let (provider_type, api_key, model, base_url) = load_ai_config(&*pool).await;

    let messages: Vec<ChatMessage> = input["messages"]
        .as_array()
        .map(|arr| {
            arr.iter().filter_map(|m| {
                Some(ChatMessage {
                    role: m["role"].as_str()?.to_string(),
                    content: m["content"].as_str()?.to_string(),
                })
            }).collect()
        })
        .unwrap_or_default();

    if messages.is_empty() {
        return Err("消息不能为空".to_string());
    }

    let provider = AIProviderFactory::create(&provider_type, &api_key, &model, &base_url);
    provider.chat(messages).await
}

/// AI 简历分析
#[tauri::command]
pub async fn ai_analyze_resume(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<ResumeAnalysis, String> {
    let (provider_type, api_key, model, base_url) = load_ai_config(&*pool).await;

    // 如果有 resume_id，从数据库获取简历内容
    let resume_content = if let Some(resume_id) = input["resume_id"].as_str() {
        sqlx::query_scalar("SELECT content FROM resumes WHERE id = ?")
            .bind(resume_id).fetch_optional(&*pool).await
            .map_err(|e| format!("查询失败: {}", e))?
            .ok_or("简历不存在")?
    } else {
        input["resume_content"].as_str().unwrap_or("").to_string()
    };

    let job_desc = input["job_description"].as_str().or_else(|| input["job_desc"].as_str()).unwrap_or("").to_string();

    let provider = AIProviderFactory::create(&provider_type, &api_key, &model, &base_url);
    provider.analyze_resume(&resume_content, &job_desc).await
}

/// AI 模拟面试
#[tauri::command]
pub async fn ai_mock_interview(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<String, String> {
    let (provider_type, api_key, model, base_url) = load_ai_config(&*pool).await;

    let role = input["position"].as_str().or_else(|| input["role"].as_str()).unwrap_or("通用岗位").to_string();

    let messages: Vec<ChatMessage> = input["messages"]
        .as_array()
        .map(|arr| {
            arr.iter().filter_map(|m| {
                Some(ChatMessage {
                    role: m["role"].as_str()?.to_string(),
                    content: m["content"].as_str()?.to_string(),
                })
            }).collect()
        })
        .unwrap_or_default();

    let provider = AIProviderFactory::create(&provider_type, &api_key, &model, &base_url);
    provider.mock_interview(&role, messages).await
}

/// AI 岗位匹配
#[tauri::command]
pub async fn ai_match_job(
    pool: tauri::State<'_, SqlitePool>,
    input: serde_json::Value,
) -> Result<MatchResult, String> {
    let (provider_type, api_key, model, base_url) = load_ai_config(&*pool).await;

    // 获取简历内容
    let resume_content = if let Some(resume_id) = input["resume_id"].as_str() {
        sqlx::query_scalar("SELECT content FROM resumes WHERE id = ?")
            .bind(resume_id).fetch_optional(&*pool).await
            .map_err(|e| format!("查询失败: {}", e))?
            .ok_or("简历不存在")?
    } else {
        input["resume_content"].as_str().unwrap_or("").to_string()
    };

    // 获取岗位描述
    let job_desc = if let Some(job_id) = input["job_id"].as_str() {
        let desc: Option<String> = sqlx::query_scalar("SELECT description FROM jobs WHERE id = ?")
            .bind(job_id).fetch_optional(&*pool).await
            .map_err(|e| format!("查询失败: {}", e))?
            .ok_or("岗位不存在")?;
        desc.unwrap_or_default()
    } else {
        input["job_description"].as_str().or_else(|| input["job_desc"].as_str()).unwrap_or("").to_string()
    };

    let provider = AIProviderFactory::create(&provider_type, &api_key, &model, &base_url);
    provider.match_job(&resume_content, &job_desc).await
}

/// 保存 AI 对话
#[tauri::command]
pub async fn save_conversation(
    pool: tauri::State<'_, SqlitePool>,
    conversation: serde_json::Value,
) -> Result<Conversation, String> {
    let id = conversation["id"].as_str().unwrap_or(&Uuid::new_v4().to_string()).to_string();
    let title = conversation["title"].as_str().unwrap_or("未命名对话").to_string();
    let mode = conversation["mode"].as_str().unwrap_or("optimize").to_string();
    let now = Utc::now().to_rfc3339();
    let messages = serde_json::to_string(&conversation["messages"].clone()).unwrap_or_else(|_| "[]".to_string());

    sqlx::query("INSERT OR REPLACE INTO ai_conversations (id, title, mode, messages, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)")
        .bind(&id).bind(&title).bind(&mode).bind(&messages).bind(&now).bind(&now)
        .execute(&*pool).await.map_err(|e| format!("保存失败: {}", e))?;

    let row: ConversationRow = sqlx::query_as("SELECT * FROM ai_conversations WHERE id = ?")
        .bind(&id).fetch_one(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(row.into())
}

/// 列出 AI 对话历史
#[tauri::command]
pub async fn list_conversations(pool: tauri::State<'_, SqlitePool>) -> Result<Vec<Conversation>, String> {
    let rows: Vec<ConversationRow> = sqlx::query_as("SELECT * FROM ai_conversations ORDER BY updated_at DESC")
        .fetch_all(&*pool).await.map_err(|e| format!("查询失败: {}", e))?;
    Ok(rows.into_iter().map(|r| r.into()).collect())
}
