pub mod applications;
pub mod resumes;
pub mod jobs;
pub mod notes;
pub mod ai;
pub mod settings;
pub mod server;
pub mod monitor;
