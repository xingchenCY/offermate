// 设置管理 Commands
use sqlx::SqlitePool;
use serde::{Deserialize, Serialize};
use crate::ai::AIProviderFactory;
use crate::db;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppSettings {
    pub theme: String,
    pub ai: AISettings,
    pub auto_save: bool,
    pub notification_enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AISettings {
    pub provider: String,
    pub api_key: String,
    pub model: String,
    pub base_url: String,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            theme: "system".to_string(),
            ai: AISettings {
                provider: "ollama".to_string(),
                api_key: String::new(),
                model: "llama3".to_string(),
                base_url: "http://localhost:11434".to_string(),
            },
            auto_save: true,
            notification_enabled: true,
        }
    }
}

/// 读取设置
#[tauri::command]
pub async fn load_settings(pool: tauri::State<'_, SqlitePool>) -> Result<AppSettings, String> {
    let p: &SqlitePool = &pool;

    let theme = db::get_setting(p, "theme").await;
    let ai_provider = db::get_setting(p, "ai_provider").await;
    let ai_api_key = db::get_setting(p, "ai_api_key").await;
    let ai_model = db::get_setting(p, "ai_model").await;
    let ai_base_url = db::get_setting(p, "ai_base_url").await;
    let auto_save = db::get_setting(p, "auto_save").await;
    let notification_enabled = db::get_setting(p, "notification_enabled").await;

    Ok(AppSettings {
        theme: if theme.is_empty() { "system".to_string() } else { theme },
        ai: AISettings {
            provider: if ai_provider.is_empty() { "ollama".to_string() } else { ai_provider },
            api_key: ai_api_key,
            model: if ai_model.is_empty() { "llama3".to_string() } else { ai_model },
            base_url: if ai_base_url.is_empty() { "http://localhost:11434".to_string() } else { ai_base_url },
        },
        auto_save: auto_save != "false" && auto_save != "0",
        notification_enabled: notification_enabled != "false" && notification_enabled != "0",
    })
}

/// 保存设置
#[tauri::command]
pub async fn save_settings(
    pool: tauri::State<'_, SqlitePool>,
    settings: AppSettings,
) -> Result<AppSettings, String> {
    let pairs = [
        ("theme", settings.theme.clone()),
        ("ai_provider", settings.ai.provider.clone()),
        ("ai_api_key", settings.ai.api_key.clone()),
        ("ai_model", settings.ai.model.clone()),
        ("ai_base_url", settings.ai.base_url.clone()),
        ("auto_save", settings.auto_save.to_string()),
        ("notification_enabled", settings.notification_enabled.to_string()),
    ];

    for (key, value) in &pairs {
        sqlx::query("INSERT OR REPLACE INTO settings (key, value, encrypted) VALUES (?, ?, 0)")
            .bind(key).bind(value)
            .execute(&*pool).await
            .map_err(|e| format!("保存设置失败: {}", e))?;
    }

    Ok(settings)
}

/// 测试 AI 连接
#[tauri::command]
pub async fn test_ai_connection(pool: tauri::State<'_, SqlitePool>) -> Result<bool, String> {
    let p: &SqlitePool = &pool;

    let provider = db::get_setting(p, "ai_provider").await;
    let api_key = db::get_setting(p, "ai_api_key").await;
    let model = db::get_setting(p, "ai_model").await;
    let base_url = db::get_setting(p, "ai_base_url").await;

    let provider = if provider.is_empty() { "ollama".to_string() } else { provider };
    let ai = AIProviderFactory::create(&provider, &api_key, &model, &base_url);

    let test_msg = vec![crate::ai::ChatMessage {
        role: "user".to_string(),
        content: "你好，请回复'连接成功'四个字。".to_string(),
    }];

    match ai.chat(test_msg).await {
        Ok(_) => Ok(true),
        Err(e) => Err(format!("连接失败: {}", e)),
    }
}

/// 导出所有数据
#[tauri::command]
pub async fn export_data(pool: tauri::State<'_, SqlitePool>) -> Result<String, String> {
    use sqlx::Row;

    let apps_rows = sqlx::query("SELECT * FROM applications")
        .fetch_all(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    let applications: Vec<serde_json::Value> = apps_rows.iter().map(|r| serde_json::json!({
        "id": r.try_get::<String, _>("id").unwrap_or_default(),
        "company": r.try_get::<String, _>("company").unwrap_or_default(),
        "position": r.try_get::<String, _>("position").unwrap_or_default(),
        "job_url": r.try_get::<Option<String>, _>("job_url").ok().flatten(),
        "salary": r.try_get::<Option<String>, _>("salary").ok().flatten(),
        "location": r.try_get::<Option<String>, _>("location").ok().flatten(),
        "source": r.try_get::<String, _>("source").unwrap_or_default(),
        "status": r.try_get::<String, _>("status").unwrap_or_default(),
        "priority": r.try_get::<String, _>("priority").unwrap_or_default(),
        "applied_at": r.try_get::<Option<String>, _>("applied_at").ok().flatten(),
        "next_interview_at": r.try_get::<Option<String>, _>("next_interview_at").ok().flatten(),
        "notes": r.try_get::<Option<String>, _>("notes").ok().flatten(),
        "job_id": r.try_get::<Option<String>, _>("job_id").ok().flatten(),
        "resume_id": r.try_get::<Option<String>, _>("resume_id").ok().flatten(),
        "created_at": r.try_get::<String, _>("created_at").unwrap_or_default(),
        "updated_at": r.try_get::<String, _>("updated_at").unwrap_or_default(),
    })).collect();

    let jobs_rows = sqlx::query("SELECT * FROM jobs")
        .fetch_all(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    let jobs: Vec<serde_json::Value> = jobs_rows.iter().map(|r| serde_json::json!({
        "id": r.try_get::<String, _>("id").unwrap_or_default(),
        "company": r.try_get::<String, _>("company").unwrap_or_default(),
        "position": r.try_get::<String, _>("position").unwrap_or_default(),
        "url": r.try_get::<Option<String>, _>("url").ok().flatten(),
        "salary": r.try_get::<Option<String>, _>("salary").ok().flatten(),
        "location": r.try_get::<Option<String>, _>("location").ok().flatten(),
        "description": r.try_get::<Option<String>, _>("description").ok().flatten(),
        "source": r.try_get::<Option<String>, _>("source").ok().flatten(),
        "match_score": r.try_get::<Option<f64>, _>("match_score").ok().flatten(),
        "tags": r.try_get::<Option<String>, _>("tags").ok().flatten(),
        "created_at": r.try_get::<String, _>("created_at").unwrap_or_default(),
    })).collect();

    let notes_rows = sqlx::query("SELECT * FROM notes")
        .fetch_all(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    let notes: Vec<serde_json::Value> = notes_rows.iter().map(|r| serde_json::json!({
        "id": r.try_get::<String, _>("id").unwrap_or_default(),
        "title": r.try_get::<String, _>("title").unwrap_or_default(),
        "content": r.try_get::<String, _>("content").unwrap_or_default(),
        "tags": r.try_get::<Option<String>, _>("tags").ok().flatten(),
        "category": r.try_get::<String, _>("category").unwrap_or_default(),
        "application_id": r.try_get::<Option<String>, _>("application_id").ok().flatten(),
        "created_at": r.try_get::<String, _>("created_at").unwrap_or_default(),
        "updated_at": r.try_get::<String, _>("updated_at").unwrap_or_default(),
    })).collect();

    let resumes_rows = sqlx::query("SELECT * FROM resumes")
        .fetch_all(&*pool).await
        .map_err(|e| format!("查询失败: {}", e))?;
    let resumes: Vec<serde_json::Value> = resumes_rows.iter().map(|r| {
        let is_primary: i64 = r.try_get::<i64, _>("is_primary").unwrap_or(0);
        serde_json::json!({
            "id": r.try_get::<String, _>("id").unwrap_or_default(),
            "name": r.try_get::<String, _>("name").unwrap_or_default(),
            "template": r.try_get::<String, _>("template").unwrap_or_default(),
            "content": r.try_get::<String, _>("content").unwrap_or_default(),
            "is_primary": is_primary != 0,
            "created_at": r.try_get::<String, _>("created_at").unwrap_or_default(),
            "updated_at": r.try_get::<String, _>("updated_at").unwrap_or_default(),
        })
    }).collect();

    let export = serde_json::json!({
        "version": "1.0.0",
        "exported_at": chrono::Utc::now().to_rfc3339(),
        "applications": applications,
        "jobs": jobs,
        "notes": notes,
        "resumes": resumes,
    });

    serde_json::to_string_pretty(&export).map_err(|e| format!("序列化失败: {}", e))
}

/// 导入数据
#[tauri::command]
pub async fn import_data(
    pool: tauri::State<'_, SqlitePool>,
    data: String,
) -> Result<(), String> {
    let import: serde_json::Value = serde_json::from_str(&data).map_err(|e| format!("JSON 解析失败: {}", e))?;

    // 导入 applications
    if let Some(apps) = import["applications"].as_array() {
        for app in apps {
            let id = app["id"].as_str().unwrap_or(&uuid::Uuid::new_v4().to_string()).to_string();
            let now = chrono::Utc::now().to_rfc3339();
            sqlx::query("INSERT OR REPLACE INTO applications (id, company, position, job_url, salary, location, source, status, priority, applied_at, next_interview_at, notes, job_id, resume_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
                .bind(&id)
                .bind(app["company"].as_str().unwrap_or(""))
                .bind(app["position"].as_str().unwrap_or(""))
                .bind(app["job_url"].as_str())
                .bind(app["salary"].as_str())
                .bind(app["location"].as_str())
                .bind(app["source"].as_str().unwrap_or("manual"))
                .bind(app["status"].as_str().unwrap_or("saved"))
                .bind(app["priority"].as_str().unwrap_or("none"))
                .bind(app["applied_at"].as_str())
                .bind(app["next_interview_at"].as_str())
                .bind(app["notes"].as_str())
                .bind(app["job_id"].as_str())
                .bind(app["resume_id"].as_str())
                .bind(app["created_at"].as_str().unwrap_or(&now))
                .bind(app["updated_at"].as_str().unwrap_or(&now))
                .execute(&*pool).await.ok();
        }
    }

    Ok(())
}

/// 清空所有数据
#[tauri::command]
pub async fn clear_data(pool: tauri::State<'_, SqlitePool>) -> Result<(), String> {
    sqlx::query("DELETE FROM status_logs").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM applications").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM sub_resumes").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM resumes").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM jobs").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM notes").execute(&*pool).await.ok();
    sqlx::query("DELETE FROM ai_conversations").execute(&*pool).await.ok();
    Ok(())
}
