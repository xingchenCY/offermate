//! OfferMate 求职管家 - Tauri 后端库
//!
//! 负责：
//! - SQLite 数据库初始化与迁移
//! - 注册所有 Tauri commands
//! - 启动浏览器扩展导入服务

mod ai;
mod commands;
mod state_machine;
mod db;

use sqlx::sqlite::SqlitePool;
use tauri::Manager;

/// 数据库连接池在 Tauri 状态中的 key
pub const DB_STATE_KEY: &str = "offermate_db_pool";

/// 应用启动入口
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_store::Builder::default().build())
        .setup(|app| {
            // 获取应用数据目录
            let app_data_dir = app
                .path()
                .app_data_dir()
                .expect("无法获取应用数据目录");

            // 确保目录存在
            std::fs::create_dir_all(&app_data_dir)
                .expect("无法创建应用数据目录");

            // 数据库文件路径
            let db_path = app_data_dir.join("offermate.db");
            let db_url = format!(
                "sqlite://{}?mode=rwc",
                db_path.to_string_lossy()
            );

            // 初始化数据库连接池（同步阻塞，在 setup 中是允许的）
            let pool = tauri::async_runtime::block_on(async {
                db::init_database(&db_url).await
            })
            .expect("数据库初始化失败");

            // 将连接池存入 Tauri 状态
            app.manage(pool);

            // 启动浏览器扩展导入服务
            let app_handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = commands::server::start_import_server_async(app_handle).await {
                    eprintln!("[OfferMate] 导入服务启动失败: {}", e);
                }
            });

            // 启动岗位监控调度器
            commands::monitor::start_monitor_scheduler(app.handle().clone());

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            // Applications
            commands::applications::list_applications,
            commands::applications::get_application,
            commands::applications::create_application,
            commands::applications::update_application,
            commands::applications::delete_application,
            commands::applications::transition_status,
            commands::applications::get_timeline,
            commands::applications::get_stats,
            // Resumes
            commands::resumes::list_resumes,
            commands::resumes::get_resume,
            commands::resumes::create_resume,
            commands::resumes::update_resume,
            commands::resumes::delete_resume,
            commands::resumes::list_sub_resumes,
            commands::resumes::create_sub_resume,
            commands::resumes::delete_sub_resume,
            // Jobs
            commands::jobs::list_jobs,
            commands::jobs::create_job,
            commands::jobs::delete_job,
            commands::jobs::import_jobs,
            commands::jobs::search_jobs,
            commands::jobs::list_recent_jobs,
            // Monitor
            commands::monitor::list_subscriptions,
            commands::monitor::create_subscription,
            commands::monitor::update_subscription,
            commands::monitor::delete_subscription,
            commands::monitor::toggle_subscription,
            commands::monitor::import_batch_jobs,
            commands::monitor::get_monitor_stats,
            // Notes
            commands::notes::list_notes,
            commands::notes::create_note,
            commands::notes::update_note,
            commands::notes::delete_note,
            // AI
            commands::ai::ai_chat,
            commands::ai::ai_analyze_resume,
            commands::ai::ai_mock_interview,
            commands::ai::ai_match_job,
            commands::ai::save_conversation,
            commands::ai::list_conversations,
            // Settings
            commands::settings::load_settings,
            commands::settings::save_settings,
            commands::settings::test_ai_connection,
            commands::settings::export_data,
            commands::settings::import_data,
            commands::settings::clear_data,
            // Server
            commands::server::start_import_server,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
