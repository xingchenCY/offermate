// DeepSeek AI Provider 实现
use crate::ai::provider::{ChatMessage, ResumeAnalysis, MatchResult, AIProvider};
use crate::ai::openai::{ChatResponse, build_system_prompt};

pub struct DeepSeekProvider {
    client: reqwest::Client,
    api_key: String,
    model: String,
    base_url: String,
}

impl DeepSeekProvider {
    pub fn new(api_key: String, model: String, base_url: String) -> Self {
        let base = if base_url.is_empty() {
            "https://api.deepseek.com/v1".to_string()
        } else {
            base_url
        };
        Self {
            client: reqwest::Client::new(),
            api_key,
            model: if model.is_empty() { "deepseek-chat".to_string() } else { model },
            base_url: base,
        }
    }
}

#[async_trait::async_trait]
impl AIProvider for DeepSeekProvider {
    fn name(&self) -> &str {
        "DeepSeek"
    }

    async fn chat(&self, messages: Vec<ChatMessage>) -> Result<String, String> {
        let body = serde_json::json!({
            "model": self.model,
            "messages": messages.iter().map(|m| {
                serde_json::json!({"role": m.role, "content": m.content})
            }).collect::<Vec<_>>()
        });

        let resp = self
            .client
            .post(format!("{}/chat/completions", self.base_url))
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("请求失败: {}", e))?;

        if !resp.status().is_success() {
            let text = resp.text().await.unwrap_or_default();
            return Err(format!("DeepSeek API 错误: {}", text));
        }

        let data: ChatResponse = resp.json().await.map_err(|e| format!("解析失败: {}", e))?;
        Ok(data.choices.first()
            .map(|c| c.message.content.clone())
            .unwrap_or_default())
    }

    async fn analyze_resume(&self, resume_content: &str, job_desc: &str) -> Result<ResumeAnalysis, String> {
        let messages = vec![
            ChatMessage { role: "system".to_string(), content: build_system_prompt("analyze_resume") },
            ChatMessage { role: "user".to_string(), content: format!("简历内容:\n{}\n\n职位描述:\n{}", resume_content, job_desc) },
        ];
        let result = self.chat(messages).await?;
        serde_json::from_str(result.trim()).map_err(|e| format!("JSON 解析失败: {}", e))
    }

    async fn mock_interview(&self, role: &str, messages: Vec<ChatMessage>) -> Result<String, String> {
        let mut all = vec![ChatMessage { role: "system".to_string(), content: format!("{} 面试岗位: {}", build_system_prompt("mock_interview"), role) }];
        all.extend(messages);
        self.chat(all).await
    }

    async fn match_job(&self, resume_content: &str, job_desc: &str) -> Result<MatchResult, String> {
        let messages = vec![
            ChatMessage { role: "system".to_string(), content: build_system_prompt("match_job") },
            ChatMessage { role: "user".to_string(), content: format!("简历:\n{}\n\n岗位:\n{}", resume_content, job_desc) },
        ];
        let result = self.chat(messages).await?;
        serde_json::from_str(result.trim()).map_err(|e| format!("JSON 解析失败: {}", e))
    }
}
