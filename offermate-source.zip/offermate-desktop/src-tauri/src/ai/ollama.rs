// Ollama 本地模型 Provider 实现
use crate::ai::provider::{ChatMessage, ResumeAnalysis, MatchResult, AIProvider};
use crate::ai::openai::build_system_prompt;
use serde::Deserialize;

pub struct OllamaProvider {
    client: reqwest::Client,
    model: String,
    base_url: String,
}

impl OllamaProvider {
    pub fn new(model: String, base_url: String) -> Self {
        Self {
            client: reqwest::Client::new(),
            model: if model.is_empty() { "llama3".to_string() } else { model },
            base_url: if base_url.is_empty() { "http://localhost:11434".to_string() } else { base_url },
        }
    }
}

#[derive(Deserialize)]
struct OllamaResponse {
    message: OllamaMessage,
}
#[derive(Deserialize)]
struct OllamaMessage {
    content: String,
}

#[async_trait::async_trait]
impl AIProvider for OllamaProvider {
    fn name(&self) -> &str {
        "Ollama (本地)"
    }

    async fn chat(&self, messages: Vec<ChatMessage>) -> Result<String, String> {
        let body = serde_json::json!({
            "model": self.model,
            "messages": messages.iter().map(|m| {
                serde_json::json!({"role": m.role, "content": m.content})
            }).collect::<Vec<_>>(),
            "stream": false
        });

        let resp = self
            .client
            .post(format!("{}/api/chat", self.base_url))
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("Ollama 请求失败: {}。请确认 Ollama 已在本地运行。", e))?;

        if !resp.status().is_success() {
            let text = resp.text().await.unwrap_or_default();
            return Err(format!("Ollama 返回错误: {}", text));
        }

        let data: OllamaResponse = resp.json().await.map_err(|e| format!("解析失败: {}", e))?;
        Ok(data.message.content)
    }

    async fn analyze_resume(&self, resume_content: &str, job_desc: &str) -> Result<ResumeAnalysis, String> {
        let messages = vec![
            ChatMessage { role: "system".to_string(), content: build_system_prompt("analyze_resume") },
            ChatMessage { role: "user".to_string(), content: format!("简历内容:\n{}\n\n职位描述:\n{}", resume_content, job_desc) },
        ];
        let result = self.chat(messages).await?;
        serde_json::from_str(result.trim()).map_err(|e| format!("JSON 解析失败: {}, 原始: {}", e, result))
    }

    async fn mock_interview(&self, role: &str, messages: Vec<ChatMessage>) -> Result<String, String> {
        let mut all = vec![ChatMessage { role: "system".to_string(), content: format!("{} 面试岗位: {}", build_system_prompt("mock_interview"), role) }];
        all.extend(messages);
        self.chat(all).await
    }

    async fn match_job(&self, resume_content: &str, job_desc: &str) -> Result<MatchResult, String> {
        let messages = vec![
            ChatMessage { role: "system".to_string(), content: build_system_prompt("match_job") },
            ChatMessage { role: "user".to_string(), content: format!("简历:\n{}\n\n岗位:\n{}", resume_content, job_desc) },
        ];
        let result = self.chat(messages).await?;
        serde_json::from_str(result.trim()).map_err(|e| format!("JSON 解析失败: {}, 原始: {}", e, result))
    }
}
