pub mod provider;
pub mod openai;
pub mod deepseek;
pub mod ollama;

pub use provider::{
    AIProvider, AIProviderFactory, ChatMessage, ResumeAnalysis, MatchResult,
};
