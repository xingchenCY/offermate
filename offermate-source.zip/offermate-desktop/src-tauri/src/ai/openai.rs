use crate::ai::provider::{ChatMessage, ResumeAnalysis, MatchResult, AIProvider};
use serde::Deserialize;

pub struct OpenAIProvider {
    client: reqwest::Client,
    api_key: String,
    model: String,
    base_url: String,
}

impl OpenAIProvider {
    pub fn new(api_key: String, model: String, base_url: String) -> Self {
        let base = if base_url.is_empty() {
            "https://api.openai.com/v1".to_string()
        } else {
            base_url
        };
        Self {
            client: reqwest::Client::new(),
            api_key,
            model: if model.is_empty() { "gpt-4o".to_string() } else { model },
            base_url: base,
        }
    }
}

#[derive(Deserialize)]
pub struct ChatResponse {
    pub choices: Vec<ChatChoice>,
}
#[derive(Deserialize)]
pub struct ChatChoice {
    pub message: ChatResponseMessage,
}
#[derive(Deserialize)]
pub struct ChatResponseMessage {
    pub content: String,
}

pub fn build_system_prompt(task: &str) -> String {
    match task {
        "analyze_resume" => "你是一个专业的简历分析师。请分析用户提供的简历和职位描述，返回 JSON 格式：{\"score\":0-100,\"strengths\":[],\"weaknesses\":[],\"suggestions\":[]}。用中文回答。".to_string(),
        "mock_interview" => "你是一个面试官。请根据岗位要求提出面试问题，评估用户的回答，并给出反馈。用中文交流。".to_string(),
        "match_job" => "你是一个岗位匹配分析师。请分析简历与岗位的匹配度，返回 JSON：{\"score\":0-100,\"reasons\":[]}。用中文回答。".to_string(),
        _ => "你是一个有帮助的求职助手。用中文回答。".to_string(),
    }
}

#[async_trait::async_trait]
impl AIProvider for OpenAIProvider {
    fn name(&self) -> &str {
        "OpenAI"
    }

    async fn chat(&self, messages: Vec<ChatMessage>) -> Result<String, String> {
        let body = serde_json::json!({
            "model": self.model,
            "messages": messages.iter().map(|m| {
                serde_json::json!({"role": m.role, "content": m.content})
            }).collect::<Vec<_>>()
        });

        let resp = self
            .client
            .post(format!("{}/chat/completions", self.base_url))
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("请求失败: {}", e))?;

        if !resp.status().is_success() {
            let text = resp.text().await.unwrap_or_default();
            return Err(format!("API 返回错误: {}", text));
        }

        let data: ChatResponse = resp.json().await.map_err(|e| format!("解析失败: {}", e))?;
        Ok(data.choices.first()
            .map(|c| c.message.content.clone())
            .unwrap_or_default())
    }

    async fn analyze_resume(
        &self,
        resume_content: &str,
        job_desc: &str,
    ) -> Result<ResumeAnalysis, String> {
        let messages = vec![
            ChatMessage {
                role: "system".to_string(),
                content: build_system_prompt("analyze_resume"),
            },
            ChatMessage {
                role: "user".to_string(),
                content: format!("简历内容:\n{}\n\n职位描述:\n{}", resume_content, job_desc),
            },
        ];

        let result = self.chat(messages).await?;
        let parsed: ResumeAnalysis = serde_json::from_str(result.trim())
            .map_err(|e| format!("JSON 解析失败: {}, 原始: {}", e, result))?;
        Ok(parsed)
    }

    async fn mock_interview(
        &self,
        role: &str,
        messages: Vec<ChatMessage>,
    ) -> Result<String, String> {
        let mut all_messages = vec![ChatMessage {
            role: "system".to_string(),
            content: format!("{} 面试岗位: {}", build_system_prompt("mock_interview"), role),
        }];
        all_messages.extend(messages);
        self.chat(all_messages).await
    }

    async fn match_job(
        &self,
        resume_content: &str,
        job_desc: &str,
    ) -> Result<MatchResult, String> {
        let messages = vec![
            ChatMessage {
                role: "system".to_string(),
                content: build_system_prompt("match_job"),
            },
            ChatMessage {
                role: "user".to_string(),
                content: format!("简历:\n{}\n\n岗位:\n{}", resume_content, job_desc),
            },
        ];

        let result = self.chat(messages).await?;
        let parsed: MatchResult = serde_json::from_str(result.trim())
            .map_err(|e| format!("JSON 解析失败: {}, 原始: {}", e, result))?;
        Ok(parsed)
    }
}
