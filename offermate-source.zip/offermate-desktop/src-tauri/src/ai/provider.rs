use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: String,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResumeAnalysis {
    pub score: f64,
    pub strengths: Vec<String>,
    pub weaknesses: Vec<String>,
    pub suggestions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchResult {
    pub score: f64,
    pub reasons: Vec<String>,
}

/// AI Provider 抽象 trait
#[async_trait::async_trait]
pub trait AIProvider: Send + Sync {
    async fn chat(&self, messages: Vec<ChatMessage>) -> Result<String, String>;
    async fn analyze_resume(
        &self,
        resume_content: &str,
        job_desc: &str,
    ) -> Result<ResumeAnalysis, String>;
    async fn mock_interview(
        &self,
        role: &str,
        messages: Vec<ChatMessage>,
    ) -> Result<String, String>;
    async fn match_job(
        &self,
        resume_content: &str,
        job_desc: &str,
    ) -> Result<MatchResult, String>;
    fn name(&self) -> &str;
}

/// AI Provider 工厂
pub struct AIProviderFactory;

impl AIProviderFactory {
    /// 根据配置创建 provider
    pub fn create(
        provider_type: &str,
        api_key: &str,
        model: &str,
        base_url: &str,
    ) -> Box<dyn AIProvider> {
        match provider_type {
            "openai" => Box::new(crate::ai::openai::OpenAIProvider::new(
                api_key.to_string(),
                model.to_string(),
                base_url.to_string(),
            )),
            "deepseek" => Box::new(crate::ai::deepseek::DeepSeekProvider::new(
                api_key.to_string(),
                model.to_string(),
                base_url.to_string(),
            )),
            "ollama" => Box::new(crate::ai::ollama::OllamaProvider::new(
                model.to_string(),
                base_url.to_string(),
            )),
            _ => Box::new(crate::ai::ollama::OllamaProvider::new(
                "llama3".to_string(),
                "http://localhost:11434".to_string(),
            )),
        }
    }
}
