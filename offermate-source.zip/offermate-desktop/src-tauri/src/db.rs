//! 数据库初始化与迁移模块
//!
//! 使用 sqlx 直接管理 SQLite 连接池，不依赖 tauri-plugin-sql。

use sqlx::sqlite::{SqlitePool, SqlitePoolOptions, SqliteRow};
use sqlx::Row;

/// 初始化数据库：创建连接池 + 执行建表 SQL
pub async fn init_database(db_url: &str) -> Result<SqlitePool, String> {
    let pool = SqlitePoolOptions::new()
        .max_connections(5)
        .connect(db_url)
        .await
        .map_err(|e| format!("数据库连接失败: {}", e))?;

    // 启用外键约束
    sqlx::query("PRAGMA foreign_keys = ON")
        .execute(&pool)
        .await
        .map_err(|e| format!("启用外键失败: {}", e))?;

    // 执行建表 SQL
    run_migrations(&pool).await?;

    Ok(pool)
}

/// 运行数据库迁移
async fn run_migrations(pool: &SqlitePool) -> Result<(), String> {
    // 001: 初始 schema
    let schema = include_str!("../migrations/001_init.sql");
    sqlx::query(schema)
        .execute(pool)
        .await
        .map_err(|e| format!("数据库迁移失败: {}", e))?;

    // 002: 监控模块
    let monitor_schema = include_str!("../migrations/002_monitor.sql");
    sqlx::query(monitor_schema)
        .execute(pool)
        .await
        .map_err(|e| format!("监控模块迁移失败: {}", e))?;

    // 对 jobs 表做容错的 ALTER TABLE（列可能已存在）
    alter_table_add_columns_if_not_exists(
        pool,
        "jobs",
        &[
            ("posted_at", "TEXT"),
            ("is_remote", "INTEGER DEFAULT 0"),
            ("requirements", "TEXT"),
        ],
    )
    .await?;

    Ok(())
}

/// 安全地为已有表添加列：SQLite 不支持 ADD COLUMN IF NOT EXISTS，
/// 此函数先检查 PRAGMA table_info，仅在列不存在时执行 ALTER TABLE。
async fn alter_table_add_columns_if_not_exists(
    pool: &SqlitePool,
    table: &str,
    columns: &[(&str, &str)],
) -> Result<(), String> {
    let pragma_sql = format!("PRAGMA table_info({})", table);
    let rows = sqlx::query(&pragma_sql)
        .fetch_all(pool)
        .await
        .map_err(|e| format!("查询 {} 表信息失败: {}", table, e))?;

    let existing: std::collections::HashSet<String> = rows
        .iter()
        .map(|r| r.try_get::<String, _>("name").unwrap_or_default())
        .collect();

    for (col_name, col_def) in columns {
        if !existing.contains(*col_name) {
            let sql = format!("ALTER TABLE {} ADD COLUMN {} {}", table, col_name, col_def);
            sqlx::query(&sql)
                .execute(pool)
                .await
                .map_err(|e| format!("添加列 {}.{} 失败: {}", table, col_name, e))?;
            println!("[OfferMate] 已添加列 {}.{}", table, col_name);
        }
    }

    Ok(())
}

/// 读取单个设置值
pub async fn get_setting(pool: &SqlitePool, key: &str) -> String {
    let row = sqlx::query("SELECT value FROM settings WHERE key = ?")
        .bind(key)
        .fetch_optional(pool)
        .await
        .ok()
        .flatten();

    row.map(|r: SqliteRow| r.get::<String, _>("value"))
        .unwrap_or_default()
}

/// 写入单个设置值
pub async fn set_setting(pool: &SqlitePool, key: &str, value: &str) -> Result<(), String> {
    sqlx::query("INSERT OR REPLACE INTO settings (key, value, encrypted) VALUES (?, ?, 0)")
        .bind(key)
        .bind(value)
        .execute(pool)
        .await
        .map_err(|e| format!("保存设置失败: {}", e))?;
    Ok(())
}

/// 查询单列字符串值（如 SELECT status FROM ...）
pub async fn fetch_one_string(pool: &SqlitePool, sql: &str, bind_val: &str) -> Result<Option<String>, String> {
    let row = sqlx::query(sql)
        .bind(bind_val)
        .fetch_optional(pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))?;

    // 获取第一列
    Ok(row.map(|r: SqliteRow| {
        r.try_get::<String, usize>(0).unwrap_or_default()
    }))
}

/// 查询两列值（如 SELECT id FROM ... WHERE ...）
pub async fn fetch_exists(pool: &SqlitePool, sql: &str, bind1: &str, bind2: &str) -> Result<bool, String> {
    let row = sqlx::query(sql)
        .bind(bind1)
        .bind(bind2)
        .fetch_optional(pool)
        .await
        .map_err(|e| format!("查询失败: {}", e))?;

    Ok(row.is_some())
}
