// 状态机模块 - 投递状态转换逻辑
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ApplicationStatus {
    Saved,
    Applied,
    Written,
    PhoneScreen,
    Onsite,
    Offer,
    Rejected,
    Withdrawn,
}

impl ApplicationStatus {
    /// 从字符串解析状态
    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "saved" => Some(Self::Saved),
            "applied" => Some(Self::Applied),
            "written" => Some(Self::Written),
            "phone_screen" => Some(Self::PhoneScreen),
            "onsite" => Some(Self::Onsite),
            "offer" => Some(Self::Offer),
            "rejected" => Some(Self::Rejected),
            "withdrawn" => Some(Self::Withdrawn),
            _ => None,
        }
    }

    /// 转为 snake_case 字符串
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Saved => "saved",
            Self::Applied => "applied",
            Self::Written => "written",
            Self::PhoneScreen => "phone_screen",
            Self::Onsite => "onsite",
            Self::Offer => "offer",
            Self::Rejected => "rejected",
            Self::Withdrawn => "withdrawn",
        }
    }

    /// 验证状态转换是否合法
    pub fn can_transition_to(&self, next: &Self) -> bool {
        if self == next {
            return false;
        }
        match self {
            Self::Saved => matches!(next, Self::Applied | Self::Withdrawn | Self::Rejected),
            Self::Applied => {
                matches!(next, Self::Written | Self::PhoneScreen | Self::Rejected | Self::Withdrawn)
            }
            Self::Written => matches!(next, Self::PhoneScreen | Self::Onsite | Self::Rejected),
            Self::PhoneScreen => matches!(next, Self::Onsite | Self::Offer | Self::Rejected),
            Self::Onsite => matches!(next, Self::Offer | Self::Rejected),
            Self::Offer => matches!(next, Self::Withdrawn),
            Self::Rejected | Self::Withdrawn => false,
        }
    }

    /// 中文标签
    pub fn label(&self) -> &'static str {
        match self {
            Self::Saved => "已收藏",
            Self::Applied => "已投递",
            Self::Written => "笔试中",
            Self::PhoneScreen => "电话/视频面",
            Self::Onsite => "现场面",
            Self::Offer => "Offer",
            Self::Rejected => "已拒绝",
            Self::Withdrawn => "已撤回",
        }
    }

    /// 看板排序权重
    pub fn sort_order(&self) -> u8 {
        match self {
            Self::Saved => 0,
            Self::Applied => 1,
            Self::Written => 2,
            Self::PhoneScreen => 3,
            Self::Onsite => 4,
            Self::Offer => 5,
            Self::Rejected => 6,
            Self::Withdrawn => 7,
        }
    }

    /// 所有状态列表（按看板顺序）
    pub fn all() -> Vec<&'static str> {
        vec![
            "saved",
            "applied",
            "written",
            "phone_screen",
            "onsite",
            "offer",
            "rejected",
            "withdrawn",
        ]
    }
}
