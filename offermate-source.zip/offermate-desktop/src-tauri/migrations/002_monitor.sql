-- OfferMate 监控模块迁移
-- 借鉴 JobSpy 的 hours_old 过滤 + ai-job-search 的 AI 评估 + job_feishu_bot 的推送闭环

-- ============================================================
-- 1. 扩展 jobs 表：增加发布时间、远程标记、岗位要求
--    （JobSpy JobPost schema 思路：date_posted / is_remote）
-- ============================================================
-- 注意：SQLite 不支持 ADD COLUMN IF NOT EXISTS，需在 Rust 中做容错

-- 2. 岗位订阅规则表（借鉴 get_jobs 的配置化筛选）
CREATE TABLE IF NOT EXISTS job_subscriptions (
    id                TEXT PRIMARY KEY,
    name              TEXT NOT NULL,
    platform          TEXT NOT NULL DEFAULT 'boss',
    keywords          TEXT,
    companies         TEXT,
    location          TEXT,
    salary_min        TEXT,
    salary_max        TEXT,
    is_remote_only    INTEGER DEFAULT 0,
    interval_minutes  INTEGER NOT NULL DEFAULT 60,
    ai_filter_enabled INTEGER DEFAULT 0,
    ai_threshold      REAL DEFAULT 60.0,
    webhook_url       TEXT,
    enabled           INTEGER DEFAULT 1,
    last_run_at       TEXT,
    last_new_count    INTEGER DEFAULT 0,
    total_new_count   INTEGER DEFAULT 0,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_subscriptions_enabled ON job_subscriptions(enabled);

-- 3. 已见岗位缓存（用于去重，借鉴 JobSpy 的增量检测）
CREATE TABLE IF NOT EXISTS job_seen_cache (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    subscription_id TEXT,
    job_key         TEXT NOT NULL,
    seen_at         TEXT NOT NULL,
    FOREIGN KEY (subscription_id) REFERENCES job_subscriptions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_seen_cache_sub ON job_seen_cache(subscription_id);
CREATE INDEX IF NOT EXISTS idx_seen_cache_key ON job_seen_cache(job_key);
