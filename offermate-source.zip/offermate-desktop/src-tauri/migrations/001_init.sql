-- OfferMate 数据库初始化
-- 投递记录表（核心表，状态机驱动）
CREATE TABLE IF NOT EXISTS applications (
    id                 TEXT PRIMARY KEY,
    company            TEXT NOT NULL,
    position           TEXT NOT NULL,
    job_url            TEXT,
    salary             TEXT,
    location           TEXT,
    source             TEXT DEFAULT 'manual',
    status             TEXT NOT NULL DEFAULT 'saved',
    priority           TEXT DEFAULT 'none',
    applied_at         TEXT,
    next_interview_at  TEXT,
    notes              TEXT,
    job_id             TEXT,
    resume_id          TEXT,
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_company ON applications(company);
CREATE INDEX IF NOT EXISTS idx_applications_created ON applications(created_at);

-- 状态变更日志（时间线 + 漏斗统计）
CREATE TABLE IF NOT EXISTS status_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id  TEXT NOT NULL,
    from_status     TEXT,
    to_status       TEXT NOT NULL,
    note            TEXT,
    created_at      TEXT NOT NULL,
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_status_logs_app ON status_logs(application_id);

-- 主简历（content 存储完整 JSON：basic_info, education, experience, projects, skills, awards）
CREATE TABLE IF NOT EXISTS resumes (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    template    TEXT DEFAULT 'modern',
    content     TEXT NOT NULL DEFAULT '{}',
    is_primary  INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

-- 子简历（针对不同岗位定制）
CREATE TABLE IF NOT EXISTS sub_resumes (
    id              TEXT PRIMARY KEY,
    parent_id       TEXT NOT NULL,
    name            TEXT NOT NULL,
    content         TEXT NOT NULL DEFAULT '{}',
    target_company  TEXT,
    target_position TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,
    FOREIGN KEY (parent_id) REFERENCES resumes(id) ON DELETE CASCADE
);

-- 聚合的招聘信息
CREATE TABLE IF NOT EXISTS jobs (
    id            TEXT PRIMARY KEY,
    company       TEXT NOT NULL,
    position      TEXT NOT NULL,
    url           TEXT,
    salary        TEXT,
    location      TEXT,
    description   TEXT,
    source        TEXT,
    match_score   REAL,
    tags          TEXT,
    created_at    TEXT NOT NULL,
    UNIQUE(company, position)
);
CREATE INDEX IF NOT EXISTS idx_jobs_source ON jobs(source);
CREATE INDEX IF NOT EXISTS idx_jobs_company ON jobs(company);

-- 求职笔记/知识库
CREATE TABLE IF NOT EXISTS notes (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    content         TEXT NOT NULL,
    tags            TEXT,
    category        TEXT DEFAULT 'general',
    application_id  TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_category ON notes(category);

-- AI 对话记录
CREATE TABLE IF NOT EXISTS ai_conversations (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    mode        TEXT NOT NULL,
    messages    TEXT NOT NULL DEFAULT '[]',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);

-- 配置（加密存储 API Key 等）
CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    encrypted   INTEGER DEFAULT 0
);
