import { useEffect } from "react";
import { RouterProvider } from "react-router-dom";
import { Toaster } from "sonner";
import { router } from "@/router";
import { useSettingsStore } from "@/stores/settingsStore";
import { TooltipProvider } from "@/components/ui/tooltip";

export function App() {
  const { loaded, loadSettings } = useSettingsStore();

  useEffect(() => {
    if (!loaded) void loadSettings();
  }, [loaded, loadSettings]);

  // 监听系统主题变化（用于 system 模式实时响应）
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => {
      const { settings } = useSettingsStore.getState();
      if (settings.theme === "system") {
        document.documentElement.classList.toggle("dark", mq.matches);
      }
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  return (
    <TooltipProvider delayDuration={200}>
      <RouterProvider router={router} />
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            borderRadius: "8px",
            border: "1px solid hsl(var(--border))",
            background: "hsl(var(--popover))",
            color: "hsl(var(--popover-foreground))",
          },
        }}
      />
    </TooltipProvider>
  );
}
