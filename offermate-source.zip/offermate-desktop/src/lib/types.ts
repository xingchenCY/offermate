/**
 * OfferMate 全局类型定义
 */

/** 投递状态：已收藏 / 已投递 / 已笔试 / 电话面试 / 现场面试 / Offer / 已拒绝 / 已撤回 */
export type ApplicationStatus =
  | "saved"
  | "applied"
  | "written"
  | "phone_screen"
  | "onsite"
  | "offer"
  | "rejected"
  | "withdrawn";

/** 优先级 */
export type Priority = "high" | "medium" | "low" | "none";

/** 岗位来源 */
export type JobSource = "boss" | "zhilian" | "niuke" | "nowcoder" | "manual" | "lagou" | "51job" | "liepin" | "monitor" | "other";

/** 简历模板 */
export type ResumeTemplate = "modern" | "classic" | "minimal" | "tech";

/** 笔记分类 */
export type NoteCategory = "interview" | "tech" | "company" | "general";

/** AI Provider */
export type AIProvider = "openai" | "deepseek" | "ollama";

/** 主题模式 */
export type ThemeMode = "light" | "dark" | "system";

/** AI 对话模式 */
export type AIMode = "optimize" | "interview" | "match";

/** 状态过滤器 */
export type StatusFilter = ApplicationStatus | "all";

/** 来源过滤器 */
export type SourceFilter = JobSource | "all";

/** 优先级过滤器 */
export type PriorityFilter = Priority | "all";

/** 教育经历 */
export interface Education {
  id: string;
  school: string;
  degree: string;
  major: string;
  start_date: string;
  end_date: string;
  gpa?: string;
  description?: string;
}

/** 工作经验 */
export interface Experience {
  id: string;
  company: string;
  position: string;
  start_date: string;
  end_date: string;
  description?: string;
}

/** 项目经历 */
export interface Project {
  id: string;
  name: string;
  role?: string;
  link?: string;
  start_date: string;
  end_date: string;
  description?: string;
  tech_stack?: string[];
}

/** 奖项 */
export interface Award {
  id: string;
  title: string;
  date: string;
  description?: string;
}

/** 基本信息 */
export interface BasicInfo {
  name: string;
  email: string;
  phone: string;
  location: string;
  summary?: string;
  website?: string;
  github?: string;
}

/** 主简历 */
export interface Resume {
  id: string;
  name: string;
  template: ResumeTemplate;
  basic_info: BasicInfo;
  education: Education[];
  experience: Experience[];
  projects: Project[];
  skills: string[];
  awards: Award[];
  is_default?: boolean;
  created_at: string;
  updated_at: string;
}

/** 子简历（针对特定岗位的定制版本） */
export interface SubResume {
  id: string;
  parent_id: string;
  name: string;
  target_company?: string;
  target_position?: string;
  /** 针对主简历的覆盖字段 */
  overrides: Partial<Omit<Resume, "id" | "created_at" | "updated_at">>;
  created_at: string;
  updated_at: string;
}

/** 岗位 */
export interface Job {
  id: string;
  company: string;
  position: string;
  salary?: string;
  location?: string;
  source: JobSource;
  url?: string;
  description?: string;
  match_score?: number;
  tags?: string[];
  created_at: string;
  posted_at?: string;
  is_remote?: boolean;
  requirements?: string;
}

/** 投递记录 */
export interface Application {
  id: string;
  company: string;
  position: string;
  job_url?: string;
  salary?: string;
  location?: string;
  source: JobSource;
  status: ApplicationStatus;
  priority: Priority;
  applied_at?: string;
  next_interview_at?: string;
  notes?: string;
  job_id?: string;
  resume_id?: string;
  created_at: string;
  updated_at: string;
}

/** 笔记 */
export interface Note {
  id: string;
  title: string;
  content: string;
  category: NoteCategory;
  tags: string[];
  application_id?: string;
  created_at: string;
  updated_at: string;
}

/** 聊天消息 */
export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  created_at: string;
  /** 模式标记 */
  mode?: AIMode;
}

/** 对话历史 */
export interface Conversation {
  id: string;
  title: string;
  mode: AIMode;
  messages: ChatMessage[];
  created_at: string;
  updated_at: string;
}

/** 状态变更日志 */
export interface StatusLog {
  id: string;
  application_id: string;
  from_status: ApplicationStatus | null;
  to_status: ApplicationStatus;
  note?: string;
  created_at: string;
}

/** 仪表盘统计 */
export interface DashboardStats {
  total: number;
  saved: number;
  applied: number;
  written: number;
  phone_screen: number;
  onsite: number;
  offer: number;
  rejected: number;
  withdrawn: number;
  interviewing: number;
  conversion_rate: number;
  by_status: Record<ApplicationStatus, number>;
  trend: TrendPoint[];
}

/** 趋势数据点 */
export interface TrendPoint {
  date: string;
  count: number;
  offer_count?: number;
}

/** 简历分析结果 */
export interface ResumeAnalysis {
  score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  keywords?: string[];
}

/** 岗位匹配结果 */
export interface JobMatchResult {
  score: number;
  matched_skills: string[];
  missing_skills: string[];
  reasons: string[];
}

/** AI 配置 */
export interface AIConfig {
  provider: AIProvider;
  api_key: string;
  model: string;
  base_url: string;
}

/** 应用设置 */
export interface AppSettings {
  theme: ThemeMode;
  ai: AIConfig;
  auto_save: boolean;
  notification_enabled: boolean;
}

/** 时间线条目 */
export interface TimelineEntry extends StatusLog {
  application?: Application;
}

/** 创建投递请求 */
export interface CreateApplicationInput {
  company: string;
  position: string;
  job_url?: string;
  salary?: string;
  location?: string;
  source: JobSource;
  status?: ApplicationStatus;
  priority?: Priority;
  next_interview_at?: string;
  notes?: string;
}

/** 更新投递请求 */
export interface UpdateApplicationInput extends Partial<CreateApplicationInput> {
  status?: ApplicationStatus;
  resume_id?: string;
}

/** 状态标签与颜色映射 */
export interface StatusMeta {
  label: string;
  color: string;
  badgeClass: string;
}

/** 状态元数据常量 */
export const STATUS_META: Record<ApplicationStatus, StatusMeta> = {
  saved: {
    label: "已收藏",
    color: "text-muted-foreground",
    badgeClass: "bg-muted text-muted-foreground",
  },
  applied: {
    label: "已投递",
    color: "text-blue-500",
    badgeClass: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300",
  },
  written: {
    label: "已笔试",
    color: "text-cyan-500",
    badgeClass: "bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300",
  },
  phone_screen: {
    label: "电话面试",
    color: "text-amber-500",
    badgeClass: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  },
  onsite: {
    label: "现场面试",
    color: "text-orange-500",
    badgeClass: "bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300",
  },
  offer: {
    label: "Offer",
    color: "text-emerald-500",
    badgeClass: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
  },
  rejected: {
    label: "已拒绝",
    color: "text-red-500",
    badgeClass: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300",
  },
  withdrawn: {
    label: "已撤回",
    color: "text-zinc-500",
    badgeClass: "bg-zinc-100 text-zinc-600 dark:bg-zinc-500/15 dark:text-zinc-400",
  },
};

/** 看板列顺序 */
export const KANBAN_COLUMNS: ApplicationStatus[] = [
  "saved",
  "applied",
  "written",
  "phone_screen",
  "onsite",
  "offer",
  "rejected",
];

/** 优先级元数据 */
export const PRIORITY_META: Record<Priority, { label: string; border: string; dot: string }> = {
  high: { label: "高", border: "border-l-red-500", dot: "bg-red-500" },
  medium: { label: "中", border: "border-l-amber-500", dot: "bg-amber-500" },
  low: { label: "低", border: "border-l-blue-500", dot: "bg-blue-500" },
  none: { label: "无", border: "border-l-transparent", dot: "bg-transparent" },
};

/** 来源元数据 */
export const SOURCE_META: Record<JobSource, string> = {
  boss: "Boss直聘",
  zhilian: "智联招聘",
  niuke: "牛客",
  nowcoder: "牛客",
  lagou: "拉勾",
  "51job": "前程无忧",
  liepin: "猎聘",
  manual: "手动",
  monitor: "监控",
  other: "其他",
};

/** 岗位订阅规则 */
export interface JobSubscription {
  id: string;
  name: string;
  platform: string;
  keywords?: string;
  companies?: string;
  location?: string;
  salary_min?: string;
  salary_max?: string;
  is_remote_only: boolean;
  interval_minutes: number;
  ai_filter_enabled: boolean;
  ai_threshold: number;
  webhook_url?: string;
  enabled: boolean;
  last_run_at?: string;
  last_new_count: number;
  total_new_count: number;
  created_at: string;
  updated_at: string;
}

/** 创建订阅请求 */
export interface CreateSubscriptionInput {
  name: string;
  platform: string;
  keywords?: string;
  companies?: string;
  location?: string;
  salary_min?: string;
  salary_max?: string;
  is_remote_only?: boolean;
  interval_minutes?: number;
  ai_filter_enabled?: boolean;
  ai_threshold?: number;
  webhook_url?: string;
  enabled?: boolean;
}

/** 批量导入结果 */
export interface BatchImportResult {
  new_jobs: Job[];
  duplicate_count: number;
  subscription_id?: string;
}

/** 监控统计 */
export interface MonitorStats {
  total_subscriptions: number;
  active_subscriptions: number;
  total_new_jobs: number;
  jobs_last_24h: number;
  jobs_last_7d: number;
}

/** 平台元数据（用于订阅表单） */
export const PLATFORM_META: Record<string, string> = {
  boss: "Boss直聘",
  zhilian: "智联招聘",
  niuke: "牛客",
  lagou: "拉勾",
  liepin: "猎聘",
  "51job": "前程无忧",
};
