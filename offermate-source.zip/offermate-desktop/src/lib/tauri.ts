import { invoke } from "@tauri-apps/api/core";
import type {
  Application,
  ApplicationStatus,
  CreateApplicationInput,
  UpdateApplicationInput,
  Resume,
  SubResume,
  ResumeTemplate,
  BasicInfo,
  Job,
  JobSource,
  Note,
  ChatMessage,
  Conversation,
  DashboardStats,
  StatusLog,
  ResumeAnalysis,
  JobMatchResult,
  AppSettings,
  AIMode,
  JobSubscription,
  CreateSubscriptionInput,
  BatchImportResult,
  MonitorStats,
} from "./types";

/**
 * Tauri 后端命令封装层。
 * 所有方法返回 Promise，并对参数/返回值做完整类型标注。
 * 在 Web 环境下（非 Tauri）会安全降级，便于开发调试。
 */

let tauriAvailable: boolean | null = null;

async function isTauri(): Promise<boolean> {
  if (tauriAvailable !== null) return tauriAvailable;
  if (typeof window !== "undefined" && "__TAURI_INTERNALS__" in window) {
    tauriAvailable = true;
  } else {
    tauriAvailable = false;
  }
  return tauriAvailable;
}

/**
 * 安全调用：Tauri 环境下走 invoke，否则返回 fallback。
 */
async function safeInvoke<T>(cmd: string, args?: Record<string, unknown>, fallback?: T): Promise<T> {
  if (await isTauri()) {
    return invoke<T>(cmd, args);
  }
  if (fallback !== undefined) return fallback;
  // 开发降级：返回空结构，避免运行时崩溃
  return [] as unknown as T;
}

/* ------------------------------------------------------------------ */
/* Applications API                                                    */
/* ------------------------------------------------------------------ */

export const applicationsApi = {
  list(): Promise<Application[]> {
    return safeInvoke<Application[]>("list_applications", undefined, []);
  },

  get(id: string): Promise<Application | null> {
    return safeInvoke<Application | null>("get_application", { id }, null);
  },

  create(input: CreateApplicationInput): Promise<Application> {
    return safeInvoke<Application>("create_application", { input });
  },

  update(id: string, input: UpdateApplicationInput): Promise<Application> {
    return safeInvoke<Application>("update_application", { id, input });
  },

  delete(id: string): Promise<void> {
    return safeInvoke<void>("delete_application", { id });
  },

  transitionStatus(
    id: string,
    toStatus: ApplicationStatus,
    note?: string,
  ): Promise<StatusLog> {
    return safeInvoke<StatusLog>("transition_status", {
      id,
      toStatus,
      note,
    });
  },

  getTimeline(id: string): Promise<StatusLog[]> {
    return safeInvoke<StatusLog[]>("get_timeline", { id }, []);
  },

  getStats(): Promise<DashboardStats> {
    return safeInvoke<DashboardStats>("get_stats", undefined, {
      total: 0,
      saved: 0,
      applied: 0,
      written: 0,
      phone_screen: 0,
      onsite: 0,
      offer: 0,
      rejected: 0,
      withdrawn: 0,
      interviewing: 0,
      conversion_rate: 0,
      by_status: {
        saved: 0,
        applied: 0,
        written: 0,
        phone_screen: 0,
        onsite: 0,
        offer: 0,
        rejected: 0,
        withdrawn: 0,
      },
      trend: [],
    });
  },
};

/* ------------------------------------------------------------------ */
/* Resumes API                                                         */
/* ------------------------------------------------------------------ */

export const resumesApi = {
  list(): Promise<Resume[]> {
    return safeInvoke<Resume[]>("list_resumes", undefined, []);
  },

  get(id: string): Promise<Resume | null> {
    return safeInvoke<Resume | null>("get_resume", { id }, null);
  },

  create(input: {
    name: string;
    template: ResumeTemplate;
    basic_info: BasicInfo;
  }): Promise<Resume> {
    return safeInvoke<Resume>("create_resume", { input });
  },

  update(id: string, input: Partial<Resume>): Promise<Resume> {
    return safeInvoke<Resume>("update_resume", { id, input });
  },

  delete(id: string): Promise<void> {
    return safeInvoke<void>("delete_resume", { id });
  },

  listSubResumes(parentId: string): Promise<SubResume[]> {
    return safeInvoke<SubResume[]>("list_sub_resumes", { parentId }, []);
  },

  createSubResume(input: {
    parent_id: string;
    name: string;
    target_company?: string;
    target_position?: string;
  }): Promise<SubResume> {
    return safeInvoke<SubResume>("create_sub_resume", { input });
  },

  deleteSubResume(id: string): Promise<void> {
    return safeInvoke<void>("delete_sub_resume", { id });
  },
};

/* ------------------------------------------------------------------ */
/* Jobs API                                                            */
/* ------------------------------------------------------------------ */

export const jobsApi = {
  list(): Promise<Job[]> {
    return safeInvoke<Job[]>("list_jobs", undefined, []);
  },

  create(input: {
    company: string;
    position: string;
    salary?: string;
    location?: string;
    source: JobSource;
    url?: string;
    description?: string;
    tags?: string[];
  }): Promise<Job> {
    return safeInvoke<Job>("create_job", { input });
  },

  delete(id: string): Promise<void> {
    return safeInvoke<void>("delete_job", { id });
  },

  importJobs(jobs: Array<Partial<Job>>): Promise<Job[]> {
    return safeInvoke<Job[]>("import_jobs", { jobs }, []);
  },

  search(query: string): Promise<Job[]> {
    return safeInvoke<Job[]>("search_jobs", { query }, []);
  },

  listRecent(hours?: number): Promise<Job[]> {
    return safeInvoke<Job[]>("list_recent_jobs", { hours }, []);
  },
};

/* ------------------------------------------------------------------ */
/* Notes API                                                           */
/* ------------------------------------------------------------------ */

export const notesApi = {
  list(): Promise<Note[]> {
    return safeInvoke<Note[]>("list_notes", undefined, []);
  },

  create(input: {
    title: string;
    content: string;
    category: Note["category"];
    tags?: string[];
    application_id?: string;
  }): Promise<Note> {
    return safeInvoke<Note>("create_note", { input });
  },

  update(id: string, input: Partial<Note>): Promise<Note> {
    return safeInvoke<Note>("update_note", { id, input });
  },

  delete(id: string): Promise<void> {
    return safeInvoke<void>("delete_note", { id });
  },
};

/* ------------------------------------------------------------------ */
/* AI API                                                              */
/* ------------------------------------------------------------------ */

export const aiApi = {
  chat(input: {
    messages: ChatMessage[];
    mode: AIMode;
  }): Promise<string> {
    return safeInvoke<string>("ai_chat", { input }, "（AI 服务未连接，请在设置中配置 AI 参数）");
  },

  analyzeResume(input: {
    resume_id: string;
    job_description: string;
  }): Promise<ResumeAnalysis> {
    return safeInvoke<ResumeAnalysis>("ai_analyze_resume", { input }, {
      score: 0,
      strengths: [],
      weaknesses: ["未连接 AI 服务"],
      suggestions: ["请先在设置页配置 AI Provider 与 API Key"],
    });
  },

  mockInterview(input: {
    resume_id?: string;
    position?: string;
    question?: string;
    answer?: string;
    action: "ask" | "evaluate";
  }): Promise<string> {
    return safeInvoke<string>("ai_mock_interview", { input }, "（AI 服务未连接）");
  },

  matchJob(input: {
    resume_id: string;
    job_id: string;
  }): Promise<JobMatchResult> {
    return safeInvoke<JobMatchResult>("ai_match_job", { input }, {
      score: 0,
      matched_skills: [],
      missing_skills: [],
      reasons: ["未连接 AI 服务"],
    });
  },

  saveConversation(conversation: Conversation): Promise<Conversation> {
    return safeInvoke<Conversation>("save_conversation", { conversation });
  },

  listConversations(): Promise<Conversation[]> {
    return safeInvoke<Conversation[]>("list_conversations", undefined, []);
  },
};

/* ------------------------------------------------------------------ */
/* Settings API                                                        */
/* ------------------------------------------------------------------ */

export const settingsApi = {
  load(): Promise<AppSettings> {
    return safeInvoke<AppSettings>("load_settings", undefined, {
      theme: "system",
      ai: { provider: "openai", api_key: "", model: "gpt-4o-mini", base_url: "" },
      auto_save: true,
      notification_enabled: true,
    });
  },

  save(settings: AppSettings): Promise<AppSettings> {
    return safeInvoke<AppSettings>("save_settings", { settings });
  },

  testConnection(): Promise<boolean> {
    return safeInvoke<boolean>("test_ai_connection", undefined, false);
  },

  exportData(): Promise<string> {
    return safeInvoke<string>("export_data", undefined, "{}");
  },

  importData(data: string): Promise<void> {
    return safeInvoke<void>("import_data", { data });
  },

  clearData(): Promise<void> {
    return safeInvoke<void>("clear_data");
  },
};

/* ------------------------------------------------------------------ */
/* Monitor API                                                         */
/* ------------------------------------------------------------------ */

export const monitorApi = {
  listSubscriptions(): Promise<JobSubscription[]> {
    return safeInvoke<JobSubscription[]>("list_subscriptions", undefined, []);
  },

  createSubscription(input: CreateSubscriptionInput): Promise<JobSubscription> {
    return safeInvoke<JobSubscription>("create_subscription", { input });
  },

  updateSubscription(id: string, input: Partial<CreateSubscriptionInput>): Promise<JobSubscription> {
    return safeInvoke<JobSubscription>("update_subscription", { id, input });
  },

  deleteSubscription(id: string): Promise<void> {
    return safeInvoke<void>("delete_subscription", { id });
  },

  toggleSubscription(id: string, enabled: boolean): Promise<void> {
    return safeInvoke<void>("toggle_subscription", { id, enabled });
  },

  importBatch(jobs: Array<Record<string, unknown>>, subscriptionId?: string): Promise<BatchImportResult> {
    return safeInvoke<BatchImportResult>(
      "import_batch_jobs",
      { jobs, subscriptionId },
      { new_jobs: [], duplicate_count: 0 },
    );
  },

  getStats(): Promise<MonitorStats> {
    return safeInvoke<MonitorStats>("get_monitor_stats", undefined, {
      total_subscriptions: 0,
      active_subscriptions: 0,
      total_new_jobs: 0,
      jobs_last_24h: 0,
      jobs_last_7d: 0,
    });
  },
};
