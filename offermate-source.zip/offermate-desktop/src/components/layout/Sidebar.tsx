import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  KanbanSquare,
  FileText,
  Sparkles,
  Brain,
  Target,
  Bookmark,
  NotebookPen,
  Settings,
  Briefcase,
  Radar,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

const NAV_GROUPS: NavGroup[] = [
  {
    title: "概览",
    items: [
      { to: "/", label: "仪表盘", icon: LayoutDashboard },
      { to: "/applications", label: "投递看板", icon: KanbanSquare },
    ],
  },
  {
    title: "简历",
    items: [
      { to: "/resume", label: "简历管理", icon: FileText },
    ],
  },
  {
    title: "AI 工具",
    items: [
      { to: "/ai", label: "AI 助手", icon: Sparkles },
      { to: "/ai?mode=interview", label: "模拟面试", icon: Brain },
      { to: "/ai?mode=match", label: "岗位匹配", icon: Target },
    ],
  },
  {
    title: "数据",
    items: [
      { to: "/monitor", label: "岗位监控", icon: Radar },
      { to: "/jobs", label: "岗位收藏", icon: Bookmark },
      { to: "/notes", label: "求职笔记", icon: NotebookPen },
      { to: "/settings", label: "设置", icon: Settings },
    ],
  },
];

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  return (
    <aside
      className={cn(
        "flex h-full w-[240px] shrink-0 flex-col border-r border-border bg-card/60 dark:bg-card/40",
        className,
      )}
    >
      {/* Logo */}
      <div className="flex h-16 items-center gap-2.5 px-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm">
          <Briefcase className="h-5 w-5" strokeWidth={1.5} />
        </div>
        <div className="flex flex-col leading-none">
          <span className="text-base font-semibold tracking-tight text-primary">
            OfferMate
          </span>
          <span className="text-[11px] text-muted-foreground">求职管家</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="scrollbar-thin flex-1 overflow-y-auto px-3 pb-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.title} className="mb-4">
            <p className="px-3 pb-1.5 pt-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              {group.title}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    end={item.to === "/"}
                    className={({ isActive }) =>
                      cn(
                        "group flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors duration-150",
                        isActive
                          ? "bg-primary/10 text-primary"
                          : "text-muted-foreground hover:bg-accent hover:text-foreground",
                      )
                    }
                  >
                    <item.icon
                      className="h-[18px] w-[18px] shrink-0"
                      strokeWidth={1.5}
                    />
                    <span className="truncate">{item.label}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-border px-5 py-3">
        <p className="text-[11px] text-muted-foreground">
          v1.0.0 · 本地优先
        </p>
      </div>
    </aside>
  );
}
