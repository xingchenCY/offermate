import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Sun,
  Moon,
  Monitor,
  Eye,
  EyeOff,
  Loader2,
  CheckCircle2,
  XCircle,
  Download,
  Upload,
  Trash2,
  Info,
  Bot,
  Palette,
  Database,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useSettingsStore } from "@/stores/settingsStore";
import { settingsApi } from "@/lib/tauri";
import { cn } from "@/lib/utils";
import type { AIProvider, ThemeMode } from "@/lib/types";

const PROVIDERS: { value: AIProvider; label: string; defaultModel: string }[] = [
  { value: "openai", label: "OpenAI", defaultModel: "gpt-4o-mini" },
  { value: "deepseek", label: "DeepSeek", defaultModel: "deepseek-chat" },
  { value: "ollama", label: "Ollama (本地)", defaultModel: "llama3.1" },
];

export function Settings() {
  const {
    settings,
    loaded,
    testing,
    testResult,
    loadSettings,
    saveSettings,
    setTheme,
    setAIProvider,
    setAIField,
    testConnection,
  } = useSettingsStore();

  const [showKey, setShowKey] = useState(false);
  const [clearOpen, setClearOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [importOpen, setImportOpen] = useState(false);

  useEffect(() => {
    if (!loaded) void loadSettings();
  }, [loaded, loadSettings]);

  const handleProviderChange = (provider: AIProvider) => {
    const p = PROVIDERS.find((x) => x.value === provider)!;
    setAIProvider(provider);
    setAIField("model", p.defaultModel);
  };

  const handleTest = async () => {
    await saveSettings(settings);
    const ok = await testConnection();
    toast[ok ? "success" : "error"](
      ok ? "连接成功" : "连接失败，请检查配置",
    );
  };

  const handleExport = async () => {
    const data = await settingsApi.exportData();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `offermate-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("数据已导出");
  };

  const handleImport = async () => {
    try {
      await settingsApi.importData(importText);
      toast.success("数据已导入");
      setImportOpen(false);
      setImportText("");
      await loadSettings();
    } catch {
      toast.error("导入失败，请检查数据格式");
    }
  };

  const handleClear = async () => {
    await settingsApi.clearData();
    toast.success("数据已清除");
    setClearOpen(false);
  };

  return (
    <div className="scrollbar-thin h-full overflow-y-auto p-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">设置</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            管理应用外观、AI 配置与数据
          </p>
        </div>

        {/* Appearance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" strokeWidth={1.5} />
              外观
            </CardTitle>
            <CardDescription>选择应用主题模式</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              <ThemeOption
                icon={Sun}
                label="亮色"
                active={settings.theme === "light"}
                onClick={() => setTheme("light")}
              />
              <ThemeOption
                icon={Moon}
                label="暗色"
                active={settings.theme === "dark"}
                onClick={() => setTheme("dark")}
              />
              <ThemeOption
                icon={Monitor}
                label="跟随系统"
                active={settings.theme === "system"}
                onClick={() => setTheme("system")}
              />
            </div>
          </CardContent>
        </Card>

        {/* AI config */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-primary" strokeWidth={1.5} />
              AI 配置
            </CardTitle>
            <CardDescription>
              配置 AI 服务以启用智能分析、模拟面试等功能
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
                服务商
              </label>
              <Select
                value={settings.ai.provider}
                onValueChange={(v) => handleProviderChange(v as AIProvider)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROVIDERS.map((p) => (
                    <SelectItem key={p.value} value={p.value}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
                API Key
              </label>
              <div className="relative">
                <Input
                  type={showKey ? "text" : "password"}
                  value={settings.ai.api_key}
                  onChange={(e) => setAIField("api_key", e.target.value)}
                  placeholder={settings.ai.provider === "ollama" ? "本地无需 Key" : "sk-..."}
                  className="pr-10"
                />
                <button
                  onClick={() => setShowKey((s) => !s)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showKey ? (
                    <EyeOff className="h-4 w-4" strokeWidth={1.5} />
                  ) : (
                    <Eye className="h-4 w-4" strokeWidth={1.5} />
                  )}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
                  模型
                </label>
                <Input
                  value={settings.ai.model}
                  onChange={(e) => setAIField("model", e.target.value)}
                  placeholder="gpt-4o-mini"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
                  Base URL（可选）
                </label>
                <Input
                  value={settings.ai.base_url}
                  onChange={(e) => setAIField("base_url", e.target.value)}
                  placeholder="https://api.openai.com/v1"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={handleTest} disabled={testing}>
                {testing ? (
                  <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.5} />
                ) : (
                  <Bot className="h-4 w-4" strokeWidth={1.5} />
                )}
                测试连接
              </Button>
              {testResult === true && (
                <span className="flex items-center gap-1 text-sm text-emerald-500">
                  <CheckCircle2 className="h-4 w-4" strokeWidth={1.5} />
                  连接正常
                </span>
              )}
              {testResult === false && (
                <span className="flex items-center gap-1 text-sm text-destructive">
                  <XCircle className="h-4 w-4" strokeWidth={1.5} />
                  连接失败
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Data management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-primary" strokeWidth={1.5} />
              数据管理
            </CardTitle>
            <CardDescription>备份、恢复或清除本地数据</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <DataRow
              icon={Download}
              title="导出数据"
              desc="将所有数据导出为 JSON 文件"
              action={
                <Button variant="outline" size="sm" onClick={handleExport}>
                  导出
                </Button>
              }
            />
            <DataRow
              icon={Upload}
              title="导入数据"
              desc="从 JSON 文件恢复数据"
              action={
                <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
                  导入
                </Button>
              }
            />
            <DataRow
              icon={Trash2}
              title="清除数据"
              desc="删除所有本地数据，不可恢复"
              danger
              action={
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setClearOpen(true)}
                >
                  清除
                </Button>
              }
            />
          </CardContent>
        </Card>

        {/* About */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-primary" strokeWidth={1.5} />
              关于
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <Row label="应用名称" value="OfferMate 求职管家" />
              <Row label="版本" value="v1.0.0" />
              <Row label="技术栈" value="Tauri 2.0 + React 18 + TypeScript" />
              <div className="flex flex-wrap items-center gap-1.5 pt-2">
                {["Tauri", "React", "Tailwind", "Zustand", "Recharts", "shadcn/ui"].map(
                  (tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ),
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clear dialog */}
      <Dialog open={clearOpen} onOpenChange={setClearOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认清除所有数据？</DialogTitle>
            <DialogDescription>
              此操作将删除所有投递记录、简历、笔记和岗位数据，且不可恢复。建议先导出备份。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClearOpen(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleClear}>
              确认清除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import dialog */}
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>导入数据</DialogTitle>
            <DialogDescription>
              粘贴之前导出的 JSON 数据
            </DialogDescription>
          </DialogHeader>
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder='{"applications": [...], ...}'
            className="min-h-[200px] w-full rounded-lg border border-input bg-background p-3 text-xs font-mono shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportOpen(false)}>
              取消
            </Button>
            <Button onClick={handleImport} disabled={!importText.trim()}>
              导入
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ThemeOption({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: typeof Sun;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-2 rounded-xl border p-4 transition-all active:scale-[0.98]",
        active
          ? "border-primary bg-primary/5 text-primary"
          : "border-border hover:bg-accent",
      )}
    >
      <Icon className="h-5 w-5" strokeWidth={1.5} />
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}

function DataRow({
  icon: Icon,
  title,
  desc,
  action,
  danger,
}: {
  icon: typeof Download;
  title: string;
  desc: string;
  action: React.ReactNode;
  danger?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-lg border border-border p-3">
      <div className="flex items-center gap-3">
        <span
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-lg",
            danger
              ? "bg-destructive/10 text-destructive"
              : "bg-primary/10 text-primary",
          )}
        >
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
        <div>
          <p className="text-sm font-medium">{title}</p>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
      </div>
      {action}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
