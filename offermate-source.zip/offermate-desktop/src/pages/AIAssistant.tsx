import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import {
  Sparkles,
  Brain,
  Target,
  Send,
  Plus,
  Trash2,
  MessageSquare,
  FileText,
  Loader2,
  Wand2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn, uid, timeAgo } from "@/lib/utils";
import { resumesApi, jobsApi, aiApi } from "@/lib/tauri";
import type {
  AIMode,
  ChatMessage,
  Conversation,
  Resume,
  Job,
} from "@/lib/types";

const MODE_META: Record<AIMode, { label: string; icon: typeof Sparkles; desc: string }> = {
  optimize: { label: "简历优化", icon: Sparkles, desc: "上传简历与 JD，AI 帮你分析匹配度与改进建议" },
  interview: { label: "模拟面试", icon: Brain, desc: "选择岗位，AI 模拟面试官提问并评价你的回答" },
  match: { label: "岗位匹配", icon: Target, desc: "选择简历与岗位，AI 评估匹配度评分" },
};

export function AIAssistant() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialMode = (searchParams.get("mode") as AIMode) || "optimize";
  const [mode, setMode] = useState<AIMode>(initialMode);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  // resource data
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedResumeId, setSelectedResumeId] = useState("");
  const [selectedJobId, setSelectedJobId] = useState("");
  const [jdText, setJdText] = useState("");
  const [position, setPosition] = useState("");

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    void (async () => {
      const [r, j, convs] = await Promise.all([
        resumesApi.list(),
        jobsApi.list(),
        aiApi.listConversations(),
      ]);
      setResumes(r);
      setJobs(j);
      setConversations(convs);
    })();
  }, []);

  useEffect(() => {
    const m = searchParams.get("mode") as AIMode | null;
    if (m && m !== mode) setMode(m);
  }, [searchParams, mode]);

  const switchMode = (m: AIMode) => {
    setMode(m);
    setSearchParams({ mode: m });
    setMessages([]);
    setActiveId("");
  };

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, sending]);

  const newConversation = () => {
    setMessages([]);
    setActiveId("");
    setInput("");
  };

  const handleSend = async () => {
    if (sending) return;
    if (mode === "optimize") {
      if (!selectedResumeId) return toast.error("请选择简历");
      if (!jdText.trim()) return toast.error("请粘贴岗位 JD");
    }
    if (mode === "match") {
      if (!selectedResumeId) return toast.error("请选择简历");
      if (!selectedJobId) return toast.error("请选择岗位");
    }

    let userContent = input.trim();
    if (mode === "optimize" && messages.length === 0) {
      userContent = `请分析我的简历与以下岗位 JD 的匹配度：\n\n${jdText}`;
    }

    if (!userContent) return;

    const userMsg: ChatMessage = {
      id: uid("msg"),
      role: "user",
      content: userContent,
      created_at: new Date().toISOString(),
      mode,
    };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput("");
    setSending(true);

    try {
      let reply = "";
      if (mode === "optimize" && messages.length === 0) {
        const analysis = await aiApi.analyzeResume({
          resume_id: selectedResumeId,
          job_description: jdText,
        });
        reply = formatAnalysis(analysis);
      } else if (mode === "match" && messages.length === 0) {
        const result = await aiApi.matchJob({
          resume_id: selectedResumeId,
          job_id: selectedJobId,
        });
        reply = formatMatch(result);
      } else if (mode === "interview" && messages.length === 0) {
        reply = await aiApi.mockInterview({
          resume_id: selectedResumeId || undefined,
          position: position || undefined,
          action: "ask",
        });
      } else {
        reply = await aiApi.chat({
          messages: nextMessages.map((m) => ({
            id: m.id,
            role: m.role,
            content: m.content,
            created_at: m.created_at,
            mode: m.mode,
          })),
          mode,
        });
      }
      const assistantMsg: ChatMessage = {
        id: uid("msg"),
        role: "assistant",
        content: reply,
        created_at: new Date().toISOString(),
        mode,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "AI 请求失败");
    } finally {
      setSending(false);
    }
  };

  const deleteConversation = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) {
      setActiveId("");
      setMessages([]);
    }
  };

  return (
    <div className="flex h-full">
      {/* Conversation list */}
      <div className="flex w-64 shrink-0 flex-col border-r border-border">
        <div className="flex items-center justify-between p-3">
          <span className="text-sm font-medium">对话历史</span>
          <Button variant="ghost" size="icon" onClick={newConversation}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
          </Button>
        </div>
        <div className="scrollbar-thin flex-1 space-y-1 overflow-y-auto px-2 pb-3">
          {conversations.length === 0 ? (
            <p className="px-3 py-4 text-center text-xs text-muted-foreground">
              暂无历史对话
            </p>
          ) : (
            conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => {
                  setActiveId(conv.id);
                  setMode(conv.mode);
                  setMessages(conv.messages);
                }}
                className={cn(
                  "group flex w-full items-start gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors hover:bg-accent",
                  activeId === conv.id && "bg-accent",
                )}
              >
                <MessageSquare
                  className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground"
                  strokeWidth={1.5}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate">{conv.title}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {MODE_META[conv.mode].label} · {timeAgo(conv.updated_at)}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteConversation(conv.id);
                  }}
                  className="opacity-0 transition-opacity group-hover:opacity-100"
                >
                  <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" strokeWidth={1.5} />
                </button>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex flex-1 flex-col">
        {/* Mode tabs */}
        <div className="border-b border-border p-3">
          <div className="flex gap-1 rounded-lg bg-muted p-1">
            {(Object.keys(MODE_META) as AIMode[]).map((m) => {
              const meta = MODE_META[m];
              return (
                <button
                  key={m}
                  onClick={() => switchMode(m)}
                  className={cn(
                    "flex flex-1 items-center justify-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                    mode === m
                      ? "bg-background text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  <meta.icon className="h-4 w-4" strokeWidth={1.5} />
                  {meta.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Resource selectors */}
        <div className="border-b border-border px-4 py-3">
          {mode === "optimize" && (
            <div className="grid grid-cols-2 gap-3">
              <ResourceSelect
                label="选择简历"
                value={selectedResumeId}
                onChange={setSelectedResumeId}
                options={resumes.map((r) => ({ value: r.id, label: r.name }))}
                placeholder="选择一份简历"
              />
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  岗位 JD
                </label>
                <Textarea
                  value={jdText}
                  onChange={(e) => setJdText(e.target.value)}
                  placeholder="粘贴目标岗位的职位描述..."
                  rows={1}
                  className="min-h-[36px]"
                />
              </div>
            </div>
          )}
          {mode === "interview" && (
            <div className="grid grid-cols-2 gap-3">
              <ResourceSelect
                label="选择简历（可选）"
                value={selectedResumeId}
                onChange={setSelectedResumeId}
                options={resumes.map((r) => ({ value: r.id, label: r.name }))}
                placeholder="用于个性化提问"
              />
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">
                  面试岗位
                </label>
                <Input
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  placeholder="例如 前端工程师"
                />
              </div>
            </div>
          )}
          {mode === "match" && (
            <div className="grid grid-cols-2 gap-3">
              <ResourceSelect
                label="选择简历"
                value={selectedResumeId}
                onChange={setSelectedResumeId}
                options={resumes.map((r) => ({ value: r.id, label: r.name }))}
                placeholder="选择简历"
              />
              <ResourceSelect
                label="选择岗位"
                value={selectedJobId}
                onChange={setSelectedJobId}
                options={jobs.map((j) => ({
                  value: j.id,
                  label: `${j.company} · ${j.position}`,
                }))}
                placeholder="选择岗位"
              />
            </div>
          )}
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="scrollbar-thin flex-1 overflow-y-auto px-4 py-4">
          {messages.length === 0 ? (
            <EmptyChat mode={mode} />
          ) : (
            <div className="mx-auto max-w-3xl space-y-4">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              {sending && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.5} />
                  AI 正在思考...
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-border p-4">
          <div className="mx-auto flex max-w-3xl items-end gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void handleSend();
                }
              }}
              placeholder={
                mode === "interview" && messages.length === 0
                  ? "点击发送开始模拟面试..."
                  : "输入消息，Enter 发送，Shift+Enter 换行"
              }
              rows={1}
              className="min-h-[44px] resize-none"
            />
            <Button
              onClick={handleSend}
              disabled={sending}
              size="icon"
              className="h-11 w-11 shrink-0"
            >
              <Send className="h-4 w-4" strokeWidth={1.5} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Sub components ---------------- */

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  return (
    <div className={cn("flex gap-3", isUser && "flex-row-reverse")}>
      <div
        className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
          isUser
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-muted-foreground",
        )}
      >
        {isUser ? (
          <span className="text-xs font-medium">我</span>
        ) : (
          <Sparkles className="h-4 w-4" strokeWidth={1.5} />
        )}
      </div>
      <div
        className={cn(
          "max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed",
          isUser
            ? "bg-primary text-primary-foreground"
            : "bg-card border border-border",
        )}
      >
        <MarkdownLite content={message.content} />
      </div>
    </div>
  );
}

function EmptyChat({ mode }: { mode: AIMode }) {
  const meta = MODE_META[mode];
  return (
    <div className="flex h-full flex-col items-center justify-center text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
        <meta.icon className="h-8 w-8" strokeWidth={1.5} />
      </div>
      <h3 className="text-lg font-medium">{meta.label}</h3>
      <p className="mt-1 max-w-md text-sm text-muted-foreground">{meta.desc}</p>
      <div className="mt-6 grid grid-cols-1 gap-2">
        {mode === "optimize" && (
          <Hint text="选择简历并粘贴 JD，开始分析" icon={FileText} />
        )}
        {mode === "interview" && (
          <Hint text="输入岗位，点击发送开始面试" icon={Brain} />
        )}
        {mode === "match" && (
          <Hint text="选择简历与岗位，计算匹配度" icon={Target} />
        )}
      </div>
    </div>
  );
}

function Hint({
  text,
  icon: Icon,
}: {
  text: string;
  icon: typeof FileText;
}) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs text-muted-foreground">
      <Icon className="h-4 w-4 text-primary" strokeWidth={1.5} />
      {text}
    </div>
  );
}

function ResourceSelect({
  label,
  value,
  onChange,
  options,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  placeholder: string;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-muted-foreground">
        {label}
      </label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {options.length === 0 ? (
            <SelectItem value="_empty" disabled>
              暂无数据
            </SelectItem>
          ) : (
            options.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
    </div>
  );
}

/** 轻量 Markdown 渲染：支持标题、粗体、列表、代码块、段落 */
function MarkdownLite({ content }: { content: string }) {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let list: string[] = [];
  let codeBuf: string[] | null = null;

  const flushList = () => {
    if (list.length > 0) {
      elements.push(
        <ul key={`ul-${elements.length}`} className="my-1 list-disc space-y-0.5 pl-4">
          {list.map((item, i) => (
            <li key={i} dangerouslySetInnerHTML={{ __html: inline(item) }} />
          ))}
        </ul>,
      );
      list = [];
    }
  };

  for (const line of lines) {
    if (line.startsWith("```")) {
      if (codeBuf) {
        elements.push(
          <pre
            key={`code-${elements.length}`}
            className="my-1 overflow-x-auto rounded-md bg-foreground/10 p-2 text-xs"
          >
            <code>{codeBuf.join("\n")}</code>
          </pre>,
        );
        codeBuf = null;
      } else {
        flushList();
        codeBuf = [];
      }
      continue;
    }
    if (codeBuf) {
      codeBuf.push(line);
      continue;
    }
    if (/^#{1,3}\s/.test(line)) {
      flushList();
      const level = line.match(/^#{1,3}/)![0].length;
      const text = line.replace(/^#{1,3}\s/, "");
      elements.push(
        <p
          key={`h-${elements.length}`}
          className={cn(
            "my-1 font-semibold",
            level === 1 ? "text-base" : "text-sm",
          )}
          dangerouslySetInnerHTML={{ __html: inline(text) }}
        />,
      );
      continue;
    }
    if (/^[-*]\s/.test(line)) {
      list.push(line.replace(/^[-*]\s/, ""));
      continue;
    }
    if (line.trim() === "") {
      flushList();
      continue;
    }
    flushList();
    elements.push(
      <p
        key={`p-${elements.length}`}
        className="my-0.5"
        dangerouslySetInnerHTML={{ __html: inline(line) }}
      />,
    );
  }
  flushList();
  if (codeBuf) {
    elements.push(
      <pre key="code-last" className="my-1 overflow-x-auto rounded-md bg-foreground/10 p-2 text-xs">
        <code>{codeBuf.join("\n")}</code>
      </pre>,
    );
  }
  return <div className="space-y-0.5">{elements}</div>;
}

function inline(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.+?)`/g, '<code class="rounded bg-foreground/10 px-1">$1</code>');
}

function formatAnalysis(a: {
  score: number;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  keywords?: string[];
}): string {
  const lines: string[] = [];
  lines.push(`## 简历分析结果`);
  lines.push(`**匹配评分：${a.score} / 100**`);
  lines.push("");
  if (a.strengths.length) {
    lines.push("### 优势");
    a.strengths.forEach((s) => lines.push(`- ${s}`));
    lines.push("");
  }
  if (a.weaknesses.length) {
    lines.push("### 不足");
    a.weaknesses.forEach((s) => lines.push(`- ${s}`));
    lines.push("");
  }
  if (a.suggestions.length) {
    lines.push("### 改进建议");
    a.suggestions.forEach((s) => lines.push(`- ${s}`));
    lines.push("");
  }
  if (a.keywords && a.keywords.length) {
    lines.push(`**关键词：** ${a.keywords.join("、")}`);
  }
  return lines.join("\n");
}

function formatMatch(r: {
  score: number;
  matched_skills: string[];
  missing_skills: string[];
  reasons: string[];
}): string {
  const lines: string[] = [];
  lines.push(`## 岗位匹配度分析`);
  lines.push(`**匹配评分：${r.score} / 100**`);
  lines.push("");
  if (r.matched_skills.length) {
    lines.push(`### 已具备 (${r.matched_skills.length})`);
    r.matched_skills.forEach((s) => lines.push(`- ${s}`));
    lines.push("");
  }
  if (r.missing_skills.length) {
    lines.push(`### 待补充 (${r.missing_skills.length})`);
    r.missing_skills.forEach((s) => lines.push(`- ${s}`));
    lines.push("");
  }
  if (r.reasons.length) {
    lines.push("### 分析说明");
    r.reasons.forEach((s) => lines.push(`- ${s}`));
  }
  return lines.join("\n");
}
