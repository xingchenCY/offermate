import { useEffect, useMemo, useState, useCallback } from "react";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Calendar,
  MapPin,
  DollarSign,
  MoreHorizontal,
  Pencil,
  Trash2,
  ArrowRightCircle,
  X,
  Inbox,
  Link2,
  type LucideIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Textarea } from "@/components/ui/textarea";
import { useApplicationStore } from "@/stores/applicationStore";
import {
  STATUS_META,
  KANBAN_COLUMNS,
  SOURCE_META,
  PRIORITY_META,
  type Application,
  type ApplicationStatus,
  type JobSource,
  type Priority,
  type CreateApplicationInput,
} from "@/lib/types";
import { cn, formatDate } from "@/lib/utils";

const SOURCES: JobSource[] = ["boss", "zhilian", "niuke", "lagou", "manual", "other"];
const PRIORITIES: Priority[] = ["high", "medium", "low", "none"];
const ALL_STATUSES: ApplicationStatus[] = [
  "saved",
  "applied",
  "written",
  "phone_screen",
  "onsite",
  "offer",
  "rejected",
  "withdrawn",
];

const STATUS_COLORS: Record<ApplicationStatus, string> = {
  saved: "#94a3b8",
  applied: "#3b82f6",
  written: "#06b6d4",
  phone_screen: "#f59e0b",
  onsite: "#f97316",
  offer: "#10b981",
  rejected: "#ef4444",
  withdrawn: "#71717a",
};

export function Applications() {
  const {
    applications,
    loading,
    filters,
    setFilter,
    fetchApplications,
    createApplication,
    updateApplication,
    deleteApplication,
    transitionStatus,
  } = useApplicationStore();

  const [createOpen, setCreateOpen] = useState(false);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = useState<ApplicationStatus | null>(null);

  useEffect(() => {
    void fetchApplications();
  }, [fetchApplications]);

  const grouped = useMemo(() => {
    const map: Record<ApplicationStatus, Application[]> = {
      saved: [],
      applied: [],
      written: [],
      phone_screen: [],
      onsite: [],
      offer: [],
      rejected: [],
      withdrawn: [],
    };
    const q = filters.search.trim().toLowerCase();
    applications.forEach((app) => {
      if (filters.source !== "all" && app.source !== filters.source) return;
      if (filters.priority !== "all" && app.priority !== filters.priority)
        return;
      if (q) {
        const hay = `${app.company} ${app.position} ${app.location ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return;
      }
      map[app.status].push(app);
    });
    KANBAN_COLUMNS.forEach((s) =>
      map[s].sort((a, b) => {
        const order: Record<Priority, number> = { high: 0, medium: 1, low: 2, none: 3 };
        return order[a.priority] - order[b.priority];
      }),
    );
    return map;
  }, [applications, filters]);

  const handleDrop = useCallback(
    (status: ApplicationStatus) => {
      if (!dragId) return;
      const app = applications.find((a) => a.id === dragId);
      if (app && app.status !== status) {
        void transitionStatus(dragId, status).then(() => {
          toast.success(`已移动到「${STATUS_META[status].label}」`);
        });
      }
      setDragId(null);
      setDragOverCol(null);
    },
    [dragId, applications, transitionStatus],
  );

  const detailApp = detailId
    ? applications.find((a) => a.id === detailId) ?? null
    : null;

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-card/40 px-6 py-4">
        <div className="relative w-64">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            strokeWidth={1.5}
          />
          <Input
            placeholder="搜索公司或职位..."
            value={filters.search}
            onChange={(e) => setFilter("search", e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filters.source}
          onValueChange={(v) => setFilter("source", v as typeof filters.source)}
        >
          <SelectTrigger className="w-36">
            <SelectValue placeholder="来源" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部来源</SelectItem>
            {SOURCES.map((s) => (
              <SelectItem key={s} value={s}>
                {SOURCE_META[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={filters.priority}
          onValueChange={(v) =>
            setFilter("priority", v as typeof filters.priority)
          }
        >
          <SelectTrigger className="w-32">
            <SelectValue placeholder="优先级" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部优先级</SelectItem>
            {PRIORITIES.map((p) => (
              <SelectItem key={p} value={p}>
                {PRIORITY_META[p].label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            共 {applications.length} 条记录
          </span>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
            新建投递
          </Button>
        </div>
      </div>

      {/* Kanban board */}
      <div className="scrollbar-thin flex-1 overflow-x-auto overflow-y-hidden">
        {loading && applications.length === 0 ? (
          <div className="flex h-full gap-4 p-6">
            {KANBAN_COLUMNS.map((s) => (
              <div key={s} className="w-72 shrink-0 space-y-3">
                <Skeleton className="h-8 w-full" />
                {Array.from({ length: 2 }).map((_, i) => (
                  <Skeleton key={i} className="h-28 w-full" />
                ))}
              </div>
            ))}
          </div>
        ) : applications.length === 0 ? (
          <EmptyState onCreate={() => setCreateOpen(true)} />
        ) : (
          <div className="flex h-full gap-4 p-6">
            {KANBAN_COLUMNS.map((status) => (
              <KanbanColumn
                key={status}
                status={status}
                applications={grouped[status]}
                dragId={dragId}
                dragOverCol={dragOverCol}
                onDragStart={setDragId}
                onDragOver={setDragOverCol}
                onDrop={handleDrop}
                onCardClick={setDetailId}
              />
            ))}
          </div>
        )}
      </div>

      {/* Create dialog */}
      <CreateApplicationDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreate={async (input) => {
          await createApplication(input);
          toast.success("投递记录已创建");
          setCreateOpen(false);
        }}
      />

      {/* Detail dialog */}
      {detailApp && (
        <ApplicationDetailDialog
          application={detailApp}
          onOpenChange={(open) => !open && setDetailId(null)}
          onUpdate={async (id, input) => {
            await updateApplication(id, input);
            toast.success("已更新");
          }}
          onDelete={async (id) => {
            await deleteApplication(id);
            toast.success("已删除");
            setDetailId(null);
          }}
          onTransition={async (id, status) => {
            await transitionStatus(id, status);
            toast.success(`已变更为「${STATUS_META[status].label}」`);
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Kanban Column ---------------- */

interface KanbanColumnProps {
  status: ApplicationStatus;
  applications: Application[];
  dragId: string | null;
  dragOverCol: ApplicationStatus | null;
  onDragStart: (id: string | null) => void;
  onDragOver: (col: ApplicationStatus | null) => void;
  onDrop: (status: ApplicationStatus) => void;
  onCardClick: (id: string) => void;
}

function KanbanColumn({
  status,
  applications,
  dragId,
  dragOverCol,
  onDragStart,
  onDragOver,
  onDrop,
  onCardClick,
}: KanbanColumnProps) {
  const meta = STATUS_META[status];
  return (
    <div
      className="flex w-72 shrink-0 flex-col"
      onDragOver={(e) => {
        e.preventDefault();
        onDragOver(status);
      }}
      onDrop={() => onDrop(status)}
    >
      <div className="mb-3 flex items-center justify-between rounded-lg bg-card px-3 py-2">
        <div className="flex items-center gap-2">
          <span className={cn("h-2 w-2 rounded-full", meta.badgeClass.split(" ")[0])} />
          <span className="text-sm font-medium">{meta.label}</span>
        </div>
        <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
          {applications.length}
        </span>
      </div>
      <div
        className={cn(
          "scrollbar-thin flex-1 space-y-2.5 overflow-y-auto rounded-lg p-1 transition-colors",
          dragOverCol === status && dragId && "bg-primary/5",
        )}
      >
        {applications.map((app) => (
          <ApplicationCard
            key={app.id}
            application={app}
            isDragging={dragId === app.id}
            onDragStart={() => onDragStart(app.id)}
            onDragEnd={() => onDragStart(null)}
            onClick={() => onCardClick(app.id)}
          />
        ))}
        {applications.length === 0 && (
          <div className="flex h-20 items-center justify-center rounded-lg border border-dashed border-border text-xs text-muted-foreground">
            拖拽卡片到此处
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Application Card ---------------- */

interface ApplicationCardProps {
  application: Application;
  isDragging: boolean;
  onDragStart: () => void;
  onDragEnd: () => void;
  onClick: () => void;
}

function ApplicationCard({
  application: app,
  isDragging,
  onDragStart,
  onDragEnd,
  onClick,
}: ApplicationCardProps) {
  const priority = PRIORITY_META[app.priority];
  return (
    <div
      draggable
      onDragStart={(e) => {
        e.dataTransfer.effectAllowed = "move";
        onDragStart();
      }}
      onDragEnd={onDragEnd}
      onClick={onClick}
      className={cn(
        "cursor-pointer rounded-xl border border-border border-l-4 bg-card p-3 shadow-sm transition-all hover:shadow-md active:scale-[0.99]",
        priority.border,
        isDragging && "opacity-40",
      )}
    >
      <div className="mb-1.5 flex items-start justify-between gap-2">
        <h4 className="truncate text-sm font-semibold leading-tight">
          {app.company}
        </h4>
        <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", priority.dot)} />
      </div>
      <p className="mb-2 truncate text-xs text-muted-foreground">{app.position}</p>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
        {app.salary && (
          <span className="flex items-center gap-0.5">
            <DollarSign className="h-3 w-3" strokeWidth={1.5} />
            {app.salary}
          </span>
        )}
        {app.location && (
          <span className="flex items-center gap-0.5">
            <MapPin className="h-3 w-3" strokeWidth={1.5} />
            {app.location}
          </span>
        )}
        <span className="rounded bg-muted px-1.5 py-0.5">
          {SOURCE_META[app.source]}
        </span>
      </div>
      {app.next_interview_at && (
        <div className="mt-2 flex items-center gap-1 rounded-lg bg-amber-500/10 px-2 py-1 text-[11px] font-medium text-amber-600 dark:text-amber-400">
          <Calendar className="h-3 w-3" strokeWidth={1.5} />
          {formatDate(app.next_interview_at)}
        </div>
      )}
    </div>
  );
}

/* ---------------- Empty State ---------------- */

function EmptyState({ onCreate }: { onCreate: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
        <Inbox className="h-8 w-8" strokeWidth={1.5} />
      </div>
      <h3 className="text-lg font-medium">还没有投递记录</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">
        点击「新建投递」开始记录你的求职进度，拖拽卡片即可更新状态。
      </p>
      <Button className="mt-5" onClick={onCreate}>
        <Plus className="h-4 w-4" strokeWidth={1.5} />
        新建投递
      </Button>
    </div>
  );
}

/* ---------------- Create Dialog ---------------- */

interface CreateApplicationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreate: (input: CreateApplicationInput) => Promise<void>;
}

function CreateApplicationDialog({
  open,
  onOpenChange,
  onCreate,
}: CreateApplicationDialogProps) {
  const [form, setForm] = useState<CreateApplicationInput>({
    company: "",
    position: "",
    source: "manual",
    priority: "medium",
    status: "saved",
  });

  const reset = () =>
    setForm({
      company: "",
      position: "",
      job_url: "",
      salary: "",
      location: "",
      source: "manual",
      priority: "medium",
      status: "saved",
      next_interview_at: "",
      notes: "",
    });

  const submit = async () => {
    if (!form.company.trim() || !form.position.trim()) {
      toast.error("请填写公司和职位");
      return;
    }
    await onCreate({
      ...form,
      company: form.company.trim(),
      position: form.position.trim(),
    });
    reset();
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) reset();
        onOpenChange(o);
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>新建投递记录</DialogTitle>
          <DialogDescription>记录一次新的求职投递</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <Field label="公司名称" required>
            <Input
              value={form.company}
              onChange={(e) => setForm({ ...form, company: e.target.value })}
              placeholder="例如 字节跳动"
            />
          </Field>
          <Field label="职位名称" required>
            <Input
              value={form.position}
              onChange={(e) => setForm({ ...form, position: e.target.value })}
              placeholder="例如 前端工程师"
            />
          </Field>
          <Field label="岗位链接" className="col-span-2">
            <Input
              value={form.job_url ?? ""}
              onChange={(e) => setForm({ ...form, job_url: e.target.value })}
              placeholder="https://..."
            />
          </Field>
          <Field label="薪资范围">
            <Input
              value={form.salary ?? ""}
              onChange={(e) => setForm({ ...form, salary: e.target.value })}
              placeholder="例如 20-35K·15薪"
            />
          </Field>
          <Field label="工作地点">
            <Input
              value={form.location ?? ""}
              onChange={(e) => setForm({ ...form, location: e.target.value })}
              placeholder="例如 北京"
            />
          </Field>
          <Field label="来源">
            <Select
              value={form.source}
              onValueChange={(v) => setForm({ ...form, source: v as JobSource })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SOURCES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {SOURCE_META[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="优先级">
            <Select
              value={form.priority}
              onValueChange={(v) =>
                setForm({ ...form, priority: v as Priority })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PRIORITIES.map((p) => (
                  <SelectItem key={p} value={p}>
                    {PRIORITY_META[p].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="初始状态" className="col-span-2">
            <Select
              value={form.status}
              onValueChange={(v) =>
                setForm({ ...form, status: v as ApplicationStatus })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ALL_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_META[s].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={submit}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
            创建
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Detail Dialog ---------------- */

interface ApplicationDetailDialogProps {
  application: Application;
  onOpenChange: (open: boolean) => void;
  onUpdate: (id: string, input: Partial<CreateApplicationInput>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onTransition: (id: string, status: ApplicationStatus) => Promise<void>;
}

function ApplicationDetailDialog({
  application: app,
  onOpenChange,
  onUpdate,
  onDelete,
  onTransition,
}: ApplicationDetailDialogProps) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<CreateApplicationInput>({
    company: app.company,
    position: app.position,
    job_url: app.job_url,
    salary: app.salary,
    location: app.location,
    source: app.source,
    priority: app.priority,
    next_interview_at: app.next_interview_at,
    notes: app.notes,
  });
  const [timeline, setTimeline] = useState<
    { id: string; to_status: ApplicationStatus; from_status: ApplicationStatus | null; created_at: string; note?: string }[]
  >([]);

  const { fetchTimeline, timelines } = useApplicationStore();

  useEffect(() => {
    void fetchTimeline(app.id);
  }, [app.id, fetchTimeline]);

  useEffect(() => {
    setTimeline(timelines[app.id] ?? []);
  }, [timelines, app.id]);

  const handleSave = async () => {
    await onUpdate(app.id, form);
    setEditing(false);
  };

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Badge className={STATUS_META[app.status].badgeClass}>
              {STATUS_META[app.status].label}
            </Badge>
            <Badge variant="outline">
              {PRIORITY_META[app.priority].label}优先级
            </Badge>
          </div>
          <DialogTitle className="mt-2">{app.company}</DialogTitle>
          <DialogDescription>{app.position}</DialogDescription>
        </DialogHeader>

        {editing ? (
          <div className="grid grid-cols-2 gap-4">
            <Field label="公司">
              <Input
                value={form.company}
                onChange={(e) => setForm({ ...form, company: e.target.value })}
              />
            </Field>
            <Field label="职位">
              <Input
                value={form.position}
                onChange={(e) => setForm({ ...form, position: e.target.value })}
              />
            </Field>
            <Field label="薪资">
              <Input
                value={form.salary ?? ""}
                onChange={(e) => setForm({ ...form, salary: e.target.value })}
              />
            </Field>
            <Field label="地点">
              <Input
                value={form.location ?? ""}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
              />
            </Field>
            <Field label="下次面试时间">
              <Input
                type="datetime-local"
                value={form.next_interview_at ? form.next_interview_at.slice(0, 16) : ""}
                onChange={(e) =>
                  setForm({ ...form, next_interview_at: e.target.value })
                }
              />
            </Field>
            <Field label="备注" className="col-span-2">
              <Textarea
                value={form.notes ?? ""}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="记录备注..."
              />
            </Field>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <InfoRow icon={DollarSign} label="薪资" value={app.salary || "-"} />
              <InfoRow icon={MapPin} label="地点" value={app.location || "-"} />
              <InfoRow icon={Link2} label="来源" value={SOURCE_META[app.source]} />
              <InfoRow
                icon={Calendar}
                label="下次面试"
                value={app.next_interview_at ? formatDate(app.next_interview_at) : "-"}
              />
            </div>
            {app.job_url && (
              <a
                href={app.job_url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
              >
                <Link2 className="h-4 w-4" strokeWidth={1.5} />
                查看岗位链接
              </a>
            )}
            {app.notes && (
              <div className="rounded-lg bg-muted p-3 text-sm">
                <p className="mb-1 text-xs font-medium text-muted-foreground">备注</p>
                {app.notes}
              </div>
            )}

            {/* Status transition */}
            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                变更状态
              </p>
              <div className="flex flex-wrap gap-1.5">
                {ALL_STATUSES.map((s) => (
                  <button
                    key={s}
                    disabled={s === app.status}
                    onClick={() => onTransition(app.id, s)}
                    className={cn(
                      "rounded-full border px-2.5 py-1 text-xs font-medium transition-colors disabled:opacity-40",
                      s === app.status
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:bg-accent",
                    )}
                  >
                    {STATUS_META[s].label}
                  </button>
                ))}
              </div>
            </div>

            {/* Timeline */}
            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                状态时间线
              </p>
              <Timeline entries={timeline} />
            </div>
          </div>
        )}

        <DialogFooter className="justify-between sm:justify-between">
          <div>
            {editing ? (
              <Button variant="outline" onClick={() => setEditing(false)}>
                取消
              </Button>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" strokeWidth={1.5} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={() => onDelete(app.id)}
                  >
                    <Trash2 className="h-4 w-4" strokeWidth={1.5} />
                    删除记录
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              关闭
            </Button>
            {editing ? (
              <Button onClick={handleSave}>保存</Button>
            ) : (
              <Button variant="outline" onClick={() => setEditing(true)}>
                <Pencil className="h-4 w-4" strokeWidth={1.5} />
                编辑
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Timeline ---------------- */

function Timeline({
  entries,
}: {
  entries: {
    id: string;
    to_status: ApplicationStatus;
    from_status: ApplicationStatus | null;
    created_at: string;
    note?: string;
  }[];
}) {
  if (entries.length === 0) {
    return (
      <p className="text-xs text-muted-foreground">暂无状态变更记录</p>
    );
  }
  return (
    <div className="relative space-y-3 pl-5">
      <span className="absolute left-1.5 top-1 bottom-1 w-px bg-border" />
      {entries.map((entry) => (
        <div key={entry.id} className="relative">
          <span
            className="absolute -left-[14px] top-1 h-2.5 w-2.5 rounded-full ring-2 ring-background"
            style={{ backgroundColor: STATUS_COLORS[entry.to_status] }}
          />
          <div className="flex items-center gap-2 text-sm">
            <span className="font-medium">
              {entry.from_status
                ? STATUS_META[entry.from_status].label
                : "新建"}
            </span>
            <ArrowRightCircle
              className="h-3.5 w-3.5 text-muted-foreground"
              strokeWidth={1.5}
            />
            <Badge className={STATUS_META[entry.to_status].badgeClass}>
              {STATUS_META[entry.to_status].label}
            </Badge>
            <span className="ml-auto text-xs text-muted-foreground">
              {formatDate(entry.created_at)}
            </span>
          </div>
          {entry.note && (
            <p className="mt-1 text-xs text-muted-foreground">{entry.note}</p>
          )}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Helpers ---------------- */

function Field({
  label,
  required,
  className,
  children,
}: {
  label: string;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="ml-0.5 text-destructive">*</span>}
      </label>
      {children}
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
      <span className="text-muted-foreground">{label}</span>
      <span className="ml-auto font-medium">{value}</span>
    </div>
  );
}
