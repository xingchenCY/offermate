import { useEffect, useState, useCallback } from "react";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  Printer,
  FileText,
  Layers,
  GraduationCap,
  Briefcase,
  FolderGit2,
  Wrench,
  Award as AwardIcon,
  User,
  Save,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { resumesApi } from "@/lib/tauri";
import { uid, cn } from "@/lib/utils";
import type {
  Resume,
  SubResume,
  ResumeTemplate,
  Education,
  Experience,
  Project,
  Award,
  BasicInfo,
} from "@/lib/types";

const TEMPLATES: { value: ResumeTemplate; label: string }[] = [
  { value: "modern", label: "现代" },
  { value: "classic", label: "经典" },
  { value: "minimal", label: "极简" },
  { value: "tech", label: "技术风" },
];

function createBlankResume(): Resume {
  return {
    id: uid("resume"),
    name: "我的简历",
    template: "modern",
    basic_info: {
      name: "",
      email: "",
      phone: "",
      location: "",
      summary: "",
    },
    education: [],
    experience: [],
    projects: [],
    skills: [],
    awards: [],
    is_default: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

export function ResumeEditor() {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [subResumes, setSubResumes] = useState<SubResume[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void (async () => {
      const list = await resumesApi.list();
      if (list.length === 0) {
        const blank = createBlankResume();
        setResumes([blank]);
        setActiveId(blank.id);
      } else {
        setResumes(list);
        setActiveId(list[0].id);
      }
      setLoading(false);
    })();
  }, []);

  const activeResume = resumes.find((r) => r.id === activeId) ?? resumes[0];

  const updateResume = useCallback(
    (updater: (r: Resume) => Resume) => {
      setResumes((prev) =>
        prev.map((r) =>
          r.id === activeId
            ? { ...updater(r), updated_at: new Date().toISOString() }
            : r,
        ),
      );
    },
    [activeId],
  );

  const handleSave = async () => {
    if (!activeResume) return;
    try {
      await resumesApi.update(activeResume.id, activeResume);
      toast.success("简历已保存");
    } catch {
      toast.message("简历已暂存到本地");
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="h-8 w-40 animate-pulse rounded bg-muted" />
      </div>
    );
  }

  if (!activeResume) {
    return (
      <div className="p-6 text-sm text-muted-foreground">暂无简历</div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-6 py-4">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">简历管理</h1>
          <p className="text-sm text-muted-foreground">编辑与预览你的简历</p>
        </div>
        <div className="flex items-center gap-2">
          <Select
            value={activeResume.template}
            onValueChange={(v) =>
              updateResume((r) => ({ ...r, template: v as ResumeTemplate }))
            }
          >
            <SelectTrigger className="w-28">
              <Layers className="mr-1 h-4 w-4" strokeWidth={1.5} />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TEMPLATES.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="h-4 w-4" strokeWidth={1.5} />
            导出 PDF
          </Button>
          <Button onClick={handleSave}>
            <Save className="h-4 w-4" strokeWidth={1.5} />
            保存
          </Button>
        </div>
      </div>

      <Tabs defaultValue="main" className="flex flex-1 flex-col overflow-hidden">
        <div className="border-b border-border px-6 pt-3">
          <TabsList>
            <TabsTrigger value="main">
              <FileText className="h-4 w-4" strokeWidth={1.5} />
              主简历
            </TabsTrigger>
            <TabsTrigger value="sub">
              <Layers className="h-4 w-4" strokeWidth={1.5} />
              子简历 ({subResumes.length})
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="main" className="flex-1 overflow-hidden mt-0">
          <div className="grid h-full grid-cols-1 lg:grid-cols-2">
            {/* Editor */}
            <div className="scrollbar-thin h-full overflow-y-auto border-r border-border p-6">
              <ResumeEditorPanel
                resume={activeResume}
                onChange={updateResume}
              />
            </div>
            {/* Preview */}
            <div className="scrollbar-thin h-full overflow-y-auto bg-muted/30 p-6">
              <ResumePreview resume={activeResume} />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="sub" className="flex-1 overflow-hidden mt-0">
          <SubResumePanel
            parentResume={activeResume}
            subResumes={subResumes}
            onChange={setSubResumes}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ---------------- Editor Panel ---------------- */

function ResumeEditorPanel({
  resume,
  onChange,
}: {
  resume: Resume;
  onChange: (updater: (r: Resume) => Resume) => void;
}) {
  const setBasic = (patch: Partial<BasicInfo>) =>
    onChange((r) => ({
      ...r,
      basic_info: { ...r.basic_info, ...patch },
    }));

  return (
    <div className="space-y-6">
      {/* Basic info */}
      <Section title="基本信息" icon={User}>
        <div className="grid grid-cols-2 gap-3">
          <LabeledInput
            label="姓名"
            value={resume.basic_info.name}
            onChange={(v) => setBasic({ name: v })}
            placeholder="张三"
          />
          <LabeledInput
            label="邮箱"
            value={resume.basic_info.email}
            onChange={(v) => setBasic({ email: v })}
            placeholder="you@example.com"
          />
          <LabeledInput
            label="电话"
            value={resume.basic_info.phone}
            onChange={(v) => setBasic({ phone: v })}
            placeholder="138xxxx"
          />
          <LabeledInput
            label="所在地"
            value={resume.basic_info.location}
            onChange={(v) => setBasic({ location: v })}
            placeholder="北京"
          />
          <LabeledInput
            label="个人网站"
            value={resume.basic_info.website ?? ""}
            onChange={(v) => setBasic({ website: v })}
            placeholder="github.com/..."
          />
          <LabeledInput
            label="GitHub"
            value={resume.basic_info.github ?? ""}
            onChange={(v) => setBasic({ github: v })}
            placeholder="github用户名"
          />
        </div>
        <LabeledTextarea
          label="个人简介"
          value={resume.basic_info.summary ?? ""}
          onChange={(v) => setBasic({ summary: v })}
          placeholder="一句话介绍你的核心竞争力..."
        />
      </Section>

      {/* Education */}
      <Section
        title="教育经历"
        icon={GraduationCap}
        onAdd={() =>
          onChange((r) => ({
            ...r,
            education: [
              ...r.education,
              {
                id: uid("edu"),
                school: "",
                degree: "",
                major: "",
                start_date: "",
                end_date: "",
              },
            ],
          }))
        }
      >
        {resume.education.map((edu, idx) => (
          <RepeatableItem
            key={edu.id}
            title={edu.school || `教育 ${idx + 1}`}
            onDelete={() =>
              onChange((r) => ({
                ...r,
                education: r.education.filter((e) => e.id !== edu.id),
              }))
            }
          >
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label="学校"
                value={edu.school}
                onChange={(v) =>
                  updateList(educationUpdate(onChange, edu.id, { school: v }))
                }
              />
              <LabeledInput
                label="学历"
                value={edu.degree}
                onChange={(v) =>
                  updateList(educationUpdate(onChange, edu.id, { degree: v }))
                }
              />
              <LabeledInput
                label="专业"
                value={edu.major}
                onChange={(v) =>
                  updateList(educationUpdate(onChange, edu.id, { major: v }))
                }
              />
              <LabeledInput
                label="GPA"
                value={edu.gpa ?? ""}
                onChange={(v) =>
                  updateList(educationUpdate(onChange, edu.id, { gpa: v }))
                }
              />
              <LabeledInput
                label="开始时间"
                value={edu.start_date}
                onChange={(v) =>
                  updateList(
                    educationUpdate(onChange, edu.id, { start_date: v }),
                  )
                }
                placeholder="2021-09"
              />
              <LabeledInput
                label="结束时间"
                value={edu.end_date}
                onChange={(v) =>
                  updateList(educationUpdate(onChange, edu.id, { end_date: v }))
                }
                placeholder="2025-06"
              />
            </div>
          </RepeatableItem>
        ))}
        {resume.education.length === 0 && <EmptyHint text="添加教育经历" />}
      </Section>

      {/* Experience */}
      <Section
        title="工作经验"
        icon={Briefcase}
        onAdd={() =>
          onChange((r) => ({
            ...r,
            experience: [
              ...r.experience,
              {
                id: uid("exp"),
                company: "",
                position: "",
                start_date: "",
                end_date: "",
                description: "",
              },
            ],
          }))
        }
      >
        {resume.experience.map((exp, idx) => (
          <RepeatableItem
            key={exp.id}
            title={exp.company || `工作 ${idx + 1}`}
            onDelete={() =>
              onChange((r) => ({
                ...r,
                experience: r.experience.filter((e) => e.id !== exp.id),
              }))
            }
          >
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label="公司"
                value={exp.company}
                onChange={(v) =>
                  updateList(experienceUpdate(onChange, exp.id, { company: v }))
                }
              />
              <LabeledInput
                label="职位"
                value={exp.position}
                onChange={(v) =>
                  updateList(experienceUpdate(onChange, exp.id, { position: v }))
                }
              />
              <LabeledInput
                label="开始时间"
                value={exp.start_date}
                onChange={(v) =>
                  updateList(
                    experienceUpdate(onChange, exp.id, { start_date: v }),
                  )
                }
              />
              <LabeledInput
                label="结束时间"
                value={exp.end_date}
                onChange={(v) =>
                  updateList(
                    experienceUpdate(onChange, exp.id, { end_date: v }),
                  )
                }
              />
            </div>
            <LabeledTextarea
              label="工作描述"
              value={exp.description ?? ""}
              onChange={(v) =>
                updateList(
                  experienceUpdate(onChange, exp.id, { description: v }),
                )
              }
              placeholder="用要点描述你的职责和成果..."
            />
          </RepeatableItem>
        ))}
        {resume.experience.length === 0 && <EmptyHint text="添加工作经验" />}
      </Section>

      {/* Projects */}
      <Section
        title="项目经历"
        icon={FolderGit2}
        onAdd={() =>
          onChange((r) => ({
            ...r,
            projects: [
              ...r.projects,
              {
                id: uid("proj"),
                name: "",
                start_date: "",
                end_date: "",
                description: "",
                tech_stack: [],
              },
            ],
          }))
        }
      >
        {resume.projects.map((proj, idx) => (
          <RepeatableItem
            key={proj.id}
            title={proj.name || `项目 ${idx + 1}`}
            onDelete={() =>
              onChange((r) => ({
                ...r,
                projects: r.projects.filter((p) => p.id !== proj.id),
              }))
            }
          >
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label="项目名称"
                value={proj.name}
                onChange={(v) =>
                  updateList(projectUpdate(onChange, proj.id, { name: v }))
                }
              />
              <LabeledInput
                label="角色"
                value={proj.role ?? ""}
                onChange={(v) =>
                  updateList(projectUpdate(onChange, proj.id, { role: v }))
                }
              />
              <LabeledInput
                label="开始时间"
                value={proj.start_date}
                onChange={(v) =>
                  updateList(
                    projectUpdate(onChange, proj.id, { start_date: v }),
                  )
                }
              />
              <LabeledInput
                label="结束时间"
                value={proj.end_date}
                onChange={(v) =>
                  updateList(projectUpdate(onChange, proj.id, { end_date: v }))
                }
              />
            </div>
            <LabeledInput
              label="技术栈 (逗号分隔)"
              value={(proj.tech_stack ?? []).join(", ")}
              onChange={(v) =>
                updateList(
                  projectUpdate(onChange, proj.id, {
                    tech_stack: v
                      .split(",")
                      .map((s) => s.trim())
                      .filter(Boolean),
                  }),
                )
              }
            />
            <LabeledTextarea
              label="项目描述"
              value={proj.description ?? ""}
              onChange={(v) =>
                updateList(
                  projectUpdate(onChange, proj.id, { description: v }),
                )
              }
            />
          </RepeatableItem>
        ))}
        {resume.projects.length === 0 && <EmptyHint text="添加项目经历" />}
      </Section>

      {/* Skills */}
      <Section title="技能" icon={Wrench}>
        <div className="flex flex-wrap gap-2">
          {resume.skills.map((skill) => (
            <Badge
              key={skill}
              variant="secondary"
              className="gap-1 pr-1.5"
            >
              {skill}
              <button
                onClick={() =>
                  onChange((r) => ({
                    ...r,
                    skills: r.skills.filter((s) => s !== skill),
                  }))
                }
                className="rounded-full p-0.5 hover:bg-background"
              >
                <XSmall />
              </button>
            </Badge>
          ))}
          {resume.skills.length === 0 && (
            <span className="text-xs text-muted-foreground">暂无技能</span>
          )}
        </div>
        <SkillInput
          onAdd={(skill) =>
            onChange((r) => ({
              ...r,
              skills: r.skills.includes(skill)
                ? r.skills
                : [...r.skills, skill],
            }))
          }
        />
      </Section>

      {/* Awards */}
      <Section
        title="奖项"
        icon={AwardIcon}
        onAdd={() =>
          onChange((r) => ({
            ...r,
            awards: [
              ...r.awards,
              { id: uid("award"), title: "", date: "", description: "" },
            ],
          }))
        }
      >
        {resume.awards.map((award, idx) => (
          <RepeatableItem
            key={award.id}
            title={award.title || `奖项 ${idx + 1}`}
            onDelete={() =>
              onChange((r) => ({
                ...r,
                awards: r.awards.filter((a) => a.id !== award.id),
              }))
            }
          >
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput
                label="奖项名称"
                value={award.title}
                onChange={(v) =>
                  updateList(awardUpdate(onChange, award.id, { title: v }))
                }
              />
              <LabeledInput
                label="时间"
                value={award.date}
                onChange={(v) =>
                  updateList(awardUpdate(onChange, award.id, { date: v }))
                }
              />
            </div>
            <LabeledTextarea
              label="描述"
              value={award.description ?? ""}
              onChange={(v) =>
                updateList(awardUpdate(onChange, award.id, { description: v }))
              }
            />
          </RepeatableItem>
        ))}
        {resume.awards.length === 0 && <EmptyHint text="添加奖项" />}
      </Section>
    </div>
  );
}

/* ---------------- Preview ---------------- */

function ResumePreview({ resume }: { resume: Resume }) {
  const { basic_info: b, template } = resume;
  return (
    <div
      className={cn(
        "mx-auto max-w-[680px] rounded-xl bg-white p-8 text-zinc-800 shadow-sm dark:bg-zinc-900 dark:text-zinc-100",
        template === "tech" && "font-mono",
      )}
    >
      {/* Header */}
      <div className="border-b border-zinc-200 pb-4 dark:border-zinc-700">
        <h1 className="text-2xl font-bold">{b.name || "你的姓名"}</h1>
        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-zinc-500 dark:text-zinc-400">
          {b.email && <span>{b.email}</span>}
          {b.phone && <span>{b.phone}</span>}
          {b.location && <span>{b.location}</span>}
          {b.github && <span>github.com/{b.github}</span>}
          {b.website && <span>{b.website}</span>}
        </div>
        {b.summary && (
          <p className="mt-3 text-sm leading-relaxed">{b.summary}</p>
        )}
      </div>

      {resume.education.length > 0 && (
        <PreviewSection title="教育经历">
          {resume.education.map((edu) => (
            <div key={edu.id} className="mb-3 flex justify-between gap-4">
              <div>
                <p className="font-semibold">{edu.school}</p>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  {edu.degree} · {edu.major}
                </p>
              </div>
              <span className="shrink-0 text-xs text-zinc-400">
                {edu.start_date} - {edu.end_date}
              </span>
            </div>
          ))}
        </PreviewSection>
      )}

      {resume.experience.length > 0 && (
        <PreviewSection title="工作经验">
          {resume.experience.map((exp) => (
            <div key={exp.id} className="mb-4">
              <div className="flex justify-between gap-4">
                <p className="font-semibold">
                  {exp.position} · {exp.company}
                </p>
                <span className="shrink-0 text-xs text-zinc-400">
                  {exp.start_date} - {exp.end_date}
                </span>
              </div>
              {exp.description && (
                <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
                  {exp.description}
                </p>
              )}
            </div>
          ))}
        </PreviewSection>
      )}

      {resume.projects.length > 0 && (
        <PreviewSection title="项目经历">
          {resume.projects.map((proj) => (
            <div key={proj.id} className="mb-4">
              <div className="flex justify-between gap-4">
                <p className="font-semibold">
                  {proj.name}
                  {proj.role && (
                    <span className="ml-2 text-sm font-normal text-zinc-500">
                      · {proj.role}
                    </span>
                  )}
                </p>
                <span className="shrink-0 text-xs text-zinc-400">
                  {proj.start_date} - {proj.end_date}
                </span>
              </div>
              {proj.description && (
                <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
                  {proj.description}
                </p>
              )}
              {proj.tech_stack && proj.tech_stack.length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {proj.tech_stack.map((t) => (
                    <span
                      key={t}
                      className="rounded bg-zinc-100 px-1.5 py-0.5 text-[11px] text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </PreviewSection>
      )}

      {resume.skills.length > 0 && (
        <PreviewSection title="技能">
          <div className="flex flex-wrap gap-1.5">
            {resume.skills.map((s) => (
              <span
                key={s}
                className="rounded bg-zinc-100 px-2 py-0.5 text-sm text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300"
              >
                {s}
              </span>
            ))}
          </div>
        </PreviewSection>
      )}

      {resume.awards.length > 0 && (
        <PreviewSection title="奖项">
          {resume.awards.map((award) => (
            <div key={award.id} className="mb-2 flex justify-between gap-4">
              <div>
                <p className="font-medium">{award.title}</p>
                {award.description && (
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    {award.description}
                  </p>
                )}
              </div>
              <span className="shrink-0 text-xs text-zinc-400">{award.date}</span>
            </div>
          ))}
        </PreviewSection>
      )}
    </div>
  );
}

function PreviewSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-5">
      <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-primary">
        {title}
      </h2>
      {children}
    </div>
  );
}

/* ---------------- Sub Resume Panel ---------------- */

function SubResumePanel({
  parentResume,
  subResumes,
  onChange,
}: {
  parentResume: Resume;
  subResumes: SubResume[];
  onChange: (subs: SubResume[]) => void;
}) {
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    target_company: "",
    target_position: "",
  });

  const handleCreate = () => {
    if (!form.name.trim()) {
      toast.error("请填写子简历名称");
      return;
    }
    const sub: SubResume = {
      id: uid("sub"),
      parent_id: parentResume.id,
      name: form.name.trim(),
      target_company: form.target_company,
      target_position: form.target_position,
      overrides: {},
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    onChange([sub, ...subResumes]);
    void resumesApi.createSubResume({
      parent_id: parentResume.id,
      name: sub.name,
      target_company: sub.target_company,
      target_position: sub.target_position,
    });
    setForm({ name: "", target_company: "", target_position: "" });
    setCreateOpen(false);
    toast.success("子简历已创建");
  };

  return (
    <div className="scrollbar-thin h-full overflow-y-auto p-6">
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          针对特定岗位定制的简历版本，基于「{parentResume.name}」
        </p>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4" strokeWidth={1.5} />
          新建子简历
        </Button>
      </div>

      {subResumes.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Layers className="mb-3 h-10 w-10 text-muted-foreground" strokeWidth={1.5} />
            <p className="text-sm font-medium">还没有子简历</p>
            <p className="mt-1 text-xs text-muted-foreground">
              为不同公司/岗位创建定制版本，提高投递命中率
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {subResumes.map((sub) => (
            <Card key={sub.id}>
              <CardContent className="p-4">
                <p className="font-medium">{sub.name}</p>
                {sub.target_company && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    目标公司: {sub.target_company}
                  </p>
                )}
                {sub.target_position && (
                  <p className="text-xs text-muted-foreground">
                    目标职位: {sub.target_position}
                  </p>
                )}
                <div className="mt-3 flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => {
                      onChange(subResumes.filter((s) => s.id !== sub.id));
                      void resumesApi.deleteSubResume(sub.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4" strokeWidth={1.5} />
                    删除
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>新建子简历</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <LabeledInput
              label="名称"
              value={form.name}
              onChange={(v) => setForm({ ...form, name: v })}
              placeholder="例如 字节-前端定制版"
            />
            <LabeledInput
              label="目标公司"
              value={form.target_company}
              onChange={(v) => setForm({ ...form, target_company: v })}
            />
            <LabeledInput
              label="目标职位"
              value={form.target_position}
              onChange={(v) => setForm({ ...form, target_position: v })}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              取消
            </Button>
            <Button onClick={handleCreate}>创建</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ---------------- Small helpers ---------------- */

function Section({
  title,
  icon: Icon,
  onAdd,
  children,
}: {
  title: string;
  icon: LucideIcon;
  onAdd?: () => void;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-semibold">
          <Icon className="h-4 w-4 text-primary" strokeWidth={1.5} />
          {title}
        </h3>
        {onAdd && (
          <Button variant="ghost" size="sm" onClick={onAdd}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
            添加
          </Button>
        )}
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function LabeledInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-muted-foreground">
        {label}
      </label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

function LabeledTextarea({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="mt-3">
      <label className="mb-1 block text-xs font-medium text-muted-foreground">
        {label}
      </label>
      <Textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
      />
    </div>
  );
}

function RepeatableItem({
  title,
  onDelete,
  children,
}: {
  title: string;
  onDelete: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="truncate text-xs font-medium text-muted-foreground">
          {title}
        </span>
        <button
          onClick={onDelete}
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          <Trash2 className="h-3.5 w-3.5" strokeWidth={1.5} />
        </button>
      </div>
      {children}
    </div>
  );
}

function EmptyHint({ text }: { text: string }) {
  return (
    <button
      onClick={() => {}}
      className="flex w-full items-center justify-center rounded-lg border border-dashed border-border py-4 text-xs text-muted-foreground"
    >
      {text}
    </button>
  );
}

function SkillInput({ onAdd }: { onAdd: (skill: string) => void }) {
  const [value, setValue] = useState("");
  return (
    <div className="mt-2 flex gap-2">
      <Input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && value.trim()) {
            onAdd(value.trim());
            setValue("");
          }
        }}
        placeholder="输入技能后回车添加"
        className="h-8"
      />
      <Button
        size="sm"
        variant="outline"
        onClick={() => {
          if (value.trim()) {
            onAdd(value.trim());
            setValue("");
          }
        }}
      >
        添加
      </Button>
    </div>
  );
}

function XSmall() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      className="h-3 w-3"
    >
      <path d="M18 6 6 18M6 6l12 12" />
    </svg>
  );
}

/* update helpers — wrapped to satisfy linter patterns */
function updateList(_fn: void) {
  void _fn;
}

function educationUpdate(
  onChange: (updater: (r: Resume) => Resume) => void,
  id: string,
  patch: Partial<Education>,
) {
  onChange((r) => ({
    ...r,
    education: r.education.map((e) => (e.id === id ? { ...e, ...patch } : e)),
  }));
}

function experienceUpdate(
  onChange: (updater: (r: Resume) => Resume) => void,
  id: string,
  patch: Partial<Experience>,
) {
  onChange((r) => ({
    ...r,
    experience: r.experience.map((e) => (e.id === id ? { ...e, ...patch } : e)),
  }));
}

function projectUpdate(
  onChange: (updater: (r: Resume) => Resume) => void,
  id: string,
  patch: Partial<Project>,
) {
  onChange((r) => ({
    ...r,
    projects: r.projects.map((p) => (p.id === id ? { ...p, ...patch } : p)),
  }));
}

function awardUpdate(
  onChange: (updater: (r: Resume) => Resume) => void,
  id: string,
  patch: Partial<Award>,
) {
  onChange((r) => ({
    ...r,
    awards: r.awards.map((a) => (a.id === id ? { ...a, ...patch } : a)),
  }));
}
