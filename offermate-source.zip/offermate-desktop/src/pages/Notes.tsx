import { useEffect, useMemo, useState, useCallback } from "react";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Trash2,
  NotebookPen,
  Eye,
  Pencil,
  Tag,
  Link2,
  Inbox,
  Save,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { notesApi } from "@/lib/tauri";
import { useApplicationStore } from "@/stores/applicationStore";
import { uid, cn, formatDate, timeAgo } from "@/lib/utils";
import type { Note, NoteCategory } from "@/lib/types";

const CATEGORIES: { value: NoteCategory; label: string }[] = [
  { value: "interview", label: "面经" },
  { value: "tech", label: "技术" },
  { value: "company", label: "公司" },
  { value: "general", label: "通用" },
];

const CATEGORY_BADGE: Record<NoteCategory, string> = {
  interview: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  tech: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300",
  company: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
  general: "bg-muted text-muted-foreground",
};

export function Notes() {
  const { applications } = useApplicationStore();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<NoteCategory | "all">("all");
  const [activeId, setActiveId] = useState<string>("");
  const [previewMode, setPreviewMode] = useState(false);
  const [draft, setDraft] = useState<Note | null>(null);

  useEffect(() => {
    void (async () => {
      const list = await notesApi.list();
      setNotes(list);
      setLoading(false);
      if (list.length > 0) {
        setActiveId(list[0].id);
        setDraft(list[0]);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return notes.filter((n) => {
      if (category !== "all" && n.category !== category) return false;
      if (q) {
        const hay = `${n.title} ${n.content} ${n.tags.join(" ")}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [notes, search, category]);

  const activeNote = notes.find((n) => n.id === activeId);

  const handleNew = useCallback(() => {
    const note: Note = {
      id: uid("note"),
      title: "新建笔记",
      content: "",
      category: "general",
      tags: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setNotes((prev) => [note, ...prev]);
    setActiveId(note.id);
    setDraft(note);
    setPreviewMode(false);
  }, []);

  const handleSave = useCallback(async () => {
    if (!draft) return;
    const existing = notes.find((n) => n.id === draft.id);
    try {
      if (existing) {
        const updated = await notesApi.update(draft.id, draft);
        setNotes((prev) => prev.map((n) => (n.id === draft.id ? updated : n)));
      } else {
        const created = await notesApi.create({
          title: draft.title,
          content: draft.content,
          category: draft.category,
          tags: draft.tags,
          application_id: draft.application_id,
        });
        setNotes((prev) =>
          prev.map((n) => (n.id === draft.id ? created : n)),
        );
      }
      toast.success("已保存");
    } catch {
      toast.message("已暂存到本地");
    }
  }, [draft, notes]);

  const handleDelete = useCallback(
    async (id: string) => {
      await notesApi.delete(id);
      setNotes((prev) => prev.filter((n) => n.id !== id));
      if (activeId === id) {
        const remaining = notes.filter((n) => n.id !== id);
        setActiveId(remaining[0]?.id ?? "");
        setDraft(remaining[0] ?? null);
      }
      toast.success("已删除");
    },
    [activeId, notes],
  );

  const updateDraft = (patch: Partial<Note>) =>
    setDraft((d) => (d ? { ...d, ...patch, updated_at: new Date().toISOString() } : d));

  return (
    <div className="flex h-full">
      {/* Note list */}
      <div className="flex w-80 shrink-0 flex-col border-r border-border">
        <div className="border-b border-border p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-medium">求职笔记</span>
            <Button size="sm" onClick={handleNew}>
              <Plus className="h-4 w-4" strokeWidth={1.5} />
              新建
            </Button>
          </div>
          <div className="relative mb-2">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground"
              strokeWidth={1.5}
            />
            <Input
              placeholder="搜索笔记..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-8 pl-8 text-xs"
            />
          </div>
          <div className="flex flex-wrap gap-1">
            <CategoryChip
              label="全部"
              active={category === "all"}
              onClick={() => setCategory("all")}
            />
            {CATEGORIES.map((c) => (
              <CategoryChip
                key={c.value}
                label={c.label}
                active={category === c.value}
                onClick={() => setCategory(c.value)}
              />
            ))}
          </div>
        </div>
        <div className="scrollbar-thin flex-1 overflow-y-auto p-2">
          {loading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="mb-2 h-16" />
            ))
          ) : filtered.length === 0 ? (
            <div className="px-3 py-8 text-center text-xs text-muted-foreground">
              暂无笔记
            </div>
          ) : (
            filtered.map((note) => (
              <button
                key={note.id}
                onClick={() => {
                  setActiveId(note.id);
                  setDraft(note);
                  setPreviewMode(false);
                }}
                className={cn(
                  "mb-1 block w-full rounded-lg p-2.5 text-left transition-colors hover:bg-accent",
                  activeId === note.id && "bg-accent",
                )}
              >
                <div className="mb-1 flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-medium">
                    {note.title || "无标题"}
                  </p>
                  <span
                    className={cn(
                      "shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium",
                      CATEGORY_BADGE[note.category],
                    )}
                  >
                    {CATEGORIES.find((c) => c.value === note.category)?.label}
                  </span>
                </div>
                <p className="mb-1 line-clamp-2 text-xs text-muted-foreground">
                  {note.content || "暂无内容"}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-muted-foreground">
                    {timeAgo(note.updated_at)}
                  </span>
                  {note.tags.length > 0 && (
                    <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
                      <Tag className="h-2.5 w-2.5" strokeWidth={1.5} />
                      {note.tags.length}
                    </span>
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Editor */}
      <div className="flex flex-1 flex-col">
        {!draft ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <NotebookPen className="h-8 w-8" strokeWidth={1.5} />
            </div>
            <h3 className="text-lg font-medium">开始记录你的求职笔记</h3>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground">
              记录面经、技术要点、公司信息，让每次面试都成为积累。
            </p>
            <Button className="mt-5" onClick={handleNew}>
              <Plus className="h-4 w-4" strokeWidth={1.5} />
              新建笔记
            </Button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between gap-3 border-b border-border px-6 py-3">
              <Input
                value={draft.title}
                onChange={(e) => updateDraft({ title: e.target.value })}
                className="border-0 bg-transparent px-0 text-base font-semibold shadow-none focus-visible:ring-0"
                placeholder="笔记标题"
              />
              <div className="flex items-center gap-2">
                <Select
                  value={draft.category}
                  onValueChange={(v) => updateDraft({ category: v as NoteCategory })}
                >
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setPreviewMode((p) => !p)}
                >
                  {previewMode ? (
                    <Pencil className="h-4 w-4" strokeWidth={1.5} />
                  ) : (
                    <Eye className="h-4 w-4" strokeWidth={1.5} />
                  )}
                </Button>
                <Button size="icon" onClick={handleSave}>
                  <Save className="h-4 w-4" strokeWidth={1.5} />
                </Button>
              </div>
            </div>

            <div className="scrollbar-thin flex-1 overflow-y-auto p-6">
              {previewMode ? (
                <div className="prose prose-sm max-w-none">
                  <MarkdownPreview content={draft.content} />
                </div>
              ) : (
                <div className="space-y-4">
                  <Textarea
                    value={draft.content}
                    onChange={(e) => updateDraft({ content: e.target.value })}
                    placeholder="支持 Markdown 语法，开始记录..."
                    className="min-h-[300px] resize-none border-0 bg-transparent p-0 shadow-none focus-visible:ring-0"
                  />

                  {/* Tags */}
                  <div>
                    <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                      <Tag className="h-3.5 w-3.5" strokeWidth={1.5} />
                      标签
                    </label>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {draft.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="gap-1 pr-1.5">
                          {tag}
                          <button
                            onClick={() =>
                              updateDraft({
                                tags: draft.tags.filter((t) => t !== tag),
                              })
                            }
                            className="rounded-full hover:bg-background"
                          >
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-3 w-3">
                              <path d="M18 6 6 18M6 6l12 12" />
                            </svg>
                          </button>
                        </Badge>
                      ))}
                      <TagInput
                        onAdd={(tag) =>
                          updateDraft({
                            tags: draft.tags.includes(tag)
                              ? draft.tags
                              : [...draft.tags, tag],
                          })
                        }
                      />
                    </div>
                  </div>

                  {/* Link application */}
                  <div>
                    <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                      <Link2 className="h-3.5 w-3.5" strokeWidth={1.5} />
                      关联投递记录
                    </label>
                    <Select
                      value={draft.application_id ?? "_none"}
                      onValueChange={(v) =>
                        updateDraft({
                          application_id: v === "_none" ? undefined : v,
                        })
                      }
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="不关联" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="_none">不关联</SelectItem>
                        {applications.map((app) => (
                          <SelectItem key={app.id} value={app.id}>
                            {app.company} - {app.position}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t border-border px-6 py-2 text-xs text-muted-foreground">
              <span>创建于 {formatDate(draft.created_at)}</span>
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive hover:text-destructive"
                onClick={() => handleDelete(draft.id)}
              >
                <Trash2 className="h-4 w-4" strokeWidth={1.5} />
                删除笔记
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function CategoryChip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
        active
          ? "bg-primary text-primary-foreground"
          : "bg-muted text-muted-foreground hover:bg-accent",
      )}
    >
      {label}
    </button>
  );
}

function TagInput({ onAdd }: { onAdd: (tag: string) => void }) {
  const [value, setValue] = useState("");
  return (
    <Input
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter" && value.trim()) {
          onAdd(value.trim());
          setValue("");
        }
      }}
      placeholder="添加标签后回车"
      className="h-7 w-32 text-xs"
    />
  );
}

function MarkdownPreview({ content }: { content: string }) {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let list: string[] = [];

  const flushList = () => {
    if (list.length > 0) {
      elements.push(
        <ul key={`ul-${elements.length}`} className="my-1 list-disc space-y-0.5 pl-5">
          {list.map((item, i) => (
            <li key={i} dangerouslySetInnerHTML={{ __html: inline(item) }} />
          ))}
        </ul>,
      );
      list = [];
    }
  };

  for (const line of lines) {
    if (/^#{1,3}\s/.test(line)) {
      flushList();
      const level = line.match(/^#{1,3}/)![0].length;
      const text = line.replace(/^#{1,3}\s/, "");
      elements.push(
        <p
          key={`h-${elements.length}`}
          className={cn("my-2 font-bold", level === 1 ? "text-lg" : "text-base")}
          dangerouslySetInnerHTML={{ __html: inline(text) }}
        />,
      );
      continue;
    }
    if (/^[-*]\s/.test(line)) {
      list.push(line.replace(/^[-*]\s/, ""));
      continue;
    }
    if (line.trim() === "") {
      flushList();
      continue;
    }
    flushList();
    elements.push(
      <p
        key={`p-${elements.length}`}
        className="my-1 leading-relaxed"
        dangerouslySetInnerHTML={{ __html: inline(line) }}
      />,
    );
  }
  flushList();
  return <div className="text-sm">{elements}</div>;
}

function inline(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.+?)`/g, '<code class="rounded bg-muted px-1 text-xs">$1</code>');
}
