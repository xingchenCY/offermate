import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
} from "recharts";
import {
  Send,
  Users,
  Trophy,
  TrendingUp,
  Plus,
  KanbanSquare,
  Sparkles,
  ArrowRight,
  Inbox,
  type LucideIcon,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useApplicationStore } from "@/stores/applicationStore";
import {
  STATUS_META,
  KANBAN_COLUMNS,
  SOURCE_META,
  type ApplicationStatus,
} from "@/lib/types";
import { cn, timeAgo } from "@/lib/utils";

const FUNNEL_COLORS: Record<ApplicationStatus, string> = {
  saved: "#94a3b8",
  applied: "#3b82f6",
  written: "#06b6d4",
  phone_screen: "#f59e0b",
  onsite: "#f97316",
  offer: "#10b981",
  rejected: "#ef4444",
  withdrawn: "#71717a",
};

interface StatItem {
  label: string;
  value: number | string;
  suffix?: string;
  icon: LucideIcon;
  accent: string;
}

export function Dashboard() {
  const navigate = useNavigate();
  const {
    applications,
    stats,
    loading,
    fetchApplications,
    fetchStats,
  } = useApplicationStore();

  useEffect(() => {
    void fetchApplications();
    void fetchStats();
  }, [fetchApplications, fetchStats]);

  const funnelData = KANBAN_COLUMNS.map((status) => ({
    name: STATUS_META[status].label,
    status,
    count: stats?.by_status?.[status] ?? 0,
    fill: FUNNEL_COLORS[status],
  }));

  const trendData = (stats?.trend ?? []).slice(-14).map((p) => ({
    date: p.date.slice(5),
    投递: p.count,
    Offer: p.offer_count ?? 0,
  }));

  const recent = [...applications]
    .sort(
      (a, b) =>
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
    )
    .slice(0, 6);

  const statsItems: StatItem[] = [
    {
      label: "已投递",
      value: stats?.applied ?? 0,
      icon: Send,
      accent: "text-blue-500 bg-blue-500/10",
    },
    {
      label: "面试中",
      value: stats?.interviewing ?? 0,
      icon: Users,
      accent: "text-amber-500 bg-amber-500/10",
    },
    {
      label: "Offer",
      value: stats?.offer ?? 0,
      icon: Trophy,
      accent: "text-emerald-500 bg-emerald-500/10",
    },
    {
      label: "转化率",
      value: stats?.conversion_rate ?? 0,
      suffix: "%",
      icon: TrendingUp,
      accent: "text-primary bg-primary/10",
    },
  ];

  if (loading && applications.length === 0) {
    return (
      <div className="scrollbar-thin h-full overflow-y-auto p-6">
        <Skeleton className="mb-6 h-8 w-48" />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Skeleton className="h-72" />
          <Skeleton className="h-72" />
        </div>
      </div>
    );
  }

  const isEmpty = applications.length === 0;

  return (
    <div className="scrollbar-thin h-full overflow-y-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">仪表盘</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            求职进度一览，保持节奏，Offer 就在前方。
          </p>
        </div>
        <Button onClick={() => navigate("/applications")}>
          <Plus className="h-4 w-4" strokeWidth={1.5} />
          新建投递
        </Button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statsItems.map((item) => (
          <Card key={item.label} className="animate-fade-in">
            <CardContent className="flex items-center justify-between p-5">
              <div>
                <p className="text-sm text-muted-foreground">{item.label}</p>
                <p className="mt-1 text-3xl font-semibold tracking-tight">
                  {item.value}
                  {item.suffix}
                </p>
              </div>
              <div
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-xl",
                  item.accent,
                )}
              >
                <item.icon className="h-6 w-6" strokeWidth={1.5} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {isEmpty ? (
        <Card className="mt-6">
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Inbox className="h-8 w-8" strokeWidth={1.5} />
            </div>
            <h3 className="text-lg font-medium">还没有投递记录</h3>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground">
              开始记录你的求职进度吧。添加第一份投递，跟踪每一个面试机会。
            </p>
            <div className="mt-5 flex gap-2">
              <Button onClick={() => navigate("/applications")}>
                <Plus className="h-4 w-4" strokeWidth={1.5} />
                添加投递
              </Button>
              <Button variant="outline" onClick={() => navigate("/jobs")}>
                <KanbanSquare className="h-4 w-4" strokeWidth={1.5} />
                浏览岗位
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Charts */}
          <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>投递漏斗</CardTitle>
                <CardDescription>各阶段投递数量分布</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart
                    data={funnelData}
                    layout="vertical"
                    margin={{ left: 8, right: 16, top: 0, bottom: 0 }}
                  >
                    <CartesianGrid
                      horizontal={false}
                      stroke="hsl(var(--border))"
                    />
                    <XAxis type="number" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis
                      type="category"
                      dataKey="name"
                      width={64}
                      tick={{ fontSize: 12 }}
                      stroke="hsl(var(--muted-foreground))"
                    />
                    <Tooltip
                      cursor={{ fill: "hsl(var(--muted) / 0.4)" }}
                      contentStyle={{
                        borderRadius: 8,
                        border: "1px solid hsl(var(--border))",
                        background: "hsl(var(--popover))",
                        color: "hsl(var(--popover-foreground))",
                        fontSize: 12,
                      }}
                    />
                    <Bar dataKey="count" radius={[0, 6, 6, 0]} barSize={18}>
                      {funnelData.map((entry) => (
                        <Cell key={entry.status} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>投递趋势</CardTitle>
                <CardDescription>近 14 天投递与 Offer 走势</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart
                    data={trendData}
                    margin={{ left: -16, right: 8, top: 8, bottom: 0 }}
                  >
                    <CartesianGrid
                      vertical={false}
                      stroke="hsl(var(--border))"
                    />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 11 }}
                      stroke="hsl(var(--muted-foreground))"
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11 }}
                      stroke="hsl(var(--muted-foreground))"
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: 8,
                        border: "1px solid hsl(var(--border))",
                        background: "hsl(var(--popover))",
                        color: "hsl(var(--popover-foreground))",
                        fontSize: 12,
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="投递"
                      stroke="#4F46E5"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="Offer"
                      stroke="#10B981"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Recent + quick actions */}
          <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader className="flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle>最近活动</CardTitle>
                  <CardDescription>最新更新的投递记录</CardDescription>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/applications")}
                >
                  查看全部
                  <ArrowRight className="h-4 w-4" strokeWidth={1.5} />
                </Button>
              </CardHeader>
              <CardContent className="space-y-1">
                {recent.map((app) => (
                  <div
                    key={app.id}
                    onClick={() => navigate("/applications")}
                    className="flex cursor-pointer items-center justify-between rounded-lg px-2 py-2.5 transition-colors hover:bg-accent"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <span
                        className={cn(
                          "h-2 w-2 shrink-0 rounded-full",
                          FUNNEL_COLORS[app.status],
                        )}
                      />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">
                          {app.company}
                          <span className="ml-2 font-normal text-muted-foreground">
                            {app.position}
                          </span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {SOURCE_META[app.source]} · {timeAgo(app.updated_at)}
                        </p>
                      </div>
                    </div>
                    <Badge variant="secondary" className={STATUS_META[app.status].badgeClass}>
                      {STATUS_META[app.status].label}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>快速操作</CardTitle>
                <CardDescription>常用功能入口</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <QuickAction
                  icon={Plus}
                  label="新建投递记录"
                  onClick={() => navigate("/applications")}
                />
                <QuickAction
                  icon={Sparkles}
                  label="AI 优化简历"
                  onClick={() => navigate("/ai")}
                />
                <QuickAction
                  icon={KanbanSquare}
                  label="岗位匹配分析"
                  onClick={() => navigate("/ai?mode=match")}
                />
                <QuickAction
                  icon={Trophy}
                  label="模拟面试练习"
                  onClick={() => navigate("/ai?mode=interview")}
                />
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function QuickAction({
  icon: Icon,
  label,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-lg border border-border px-3 py-2.5 text-sm font-medium transition-all hover:bg-accent active:scale-[0.98]"
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <Icon className="h-4 w-4" strokeWidth={1.5} />
      </span>
      {label}
      <ArrowRight className="ml-auto h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
    </button>
  );
}
