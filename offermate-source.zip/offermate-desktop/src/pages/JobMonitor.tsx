import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Radar,
  Plus,
  Trash2,
  Power,
  PowerOff,
  Pencil,
  Activity,
  TrendingUp,
  Clock,
  Zap,
  ExternalLink,
  MapPin,
  DollarSign,
  Bell,
  Globe,
  Inbox,
  type LucideIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { monitorApi, jobsApi } from "@/lib/tauri";
import {
  PLATFORM_META,
  SOURCE_META,
  type JobSubscription,
  type CreateSubscriptionInput,
  type MonitorStats,
  type Job,
  type JobSource,
} from "@/lib/types";
import { cn, timeAgo } from "@/lib/utils";

// ============================================================
// Stat 卡片
// ============================================================

interface StatCardProps {
  label: string;
  value: number | string;
  icon: LucideIcon;
  accent: string;
  sub?: string;
}

function StatCard({ label, value, icon: Icon, accent, sub }: StatCardProps) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 p-4">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-lg",
            accent,
          )}
        >
          <Icon className="h-5 w-5" strokeWidth={1.5} />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-xl font-semibold tabular-nums">{value}</p>
          {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// 订阅卡片
// ============================================================

interface SubscriptionCardProps {
  sub: JobSubscription;
  onToggle: (id: string, enabled: boolean) => void;
  onEdit: (sub: JobSubscription) => void;
  onDelete: (id: string) => void;
}

function SubscriptionCard({ sub, onToggle, onEdit, onDelete }: SubscriptionCardProps) {
  return (
    <Card className={cn("transition-opacity", !sub.enabled && "opacity-60")}>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="truncate text-sm font-semibold">{sub.name}</h4>
              <Badge variant={sub.enabled ? "success" : "secondary"}>
                {sub.enabled ? "运行中" : "已暂停"}
              </Badge>
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {PLATFORM_META[sub.platform] || sub.platform}
              {" · "}
              每 {sub.interval_minutes} 分钟
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <button
              onClick={() => onToggle(sub.id, !sub.enabled)}
              className={cn(
                "rounded p-1.5 transition-colors",
                sub.enabled
                  ? "text-emerald-500 hover:bg-emerald-500/10"
                  : "text-muted-foreground hover:bg-muted",
              )}
              title={sub.enabled ? "暂停" : "启用"}
            >
              {sub.enabled ? (
                <Power className="h-4 w-4" strokeWidth={1.5} />
              ) : (
                <PowerOff className="h-4 w-4" strokeWidth={1.5} />
              )}
            </button>
            <button
              onClick={() => onEdit(sub)}
              className="rounded p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              title="编辑"
            >
              <Pencil className="h-4 w-4" strokeWidth={1.5} />
            </button>
            <button
              onClick={() => onDelete(sub.id)}
              className="rounded p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
              title="删除"
            >
              <Trash2 className="h-4 w-4" strokeWidth={1.5} />
            </button>
          </div>
        </div>

        {/* 筛选条件 */}
        <div className="mb-2 flex flex-wrap gap-1.5">
          {sub.keywords && (
            <Badge variant="outline" className="text-[11px]">
              关键词: {sub.keywords}
            </Badge>
          )}
          {sub.location && (
            <Badge variant="outline" className="text-[11px]">
              <MapPin className="h-3 w-3" strokeWidth={1.5} />
              {sub.location}
            </Badge>
          )}
          {sub.is_remote_only && (
            <Badge variant="outline" className="text-[11px]">
              <Globe className="h-3 w-3" strokeWidth={1.5} />
              仅远程
            </Badge>
          )}
          {sub.ai_filter_enabled && (
            <Badge variant="warning" className="text-[11px]">
              <Zap className="h-3 w-3" strokeWidth={1.5} />
              AI 过滤 ≥{sub.ai_threshold}
            </Badge>
          )}
          {sub.webhook_url && (
            <Badge variant="outline" className="text-[11px]">
              <Bell className="h-3 w-3" strokeWidth={1.5} />
              Webhook
            </Badge>
          )}
        </div>

        {/* 统计 */}
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span>
            本次新增: <span className="font-medium text-foreground">{sub.last_new_count}</span>
          </span>
          <span>
            累计: <span className="font-medium text-foreground">{sub.total_new_count}</span>
          </span>
          {sub.last_run_at && (
            <span className="flex items-center gap-0.5">
              <Clock className="h-3 w-3" strokeWidth={1.5} />
              {timeAgo(sub.last_run_at)}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// 订阅表单对话框
// ============================================================

interface SubscriptionFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing?: JobSubscription | null;
  onSubmit: (input: CreateSubscriptionInput) => Promise<void>;
}

function SubscriptionForm({ open, onOpenChange, editing, onSubmit }: SubscriptionFormProps) {
  const [form, setForm] = useState<CreateSubscriptionInput>({
    name: "",
    platform: "boss",
    keywords: "",
    companies: "",
    location: "",
    salary_min: "",
    salary_max: "",
    is_remote_only: false,
    interval_minutes: 60,
    ai_filter_enabled: false,
    ai_threshold: 60,
    webhook_url: "",
    enabled: true,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editing) {
      setForm({
        name: editing.name,
        platform: editing.platform,
        keywords: editing.keywords || "",
        companies: editing.companies || "",
        location: editing.location || "",
        salary_min: editing.salary_min || "",
        salary_max: editing.salary_max || "",
        is_remote_only: editing.is_remote_only,
        interval_minutes: editing.interval_minutes,
        ai_filter_enabled: editing.ai_filter_enabled,
        ai_threshold: editing.ai_threshold,
        webhook_url: editing.webhook_url || "",
        enabled: editing.enabled,
      });
    } else {
      setForm({
        name: "",
        platform: "boss",
        keywords: "",
        companies: "",
        location: "",
        salary_min: "",
        salary_max: "",
        is_remote_only: false,
        interval_minutes: 60,
        ai_filter_enabled: false,
        ai_threshold: 60,
        webhook_url: "",
        enabled: true,
      });
    }
  }, [editing, open]);

  const handleSubmit = async () => {
    if (!form.name.trim()) {
      toast.error("请填写订阅名称");
      return;
    }
    setSaving(true);
    try {
      await onSubmit(form);
      onOpenChange(false);
    } catch {
      toast.error(editing ? "更新失败" : "创建失败");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editing ? "编辑订阅" : "创建监控订阅"}</DialogTitle>
          <DialogDescription>
            设置筛选条件，OfferMate 将定期通过浏览器扩展自动抓取新岗位
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* 基本信息 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">
                订阅名称 <span className="text-destructive">*</span>
              </label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="如：前端开发-北京"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">监控平台</label>
              <Select
                value={form.platform}
                onValueChange={(v) => setForm({ ...form, platform: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PLATFORM_META).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">关键词</label>
              <Input
                value={form.keywords}
                onChange={(e) => setForm({ ...form, keywords: e.target.value })}
                placeholder="如：React 前端"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">城市/地区</label>
              <Input
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="如：北京 或 全国"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              指定公司（多个用逗号分隔）
            </label>
            <Input
              value={form.companies}
              onChange={(e) => setForm({ ...form, companies: e.target.value })}
              placeholder="如：字节跳动,腾讯,阿里巴巴"
            />
          </div>

          {/* 抓取频率 */}
          <div className="flex items-center gap-3">
            <label className="text-xs font-medium text-muted-foreground">抓取频率</label>
            <Select
              value={String(form.interval_minutes)}
              onValueChange={(v) => setForm({ ...form, interval_minutes: Number(v) })}
            >
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">每 15 分钟</SelectItem>
                <SelectItem value="30">每 30 分钟</SelectItem>
                <SelectItem value="60">每 1 小时</SelectItem>
                <SelectItem value="120">每 2 小时</SelectItem>
                <SelectItem value="360">每 6 小时</SelectItem>
                <SelectItem value="720">每 12 小时</SelectItem>
                <SelectItem value="1440">每天</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 远程岗位 */}
          <label className="flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={form.is_remote_only}
              onChange={(e) => setForm({ ...form, is_remote_only: e.target.checked })}
              className="h-4 w-4 rounded border-border accent-primary"
            />
            <span className="text-sm">仅监控远程岗位</span>
          </label>

          {/* AI 过滤 */}
          <div className="rounded-lg border border-border p-3">
            <label className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={form.ai_filter_enabled}
                onChange={(e) => setForm({ ...form, ai_filter_enabled: e.target.checked })}
                className="h-4 w-4 rounded border-border accent-primary"
              />
              <span className="text-sm font-medium">启用 AI 自动评分过滤</span>
            </label>
            {form.ai_filter_enabled && (
              <div className="mt-2 flex items-center gap-2 pl-6">
                <span className="text-xs text-muted-foreground">匹配阈值</span>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  value={form.ai_threshold}
                  onChange={(e) => setForm({ ...form, ai_threshold: Number(e.target.value) })}
                  className="w-20"
                />
                <span className="text-xs text-muted-foreground">
                  低于此分的岗位将被过滤
                </span>
              </div>
            )}
          </div>

          {/* Webhook */}
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Webhook 推送地址（飞书/企业微信机器人）
            </label>
            <Input
              value={form.webhook_url}
              onChange={(e) => setForm({ ...form, webhook_url: e.target.value })}
              placeholder="https://open.feishu.cn/open-apis/bot/v2/hook/..."
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              新岗位将自动推送到此地址，支持飞书和企业微信群机器人
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={saving}>
            {saving ? "保存中..." : editing ? "保存" : "创建"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// 监控岗位卡片
// ============================================================

function MonitoredJobCard({ job }: { job: Job }) {
  return (
    <Card className="transition-shadow hover:shadow-sm">
      <CardContent className="p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h4 className="truncate text-sm font-semibold">{job.position}</h4>
            <p className="truncate text-xs text-muted-foreground">{job.company}</p>
          </div>
          {job.match_score != null && (
            <Badge
              variant={job.match_score >= 80 ? "success" : job.match_score >= 60 ? "warning" : "destructive"}
              className="shrink-0"
            >
              {Math.round(job.match_score)}%
            </Badge>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
          {job.salary && (
            <span className="flex items-center gap-0.5">
              <DollarSign className="h-3 w-3" strokeWidth={1.5} />
              {job.salary}
            </span>
          )}
          {job.location && (
            <span className="flex items-center gap-0.5">
              <MapPin className="h-3 w-3" strokeWidth={1.5} />
              {job.location}
            </span>
          )}
          {job.is_remote && (
            <Badge variant="outline" className="text-[10px]">
              <Globe className="h-2.5 w-2.5" strokeWidth={1.5} />
              远程
            </Badge>
          )}
          <span className="rounded bg-muted px-1.5 py-0.5">
            {SOURCE_META[job.source as JobSource] || job.source}
          </span>
          {job.created_at && (
            <span className="flex items-center gap-0.5">
              <Clock className="h-3 w-3" strokeWidth={1.5} />
              {timeAgo(job.created_at)}
            </span>
          )}
        </div>
        {job.url && (
          <a
            href={job.url}
            target="_blank"
            rel="noreferrer"
            className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
            onClick={(e) => e.stopPropagation()}
          >
            <ExternalLink className="h-3 w-3" strokeWidth={1.5} />
            查看原文
          </a>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================
// 主页面
// ============================================================

export function JobMonitor() {
  const [subscriptions, setSubscriptions] = useState<JobSubscription[]>([]);
  const [monitoredJobs, setMonitoredJobs] = useState<Job[]>([]);
  const [stats, setStats] = useState<MonitorStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<JobSubscription | null>(null);

  const fetchData = useCallback(async () => {
    const [subs, stat] = await Promise.all([
      monitorApi.listSubscriptions(),
      monitorApi.getStats(),
    ]);
    setSubscriptions(subs);
    setStats(stat);
    setLoading(false);
  }, []);

  const fetchMonitoredJobs = useCallback(async () => {
    const recent = await jobsApi.listRecent(168); // 7 days
    setMonitoredJobs(recent);
  }, []);

  useEffect(() => {
    void fetchData();
    void fetchMonitoredJobs();
  }, [fetchData, fetchMonitoredJobs]);

  // 监听 Tauri 事件 - 新岗位检测
  useEffect(() => {
    let unlisten: (() => void) | null = null;

    (async () => {
      try {
        if ("__TAURI_INTERNALS__" in window) {
          const { listen } = await import("@tauri-apps/api/event");
          unlisten = await listen("offermate://new-jobs-detected", () => {
            void fetchData();
            void fetchMonitoredJobs();
            toast.success("检测到新岗位！");
          });
        }
      } catch {
        // 非 Tauri 环境忽略
      }
    })();

    return () => {
      if (unlisten) unlisten();
    };
  }, [fetchData, fetchMonitoredJobs]);

  const handleCreate = async (input: CreateSubscriptionInput) => {
    await monitorApi.createSubscription(input);
    toast.success("订阅已创建");
    void fetchData();
  };

  const handleUpdate = async (input: CreateSubscriptionInput) => {
    if (!editing) return;
    await monitorApi.updateSubscription(editing.id, input);
    toast.success("订阅已更新");
    setEditing(null);
    void fetchData();
  };

  const handleToggle = async (id: string, enabled: boolean) => {
    await monitorApi.toggleSubscription(id, enabled);
    setSubscriptions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, enabled } : s)),
    );
    toast.success(enabled ? "已启用" : "已暂停");
  };

  const handleDelete = async (id: string) => {
    await monitorApi.deleteSubscription(id);
    setSubscriptions((prev) => prev.filter((s) => s.id !== id));
    toast.success("已删除");
  };

  const handleEdit = (sub: JobSubscription) => {
    setEditing(sub);
    setFormOpen(true);
  };

  const handleAdd = () => {
    setEditing(null);
    setFormOpen(true);
  };

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-card/40 px-6 py-4">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">岗位监控</h1>
          <p className="text-sm text-muted-foreground">
            自动跟踪招聘网站新岗位发布，AI 智能筛选
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button onClick={handleAdd}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
            创建订阅
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 border-b border-border px-6 py-4 md:grid-cols-4">
        {loading || !stats ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-[72px]" />
          ))
        ) : (
          <>
            <StatCard
              label="活跃订阅"
              value={stats.active_subscriptions}
              sub={`共 ${stats.total_subscriptions} 个`}
              icon={Radar}
              accent="bg-blue-100 text-blue-600 dark:bg-blue-500/15 dark:text-blue-400"
            />
            <StatCard
              label="累计新岗位"
              value={stats.total_new_jobs}
              icon={TrendingUp}
              accent="bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
            />
            <StatCard
              label="24h 新增"
              value={stats.jobs_last_24h}
              icon={Activity}
              accent="bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400"
            />
            <StatCard
              label="7 天新增"
              value={stats.jobs_last_7d}
              icon={Clock}
              accent="bg-purple-100 text-purple-600 dark:bg-purple-500/15 dark:text-purple-400"
            />
          </>
        )}
      </div>

      {/* Tabs */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="subscriptions" className="flex h-full flex-col">
          <div className="border-b border-border px-6 pt-3">
            <TabsList>
              <TabsTrigger value="subscriptions">
                <Radar className="h-4 w-4" strokeWidth={1.5} />
                订阅规则 ({subscriptions.length})
              </TabsTrigger>
              <TabsTrigger value="jobs">
                <Inbox className="h-4 w-4" strokeWidth={1.5} />
                监控到的新岗位 ({monitoredJobs.length})
              </TabsTrigger>
            </TabsList>
          </div>

          {/* 订阅规则 Tab */}
          <TabsContent
            value="subscriptions"
            className="scrollbar-thin mt-0 flex-1 overflow-y-auto p-6"
          >
            {loading ? (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-32" />
                ))}
              </div>
            ) : subscriptions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <Radar className="h-8 w-8" strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-medium">还没有监控订阅</h3>
                <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                  创建订阅规则，OfferMate 将通过浏览器扩展自动监控招聘网站的新岗位。
                </p>
                <Button className="mt-5" onClick={handleAdd}>
                  <Plus className="h-4 w-4" strokeWidth={1.5} />
                  创建第一个订阅
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {subscriptions.map((sub) => (
                  <SubscriptionCard
                    key={sub.id}
                    sub={sub}
                    onToggle={handleToggle}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* 新岗位 Tab */}
          <TabsContent
            value="jobs"
            className="scrollbar-thin mt-0 flex-1 overflow-y-auto p-6"
          >
            {monitoredJobs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
                  <Inbox className="h-8 w-8" strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-medium">暂无监控到的新岗位</h3>
                <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                  当浏览器扩展检测到符合订阅条件的新岗位时，会自动出现在这里。
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
                {monitoredJobs.map((job) => (
                  <MonitoredJobCard key={job.id} job={job} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* 创建/编辑对话框 */}
      <SubscriptionForm
        open={formOpen}
        onOpenChange={(o) => {
          setFormOpen(o);
          if (!o) setEditing(null);
        }}
        editing={editing}
        onSubmit={editing ? handleUpdate : handleCreate}
      />
    </div>
  );
}
