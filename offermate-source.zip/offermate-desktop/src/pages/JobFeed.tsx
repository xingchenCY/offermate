import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  Search,
  Plus,
  Bookmark,
  MapPin,
  DollarSign,
  ExternalLink,
  Download,
  Trash2,
  Inbox,
  ArrowRight,
  Globe,
  Clock,
  type LucideIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { jobsApi } from "@/lib/tauri";
import { useApplicationStore } from "@/stores/applicationStore";
import {
  SOURCE_META,
  type Job,
  type JobSource,
} from "@/lib/types";
import { cn, timeAgo } from "@/lib/utils";

const SOURCES: JobSource[] = ["boss", "zhilian", "niuke", "nowcoder", "lagou", "51job", "liepin", "monitor", "manual", "other"];

export function JobFeed() {
  const navigate = useNavigate();
  const { createApplication } = useApplicationStore();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sourceFilter, setSourceFilter] = useState<JobSource | "all">("all");
  const [timeFilter, setTimeFilter] = useState<"all" | "24h" | "7d">("all");
  const [detailJob, setDetailJob] = useState<Job | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  useEffect(() => {
    void (async () => {
      const list = await jobsApi.list();
      setJobs(list);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const now = Date.now();
    const cutoff24h = now - 24 * 60 * 60 * 1000;
    const cutoff7d = now - 7 * 24 * 60 * 60 * 1000;

    return jobs.filter((job) => {
      if (sourceFilter !== "all" && job.source !== sourceFilter) return false;
      if (timeFilter !== "all") {
        const jobTime = job.posted_at
          ? new Date(job.posted_at).getTime()
          : new Date(job.created_at).getTime();
        if (timeFilter === "24h" && jobTime < cutoff24h) return false;
        if (timeFilter === "7d" && jobTime < cutoff7d) return false;
      }
      if (q) {
        const hay = `${job.company} ${job.position} ${job.location ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [jobs, search, sourceFilter, timeFilter]);

  const handleImport = async () => {
    try {
      // 模拟从浏览器扩展导入（实际由扩展推送数据）
      const imported = await jobsApi.importJobs([]);
      if (imported.length > 0) {
        setJobs((prev) => [...imported, ...prev]);
        toast.success(`已导入 ${imported.length} 个岗位`);
      } else {
        toast.message("未检测到可导入的岗位数据");
      }
    } catch {
      toast.error("导入失败");
    }
  };

  const handleDelete = async (id: string) => {
    await jobsApi.delete(id);
    setJobs((prev) => prev.filter((j) => j.id !== id));
    toast.success("已删除");
  };

  const handleCreateApplication = async () => {
    if (!detailJob) return;
    await createApplication({
      company: detailJob.company,
      position: detailJob.position,
      job_url: detailJob.url,
      salary: detailJob.salary,
      location: detailJob.location,
      source: detailJob.source,
      status: "saved",
      priority: "medium",
    });
    toast.success("已创建投递记录");
    setCreateOpen(false);
    setDetailJob(null);
    navigate("/applications");
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-card/40 px-6 py-4">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">岗位收藏</h1>
          <p className="text-sm text-muted-foreground">收藏与管理感兴趣的岗位</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4" strokeWidth={1.5} />
            手动添加
          </Button>
          <Button variant="outline" onClick={handleImport}>
            <Download className="h-4 w-4" strokeWidth={1.5} />
            从扩展导入
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 border-b border-border px-6 py-3">
        <div className="relative w-64">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            strokeWidth={1.5}
          />
          <Input
            placeholder="搜索岗位..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={sourceFilter}
          onValueChange={(v) => setSourceFilter(v as JobSource | "all")}
        >
          <SelectTrigger className="w-36">
            <SelectValue placeholder="来源" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部来源</SelectItem>
            {SOURCES.map((s) => (
              <SelectItem key={s} value={s}>
                {SOURCE_META[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={timeFilter}
          onValueChange={(v) => setTimeFilter(v as "all" | "24h" | "7d")}
        >
          <SelectTrigger className="w-32">
            <SelectValue placeholder="时间" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部时间</SelectItem>
            <SelectItem value="24h">最近 24 小时</SelectItem>
            <SelectItem value="7d">最近 7 天</SelectItem>
          </SelectContent>
        </Select>
        <span className="ml-auto text-sm text-muted-foreground">
          共 {filtered.length} 个岗位
        </span>
      </div>

      <div className="scrollbar-thin flex-1 overflow-y-auto p-6">
        {loading ? (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-36" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Inbox className="h-8 w-8" strokeWidth={1.5} />
            </div>
            <h3 className="text-lg font-medium">
              {jobs.length === 0 ? "还没有收藏的岗位" : "未找到匹配的岗位"}
            </h3>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground">
              {jobs.length === 0
                ? "通过浏览器扩展收藏岗位，或手动添加感兴趣的岗位。"
                : "试试调整搜索条件或来源筛选。"}
            </p>
            <Button className="mt-5" onClick={handleImport}>
              <Download className="h-4 w-4" strokeWidth={1.5} />
              导入岗位
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((job) => (
              <JobCard
                key={job.id}
                job={job}
                onClick={() => setDetailJob(job)}
                onDelete={() => handleDelete(job.id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Detail / create dialog */}
      {detailJob && (
        <Dialog open onOpenChange={(o) => !o && setDetailJob(null)}>
          <DialogContent>
            <DialogHeader>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{SOURCE_META[detailJob.source]}</Badge>
                {detailJob.is_remote && (
                  <Badge variant="outline">
                    <Globe className="h-3 w-3" strokeWidth={1.5} />
                    远程
                  </Badge>
                )}
                {detailJob.match_score != null && (
                  <Badge variant="success">
                    匹配 {detailJob.match_score}%
                  </Badge>
                )}
              </div>
              <DialogTitle className="mt-2">{detailJob.position}</DialogTitle>
              <DialogDescription>{detailJob.company}</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <InfoItem icon={DollarSign} label="薪资" value={detailJob.salary || "-"} />
                <InfoItem icon={MapPin} label="地点" value={detailJob.location || "-"} />
              </div>
              {(detailJob.posted_at || detailJob.created_at) && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" strokeWidth={1.5} />
                  发布时间: {timeAgo(detailJob.posted_at || detailJob.created_at)}
                </div>
              )}
              {detailJob.tags && detailJob.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {detailJob.tags.map((t) => (
                    <Badge key={t} variant="outline" className="text-xs">
                      {t}
                    </Badge>
                  ))}
                </div>
              )}
              {detailJob.description && (
                <div className="rounded-lg bg-muted p-3 text-sm leading-relaxed">
                  {detailJob.description}
                </div>
              )}
              {detailJob.url && (
                <a
                  href={detailJob.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  <ExternalLink className="h-4 w-4" strokeWidth={1.5} />
                  查看原始链接
                </a>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDetailJob(null)}>
                关闭
              </Button>
              <Button onClick={handleCreateApplication}>
                <Plus className="h-4 w-4" strokeWidth={1.5} />
                创建投递
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Quick manual add */}
      <QuickAddJob
        open={createOpen}
        onOpenChange={setCreateOpen}
        onAdd={async (job) => {
          const created = await jobsApi.create(job);
          setJobs((prev) => [created, ...prev]);
          toast.success("岗位已添加");
          setCreateOpen(false);
        }}
      />
    </div>
  );
}

function JobCard({
  job,
  onClick,
  onDelete,
}: {
  job: Job;
  onClick: () => void;
  onDelete: () => void;
}) {
  return (
    <Card
      className="group cursor-pointer transition-all hover:shadow-md active:scale-[0.99]"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="mb-1.5 flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h4 className="truncate text-sm font-semibold">{job.position}</h4>
            <p className="truncate text-xs text-muted-foreground">{job.company}</p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="rounded p-1 text-muted-foreground opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
          >
            <Trash2 className="h-3.5 w-3.5" strokeWidth={1.5} />
          </button>
        </div>
        <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
          {job.salary && (
            <span className="flex items-center gap-0.5">
              <DollarSign className="h-3 w-3" strokeWidth={1.5} />
              {job.salary}
            </span>
          )}
          {job.location && (
            <span className="flex items-center gap-0.5">
              <MapPin className="h-3 w-3" strokeWidth={1.5} />
              {job.location}
            </span>
          )}
          {job.is_remote && (
            <Badge variant="outline" className="gap-0.5 px-1.5 py-0 text-[10px]">
              <Globe className="h-2.5 w-2.5" strokeWidth={1.5} />
              远程
            </Badge>
          )}
          <span className="rounded bg-muted px-1.5 py-0.5">
            {SOURCE_META[job.source]}
          </span>
          {(job.posted_at || job.created_at) && (
            <span className="flex items-center gap-0.5">
              <Clock className="h-3 w-3" strokeWidth={1.5} />
              {timeAgo(job.posted_at || job.created_at)}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between">
          {job.match_score != null ? (
            <div className="flex items-center gap-1.5">
              <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
                <div
                  className={cn(
                    "h-full rounded-full",
                    job.match_score >= 80
                      ? "bg-emerald-500"
                      : job.match_score >= 60
                        ? "bg-amber-500"
                        : "bg-red-500",
                  )}
                  style={{ width: `${job.match_score}%` }}
                />
              </div>
              <span className="text-xs font-medium text-muted-foreground">
                {job.match_score}%
              </span>
            </div>
          ) : (
            <span className="text-xs text-muted-foreground">未评估</span>
          )}
          <span className="flex items-center gap-1 text-xs text-primary opacity-0 transition-opacity group-hover:opacity-100">
            详情
            <ArrowRight className="h-3 w-3" strokeWidth={1.5} />
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoItem({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
      <span className="text-muted-foreground">{label}</span>
      <span className="ml-auto font-medium">{value}</span>
    </div>
  );
}

function QuickAddJob({
  open,
  onOpenChange,
  onAdd,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (job: {
    company: string;
    position: string;
    salary?: string;
    location?: string;
    source: JobSource;
    url?: string;
  }) => Promise<void>;
}) {
  const [form, setForm] = useState({
    company: "",
    position: "",
    salary: "",
    location: "",
    url: "",
    source: "manual" as JobSource,
  });
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o)
          setForm({
            company: "",
            position: "",
            salary: "",
            location: "",
            url: "",
            source: "manual",
          });
        onOpenChange(o);
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>手动添加岗位</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">公司</label>
            <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">职位</label>
            <Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">薪资</label>
            <Input value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">地点</label>
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
          </div>
          <div className="col-span-2">
            <label className="mb-1 block text-xs font-medium text-muted-foreground">链接</label>
            <Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>取消</Button>
          <Button onClick={() => onAdd(form)}>添加</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
