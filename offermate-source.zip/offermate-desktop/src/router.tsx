import { createBrowserRouter, type RouteObject } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { Dashboard } from "@/pages/Dashboard";
import { Applications } from "@/pages/Applications";
import { ResumeEditor } from "@/pages/ResumeEditor";
import { AIAssistant } from "@/pages/AIAssistant";
import { JobFeed } from "@/pages/JobFeed";
import { JobMonitor } from "@/pages/JobMonitor";
import { Notes } from "@/pages/Notes";
import { Settings } from "@/pages/Settings";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <AppLayout />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "applications", element: <Applications /> },
      { path: "resume", element: <ResumeEditor /> },
      { path: "ai", element: <AIAssistant /> },
      { path: "jobs", element: <JobFeed /> },
      { path: "monitor", element: <JobMonitor /> },
      { path: "notes", element: <Notes /> },
      { path: "settings", element: <Settings /> },
      {
        path: "*",
        element: (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <p className="text-lg font-medium">页面未找到</p>
            <p className="mt-1 text-sm text-muted-foreground">
              请检查地址是否正确
            </p>
          </div>
        ),
      },
    ],
  },
];

export const router = createBrowserRouter(routes);
