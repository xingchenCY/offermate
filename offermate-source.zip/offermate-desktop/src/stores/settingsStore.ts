import { create } from "zustand";
import { settingsApi } from "@/lib/tauri";
import type { AIProvider, AppSettings, ThemeMode } from "@/lib/types";

interface SettingsState {
  settings: AppSettings;
  loaded: boolean;
  testing: boolean;
  testResult: boolean | null;
  error: string | null;

  loadSettings: () => Promise<void>;
  saveSettings: (settings: AppSettings) => Promise<void>;
  toggleTheme: () => void;
  setTheme: (theme: ThemeMode) => void;
  setAIProvider: (provider: AIProvider) => void;
  setAIField: <K extends "api_key" | "model" | "base_url">(
    field: K,
    value: string,
  ) => void;
  testConnection: () => Promise<boolean>;
}

const defaultSettings: AppSettings = {
  theme: "system",
  ai: {
    provider: "openai",
    api_key: "",
    model: "gpt-4o-mini",
    base_url: "",
  },
  auto_save: true,
  notification_enabled: true,
};

/** 应用主题到 document */
function applyTheme(theme: ThemeMode) {
  const root = document.documentElement;
  const prefersDark = window.matchMedia(
    "(prefers-color-scheme: dark)",
  ).matches;
  const isDark = theme === "dark" || (theme === "system" && prefersDark);
  root.classList.toggle("dark", isDark);
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  settings: { ...defaultSettings },
  loaded: false,
  testing: false,
  testResult: null,
  error: null,

  loadSettings: async () => {
    try {
      const settings = await settingsApi.load();
      set({ settings, loaded: true });
      applyTheme(settings.theme);
    } catch (err) {
      set({
        loaded: true,
        error: err instanceof Error ? err.message : "加载设置失败",
      });
      applyTheme("system");
    }
  },

  saveSettings: async (settings) => {
    try {
      const saved = await settingsApi.save(settings);
      set({ settings: saved });
      applyTheme(saved.theme);
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : "保存设置失败",
      });
    }
  },

  toggleTheme: () => {
    const current = get().settings.theme;
    const next: ThemeMode = current === "dark" ? "light" : "dark";
    const settings = { ...get().settings, theme: next };
    set({ settings });
    applyTheme(next);
    void get().saveSettings(settings);
  },

  setTheme: (theme) => {
    const settings = { ...get().settings, theme };
    set({ settings });
    applyTheme(theme);
    void get().saveSettings(settings);
  },

  setAIProvider: (provider) => {
    const settings = {
      ...get().settings,
      ai: { ...get().settings.ai, provider },
    };
    set({ settings });
    void get().saveSettings(settings);
  },

  setAIField: (field, value) => {
    const settings = {
      ...get().settings,
      ai: { ...get().settings.ai, [field]: value },
    };
    set({ settings });
  },

  testConnection: async () => {
    set({ testing: true, testResult: null });
    try {
      const ok = await settingsApi.testConnection();
      set({ testing: false, testResult: ok });
      return ok;
    } catch (err) {
      set({
        testing: false,
        testResult: false,
        error: err instanceof Error ? err.message : "测试连接失败",
      });
      return false;
    }
  },
}));
