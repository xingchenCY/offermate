import { create } from "zustand";
import { applicationsApi } from "@/lib/tauri";
import type {
  Application,
  ApplicationStatus,
  CreateApplicationInput,
  UpdateApplicationInput,
  StatusFilter,
  SourceFilter,
  PriorityFilter,
  DashboardStats,
  StatusLog,
} from "@/lib/types";

interface ApplicationFilters {
  status: StatusFilter;
  source: SourceFilter;
  priority: PriorityFilter;
  search: string;
}

interface ApplicationState {
  applications: Application[];
  stats: DashboardStats | null;
  timelines: Record<string, StatusLog[]>;
  loading: boolean;
  error: string | null;
  filters: ApplicationFilters;

  fetchApplications: () => Promise<void>;
  fetchStats: () => Promise<void>;
  fetchTimeline: (id: string) => Promise<void>;
  createApplication: (input: CreateApplicationInput) => Promise<Application>;
  updateApplication: (
    id: string,
    input: UpdateApplicationInput,
  ) => Promise<Application>;
  deleteApplication: (id: string) => Promise<void>;
  transitionStatus: (
    id: string,
    toStatus: ApplicationStatus,
    note?: string,
  ) => Promise<void>;
  setFilter: <K extends keyof ApplicationFilters>(
    key: K,
    value: ApplicationFilters[K],
  ) => void;
  resetFilters: () => void;
  getById: (id: string) => Application | undefined;
}

const defaultFilters: ApplicationFilters = {
  status: "all",
  source: "all",
  priority: "all",
  search: "",
};

export const useApplicationStore = create<ApplicationState>((set, get) => ({
  applications: [],
  stats: null,
  timelines: {},
  loading: false,
  error: null,
  filters: { ...defaultFilters },

  fetchApplications: async () => {
    set({ loading: true, error: null });
    try {
      const applications = await applicationsApi.list();
      set({ applications, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "加载投递记录失败",
      });
    }
  },

  fetchStats: async () => {
    try {
      const stats = await applicationsApi.getStats();
      set({ stats });
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : "加载统计数据失败",
      });
    }
  },

  fetchTimeline: async (id) => {
    try {
      const timeline = await applicationsApi.getTimeline(id);
      set((state) => ({
        timelines: { ...state.timelines, [id]: timeline },
      }));
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : "加载时间线失败",
      });
    }
  },

  createApplication: async (input) => {
    const created = await applicationsApi.create(input);
    set((state) => ({
      applications: [created, ...state.applications],
    }));
    void get().fetchStats();
    return created;
  },

  updateApplication: async (id, input) => {
    const updated = await applicationsApi.update(id, input);
    set((state) => ({
      applications: state.applications.map((app) =>
        app.id === id ? updated : app,
      ),
    }));
    return updated;
  },

  deleteApplication: async (id) => {
    await applicationsApi.delete(id);
    set((state) => ({
      applications: state.applications.filter((app) => app.id !== id),
    }));
    void get().fetchStats();
  },

  transitionStatus: async (id, toStatus, note) => {
    const log = await applicationsApi.transitionStatus(id, toStatus, note);
    set((state) => ({
      applications: state.applications.map((app) =>
        app.id === id
          ? { ...app, status: toStatus, updated_at: log.created_at }
          : app,
      ),
      timelines: {
        ...state.timelines,
        [id]: [log, ...(state.timelines[id] ?? [])],
      },
    }));
    void get().fetchStats();
  },

  setFilter: (key, value) =>
    set((state) => ({
      filters: { ...state.filters, [key]: value },
    })),

  resetFilters: () => set({ filters: { ...defaultFilters } }),

  getById: (id) => get().applications.find((app) => app.id === id),
}));

/** 选择器：根据当前过滤器筛选投递记录 */
export function selectFilteredApplications(state: ApplicationState): Application[] {
  const { applications, filters } = state;
  return applications.filter((app) => {
    if (filters.status !== "all" && app.status !== filters.status) return false;
    if (filters.source !== "all" && app.source !== filters.source) return false;
    if (filters.priority !== "all" && app.priority !== filters.priority)
      return false;
    if (filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      const haystack = `${app.company} ${app.position} ${app.location ?? ""}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
}
