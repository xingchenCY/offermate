/**
 * OfferMate 扩展弹窗逻辑
 *
 * 职责：
 *   1. 页面加载时检查与 OfferMate 的连接状态 (GET /api/health)
 *   2. 获取当前活动标签页，抓取岗位信息并预览
 *   3. "导入到 OfferMate" 按钮：触发 content script 抓取 -> 通过 background 导入
 *   4. "打开 OfferMate" 按钮：尝试唤起 offermate:// 协议
 *   5. 从 chrome.storage.local 读取并展示最近导入历史
 *   6. 导入成功后更新历史记录
 */

(function () {
  "use strict";

  const OFFERMATE_HEALTH = "http://localhost:9420/api/health";

  // DOM 元素引用
  const statusEl = document.getElementById("status");
  const statusTextEl = document.getElementById("status-text");
  const jobPreviewEl = document.getElementById("job-preview");
  const btnImport = document.getElementById("btn-import");
  const btnOpen = document.getElementById("btn-open");
  const historyListEl = document.getElementById("history-list");
  const toastEl = document.getElementById("toast");
  const queueBannerEl = document.getElementById("queue-banner");
  const queueCountEl = document.getElementById("queue-count");
  const manualInputEl = document.getElementById("manual-input");
  const btnManualToggle = document.getElementById("btn-manual-toggle");
  const btnManualSubmit = document.getElementById("btn-manual-submit");
  const inputCompany = document.getElementById("input-company");
  const inputPosition = document.getElementById("input-position");
  const inputSalary = document.getElementById("input-salary");
  const inputLocation = document.getElementById("input-location");

  // 缓存当前抓取到的岗位信息
  let currentJobInfo = null;

  // ============================================================
  // 工具函数
  // ============================================================

  /**
   * 显示提示条
   * @param {string} message
   * @param {"success"|"error"|""} [type]
   */
  function showToast(message, type = "") {
    toastEl.textContent = message;
    toastEl.className = "toast show " + type;
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => {
      toastEl.className = "toast " + type;
    }, 2600);
  }

  /**
   * 转义 HTML，防止注入
   * @param {string} str
   * @returns {string}
   */
  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /**
   * 相对时间格式化
   * @param {number} timestamp
   * @returns {string}
   */
  function timeAgo(timestamp) {
    const diff = Date.now() - timestamp;
    const min = Math.floor(diff / 60000);
    if (min < 1) return "刚刚";
    if (min < 60) return `${min} 分钟前`;
    const hour = Math.floor(min / 60);
    if (hour < 24) return `${hour} 小时前`;
    const day = Math.floor(hour / 24);
    if (day < 30) return `${day} 天前`;
    const d = new Date(timestamp);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }

  /**
   * 发送消息给 background.js 并等待响应
   * @param {Object} message
   * @returns {Promise<Object>}
   */
  function sendBgMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (resp) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(resp);
        }
      });
    });
  }

  /**
   * 获取当前活动标签页
   * @returns {Promise<chrome.tabs.Tab>}
   */
  function getActiveTab() {
    return new Promise((resolve, reject) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (tabs && tabs.length > 0) {
          resolve(tabs[0]);
        } else {
          reject(new Error("未找到活动标签页"));
        }
      });
    });
  }

  /**
   * 向 content script 发送抓取请求
   * @param {number} tabId
   * @returns {Promise<Object|null>}
   */
  function requestExtract(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type: "OFFERMATE_EXTRACT" }, (resp) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else if (resp && resp.success) {
          resolve(resp.data);
        } else {
          resolve(null);
        }
      });
    });
  }

  /**
   * 编程式注入 content.js 到指定标签页
   * 用于 content script 未通过 manifest 自动注入的场景
   * @param {number} tabId
   * @returns {Promise<boolean>}
   */
  async function injectContentScript(tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"],
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * 判断 URL 是否属于已知招聘网站
   * @param {string} url
   * @returns {boolean}
   */
  function isRecruitmentSite(url) {
    if (!url) return false;
    const patterns = [
      /zhipin\.com/i, /zhaopin\.com/i, /nowcoder\.com/i,
      /lagou\.com/i, /51job\.com/i, /liepin\.com/i,
      /linkedin\.com/i, /indeed\./i, /glassdoor\./i,
      /maimai\.cn/i, /kanzhun\.com/i, /zhipin/i,
    ];
    return patterns.some((p) => p.test(url));
  }

  /**
   * 从 URL 提取来源标识
   * @param {string} url
   * @returns {string}
   */
  function detectSourceFromUrl(url) {
    if (!url) return "unknown";
    if (/zhipin\.com/i.test(url)) return "boss";
    if (/zhaopin\.com/i.test(url)) return "zhilian";
    if (/nowcoder\.com/i.test(url)) return "nowcoder";
    if (/lagou\.com/i.test(url)) return "lagou";
    if (/51job\.com/i.test(url)) return "51job";
    if (/liepin\.com/i.test(url)) return "liepin";
    return "unknown";
  }

  /**
   * 显示手动输入表单
   */
  function showManualInput() {
    if (manualInputEl) manualInputEl.classList.add("show");
    if (btnManualToggle) btnManualToggle.style.display = "none";
  }

  /**
   * 隐藏手动输入表单
   */
  function hideManualInput() {
    if (manualInputEl) manualInputEl.classList.remove("show");
    if (btnManualToggle) btnManualToggle.style.display = "";
  }

  // ============================================================
  // 连接状态检查
  // ============================================================

  async function checkConnection() {
    // 优先通过 background 检查（避免 popup 直接 fetch 的 CORS 问题）
    try {
      const resp = await sendBgMessage({ type: "OFFERMATE_CHECK_HEALTH" });
      if (resp && resp.online) {
        statusEl.classList.add("online");
        statusTextEl.textContent = "已连接";
        return true;
      }
    } catch (_) {
      // 回退到直接 fetch
    }

    // 回退：popup 直接请求 health
    try {
      const res = await fetch(OFFERMATE_HEALTH, {
        method: "GET",
        mode: "cors",
        signal: AbortSignal.timeout(2000),
      });
      if (res.ok) {
        statusEl.classList.add("online");
        statusTextEl.textContent = "已连接";
        return true;
      }
    } catch (_) {
      // 离线
    }

    statusEl.classList.remove("online");
    statusTextEl.textContent = "未连接";
    return false;
  }

  // ============================================================
  // 岗位预览
  // ============================================================

  function renderJobPreview(jobInfo) {
    if (!jobInfo || (!jobInfo.position && !jobInfo.company)) {
      jobPreviewEl.className = "job-preview empty";
      jobPreviewEl.textContent =
        "未识别到岗位信息，请在招聘网站岗位详情页使用。";
      btnImport.disabled = true;
      currentJobInfo = null;
      return;
    }

    jobPreviewEl.className = "job-preview";
    const salaryHtml = jobInfo.salary
      ? `<span class="job-salary">${escapeHtml(jobInfo.salary)}</span>`
      : "";
    const locationHtml = jobInfo.location
      ? `<span>${escapeHtml(jobInfo.location)}</span>`
      : "";
    const sourceMap = {
      boss: "Boss直聘",
      zhilian: "智联招聘",
      nowcoder: "牛客网",
      lagou: "拉勾",
      "51job": "前程无忧",
      liepin: "猎聘",
      unknown: "招聘网站",
    };
    const sourceHtml = jobInfo.source
      ? `<span>${escapeHtml(sourceMap[jobInfo.source] || jobInfo.source)}</span>`
      : "";

    jobPreviewEl.innerHTML = `
      <div class="job-position">${escapeHtml(jobInfo.position || "未知职位")}</div>
      <div class="job-company">${escapeHtml(jobInfo.company || "未知公司")}</div>
      <div class="job-meta">${salaryHtml}${locationHtml}${sourceHtml}</div>
    `;

    // 公司或职位为空时禁止导入，避免服务端 500 错误
    const hasCoreInfo = jobInfo.company && jobInfo.position;
    btnImport.disabled = !hasCoreInfo;
    if (!hasCoreInfo) {
      const missing = [];
      if (!jobInfo.company) missing.push("公司名");
      if (!jobInfo.position) missing.push("职位名");
      showToast(`未识别到${missing.join("和")}，请尝试在岗位详情页使用`, "error");
    }
    currentJobInfo = jobInfo;
  }

  // ============================================================
  // 导入历史
  // ============================================================

  async function loadHistory() {
    try {
      const result = await chrome.storage.local.get("offermate_import_history");
      const history = result.offermate_import_history || [];
      renderHistory(history.slice(0, 5));
    } catch (e) {
      renderHistory([]);
    }
  }

  function renderHistory(history) {
    if (!history || history.length === 0) {
      historyListEl.innerHTML = `<li class="history-empty">暂无导入记录</li>`;
      return;
    }

    historyListEl.innerHTML = history
      .map((item) => {
        const status = item.status || (item.success ? "success" : "error");
        let iconClass = "fail";
        let iconChar = "✕";
        if (status === "success") {
          iconClass = "success";
          iconChar = "✓";
        } else if (status === "duplicate") {
          iconClass = "duplicate";
          iconChar = "↻";
        }

        const displayPosition = item.position || "未知职位";
        const displayCompany = item.company || "未知公司";

        return `
        <li class="history-item">
          <div class="history-icon ${iconClass}">
            ${iconChar}
          </div>
          <div class="history-info">
            <div class="history-title">${escapeHtml(displayPosition)} · ${escapeHtml(displayCompany)}</div>
            <div class="history-time">${timeAgo(item.timestamp)}${
          item.message ? " · " + escapeHtml(item.message) : ""
        }</div>
          </div>
        </li>
      `;
      })
      .join("");
  }

  // ============================================================
  // 待导入队列
  // ============================================================

  async function loadQueue() {
    try {
      const resp = await sendBgMessage({ type: "OFFERMATE_GET_QUEUE" });
      if (resp && resp.queue && resp.queue.length > 0) {
        queueCountEl.textContent = resp.queue.length;
        queueBannerEl.classList.add("show");
      } else {
        queueBannerEl.classList.remove("show");
      }
    } catch (_) {
      // 忽略
    }
  }

  // ============================================================
  // 事件绑定
  // ============================================================

  // 导入按钮
  btnImport.addEventListener("click", async () => {
    if (!currentJobInfo) {
      showToast("没有可导入的岗位信息", "error");
      return;
    }

    btnImport.disabled = true;
    const originalText = btnImport.textContent;
    btnImport.textContent = "导入中…";

    try {
      const resp = await sendBgMessage({
        type: "OFFERMATE_IMPORT",
        data: currentJobInfo,
      });

      if (resp && resp.success) {
        showToast(resp.message || "导入成功", "success");
        await loadHistory();
        await loadQueue();
      } else if (resp && resp.queued) {
        showToast(resp.message || "已加入待导入队列", "success");
        await loadQueue();
      } else if (resp && resp.duplicate) {
        showToast(resp.message || "该岗位已导入过", "");
        await loadHistory();
      } else {
        showToast((resp && resp.message) || "导入失败", "error");
      }
    } catch (e) {
      showToast("导入失败：" + (e.message || e), "error");
    } finally {
      btnImport.disabled = false;
      btnImport.textContent = originalText;
    }
  });

  // 打开 OfferMate 按钮
  btnOpen.addEventListener("click", async () => {
    // 尝试通过自定义协议唤起桌面应用
    try {
      window.location.href = "offermate://open";
      // 兜底：如果协议未注册，给用户提示
      setTimeout(() => {
        showToast("如未自动打开，请手动启动 OfferMate 桌面应用", "");
      }, 1200);
    } catch (e) {
      showToast("无法自动打开 OfferMate，请手动启动", "error");
    }
  });

  // 点击队列横幅时尝试刷新队列
  queueBannerEl.addEventListener("click", async () => {
    try {
      const resp = await sendBgMessage({ type: "OFFERMATE_FLUSH_QUEUE" });
      if (resp && resp.success) {
        showToast("已尝试同步待导入队列", "success");
        await loadQueue();
        await loadHistory();
      } else {
        showToast((resp && resp.message) || "同步失败", "error");
      }
    } catch (e) {
      showToast("同步失败：" + (e.message || e), "error");
    }
  });

  // ============================================================
  // 手动输入
  // ============================================================

  // "手动输入" 按钮点击 — 展开输入表单，预填已有数据
  if (btnManualToggle) {
    btnManualToggle.addEventListener("click", () => {
      // 如果已有自动提取的数据，预填到输入框
      if (currentJobInfo) {
        if (inputCompany) inputCompany.value = currentJobInfo.company || "";
        if (inputPosition) inputPosition.value = currentJobInfo.position || "";
        if (inputSalary) inputSalary.value = currentJobInfo.salary || "";
        if (inputLocation) inputLocation.value = currentJobInfo.location || "";
      }
      showManualInput();
      if (inputCompany) inputCompany.focus();
    });
  }

  // 手动输入提交
  if (btnManualSubmit) {
    btnManualSubmit.addEventListener("click", async () => {
      const company = inputCompany?.value?.trim() || "";
      const position = inputPosition?.value?.trim() || "";

      if (!company || !position) {
        showToast("请输入公司名称和职位名称", "error");
        return;
      }

      const jobInfo = {
        company,
        position,
        salary: inputSalary?.value?.trim() || "",
        location: inputLocation?.value?.trim() || "",
        description: "",
        requirements: "",
        source: "manual",
        url: "",
      };

      // 渲染预览并启用导入按钮
      currentJobInfo = jobInfo;
      jobPreviewEl.className = "job-preview";
      const salaryHtml = jobInfo.salary
        ? `<span class="job-salary">${escapeHtml(jobInfo.salary)}</span>`
        : "";
      const locationHtml = jobInfo.location
        ? `<span>${escapeHtml(jobInfo.location)}</span>`
        : "";
      jobPreviewEl.innerHTML = `
        <div class="job-position">${escapeHtml(position)}</div>
        <div class="job-company">${escapeHtml(company)}</div>
        <div class="job-meta">${salaryHtml}${locationHtml}<span>手动输入</span></div>
      `;
      btnImport.disabled = false;
      hideManualInput();
      showToast("已填写岗位信息，点击「导入到 OfferMate」", "");
    });
  }

  // ============================================================
  // 初始化
  // ============================================================

  async function init() {
    // 并行执行：检查连接、加载历史、加载队列
    const [online] = await Promise.all([checkConnection(), loadHistory(), loadQueue()]);

    // 获取当前标签页并尝试抓取岗位信息
    try {
      const tab = await getActiveTab();
      const tabUrl = tab.url || "";

      // 第一步：尝试通过已注入的 content script 提取
      let jobInfo = await requestExtract(tab.id);

      // 第二步：如果未响应，尝试编程式注入 content.js 后再提取
      if (!jobInfo && tabUrl.startsWith("http")) {
        const injected = await injectContentScript(tab.id);
        if (injected) {
          // 注入后稍等一下让脚本初始化
          await new Promise((r) => setTimeout(r, 300));
          jobInfo = await requestExtract(tab.id);
        }
      }

      // 第三步：根据提取结果显示
      if (jobInfo && (jobInfo.company || jobInfo.position)) {
        renderJobPreview(jobInfo);
        hideManualInput();
      } else {
        // 提取失败：根据页面类型显示不同提示
        const isRecSite = isRecruitmentSite(tabUrl);
        jobPreviewEl.className = "job-preview empty";

        if (isRecSite) {
          jobPreviewEl.textContent = "未识别到岗位信息，请确保在岗位详情页使用，或手动输入。";
        } else if (tabUrl.startsWith("chrome://") || tabUrl.startsWith("chrome-extension://")) {
          jobPreviewEl.textContent = "浏览器内部页面无法抓取，请打开招聘网站岗位详情页。";
        } else if (tabUrl.startsWith("http")) {
          jobPreviewEl.textContent = "当前页面不是已知招聘网站，可手动输入岗位信息。";
        } else {
          jobPreviewEl.textContent = "请打开招聘网站岗位详情页，或手动输入岗位信息。";
        }

        btnImport.disabled = true;
        showManualInput();
      }
    } catch (e) {
      jobPreviewEl.className = "job-preview empty";
      jobPreviewEl.textContent = "无法读取当前页面信息，可手动输入岗位信息。";
      btnImport.disabled = true;
      showManualInput();
    }

    // 如果已连接且有待导入队列，提示用户可同步
    if (online) {
      const resp = await sendBgMessage({ type: "OFFERMATE_GET_QUEUE" }).catch(
        () => null
      );
      if (resp && resp.queue && resp.queue.length > 0) {
        showToast(`检测到 ${resp.queue.length} 个待导入岗位，可点击同步`, "");
      }
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
