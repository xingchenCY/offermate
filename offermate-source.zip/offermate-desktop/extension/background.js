/**
 * OfferMate 后台 Service Worker (Manifest V3)
 *
 * 职责：
 *   1. 监听来自 content.js 的岗位抓取消息
 *   2. 将岗位信息通过 fetch POST 发送到 OfferMate 桌面应用 (localhost:9420/api/import)
 *   3. 处理导入成功/失败，并通过 Chrome 通知告知用户
 *   4. 维护待导入队列：OfferMate 未运行时缓存，恢复连接后重试
 *   5. 监听扩展图标点击与连接状态变化
 */

// OfferMate 桌面应用的本地服务地址
const OFFERMATE_BASE = "http://localhost:9420";
const IMPORT_ENDPOINT = `${OFFERMATE_BASE}/api/import`;
const HEALTH_ENDPOINT = `${OFFERMATE_BASE}/api/health`;

// 待导入队列的存储键
const QUEUE_KEY = "offermate_pending_queue";
// 导入历史记录的存储键
const HISTORY_KEY = "offermate_import_history";
// 最多保留的历史记录条数
const MAX_HISTORY = 20;

// ============================================================
// 订阅监控相关常量（chrome.alarms 定时抓取模式）
// ============================================================
const SUBSCRIPTIONS_ENDPOINT = `${OFFERMATE_BASE}/api/subscriptions`;
const IMPORT_BATCH_ENDPOINT = `${OFFERMATE_BASE}/api/import-batch`;
const ALARM_NAME = "offermate_monitor";
const MONITOR_INTERVAL_MINUTES = 1; // Check every minute
const MONITOR_STORAGE_KEY = "offermate_monitor_state";

// ============================================================
// 工具函数
// ============================================================

/**
 * 获取待导入队列
 * @returns {Promise<Array>}
 */
async function getQueue() {
  try {
    const result = await chrome.storage.local.get(QUEUE_KEY);
    return result[QUEUE_KEY] || [];
  } catch (e) {
    return [];
  }
}

/**
 * 保存待导入队列
 * @param {Array} queue
 */
async function saveQueue(queue) {
  await chrome.storage.local.set({ [QUEUE_KEY]: queue });
}

/**
 * 获取导入历史
 * @returns {Promise<Array>}
 */
async function getHistory() {
  try {
    const result = await chrome.storage.local.get(HISTORY_KEY);
    return result[HISTORY_KEY] || [];
  } catch (e) {
    return [];
  }
}

/**
 * 向历史记录中添加一条记录
 * @param {Object} jobInfo
 * @param {boolean} success
 * @param {string} [message]
 * @param {string} [status] - "success" | "duplicate" | "error"
 */
async function addHistory(jobInfo, success, message, status) {
  const history = await getHistory();
  history.unshift({
    company: jobInfo.company || "",
    position: jobInfo.position || "",
    source: jobInfo.source || "unknown",
    success,
    status: status || (success ? "success" : "error"),
    message: message || "",
    timestamp: Date.now(),
  });
  // 限制历史记录数量
  const trimmed = history.slice(0, MAX_HISTORY);
  await chrome.storage.local.set({ [HISTORY_KEY]: trimmed });
}

/**
 * 发送 Chrome 通知
 * @param {string} title
 * @param {string} message
 */
function notify(title, message) {
  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon.svg",
      title,
      message,
      priority: 2,
    });
  } catch (e) {
    // 通知失败时静默处理（可能未授权）
    console.warn("[OfferMate] 通知发送失败:", e);
  }
}

// ============================================================
// 与 OfferMate 桌面应用通信
// ============================================================

/**
 * 检查 OfferMate 是否在线
 * @returns {Promise<boolean>}
 */
async function checkHealth() {
  try {
    const resp = await fetch(HEALTH_ENDPOINT, {
      method: "GET",
      mode: "cors",
      signal: AbortSignal.timeout(2500),
    });
    return resp.ok;
  } catch (e) {
    return false;
  }
}

/**
 * 将岗位信息导入到 OfferMate
 * @param {Object} jobInfo
 * @returns {Promise<{ success: boolean, message: string, status: string }>}
 */
async function importToOfferMate(jobInfo) {
  try {
    const resp = await fetch(IMPORT_ENDPOINT, {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jobInfo),
      signal: AbortSignal.timeout(5000),
    });

    const text = await resp.text().catch(() => "");
    let serverMsg = "";
    try {
      const json = JSON.parse(text);
      serverMsg = json.message || "";
    } catch (_) { /* 非 JSON 响应 */ }

    if (resp.ok) {
      return { success: true, message: serverMsg || "导入成功", status: "success" };
    }

    // 400: 数据不完整（缺少公司名或职位名）
    if (resp.status === 400) {
      return {
        success: false,
        message: serverMsg || "岗位信息不完整，请在岗位详情页使用",
        status: "validation_error",
      };
    }

    // 409: 重复岗位
    if (resp.status === 409) {
      return {
        success: false,
        message: serverMsg || "该岗位已导入过",
        status: "duplicate",
      };
    }

    // 其他错误
    return {
      success: false,
      message: serverMsg || `导入失败：服务器返回 ${resp.status}`,
      status: "error",
    };
  } catch (e) {
    return {
      success: false,
      message: `无法连接到 OfferMate：${e.message || e}`,
      status: "error",
    };
  }
}

/**
 * 尝试导入岗位信息，若 OfferMate 离线则加入队列
 * @param {Object} jobInfo
 * @param {boolean} [notifyUser=true] 是否在导入后发送通知
 */
async function tryImport(jobInfo, notifyUser = true) {
  const online = await checkHealth();

  if (!online) {
    // OfferMate 未运行，加入待导入队列
    const queue = await getQueue();
    queue.push(jobInfo);
    await saveQueue(queue);
    if (notifyUser) {
      notify(
        "OfferMate 未运行",
        `已将「${jobInfo.position || "岗位"}」加入待导入队列，启动 OfferMate 后将自动导入。`
      );
    }
    return { success: false, queued: true, message: "已加入待导入队列" };
  }

  const result = await importToOfferMate(jobInfo);
  await addHistory(jobInfo, result.success, result.message, result.status);

  if (result.success) {
    if (notifyUser) {
      notify(
        "导入成功",
        `「${jobInfo.position || "岗位"} @ ${jobInfo.company || ""}」已导入 OfferMate`
      );
    }
    return { success: true, message: result.message };
  }

  // 重复岗位：不算失败，但告知用户
  if (result.status === "duplicate") {
    if (notifyUser) {
      notify("岗位已存在", result.message);
    }
    return { success: false, message: result.message, duplicate: true };
  }

  // 验证错误或其他错误
  if (notifyUser) {
    notify("导入失败", result.message);
  }
  return { success: false, message: result.message };
}

/**
 * 刷新待导入队列：OfferMate 在线时尝试导入队列中缓存的岗位
 */
async function flushQueue() {
  const queue = await getQueue();
  if (queue.length === 0) return;

  const online = await checkHealth();
  if (!online) return;

  const remaining = [];
  let importedCount = 0;

  for (const jobInfo of queue) {
    const result = await importToOfferMate(jobInfo);
    await addHistory(jobInfo, result.success, result.message, result.status);
    if (result.success) {
      importedCount++;
    } else if (result.status === "duplicate" || result.status === "validation_error") {
      // 重复或数据不全的岗位不再保留在队列中
    } else {
      remaining.push(jobInfo);
    }
  }

  await saveQueue(remaining);

  if (importedCount > 0) {
    notify(
      "队列导入完成",
      `已从待导入队列导入 ${importedCount} 个岗位到 OfferMate。`
    );
  }
}

// ============================================================
// 订阅监控模式（chrome.alarms 定时抓取）
// ============================================================

/**
 * 读取监控状态（上次检查时间、各订阅最后抓取时间等）
 * @returns {Promise<Object>}
 */
async function getMonitorState() {
  try {
    const result = await chrome.storage.local.get(MONITOR_STORAGE_KEY);
    return (
      result[MONITOR_STORAGE_KEY] || { lastCheck: {}, lastRun: 0 }
    );
  } catch (e) {
    return { lastCheck: {}, lastRun: 0 };
  }
}

/**
 * 保存监控状态
 * @param {Object} state
 */
async function saveMonitorState(state) {
  try {
    await chrome.storage.local.set({ [MONITOR_STORAGE_KEY]: state });
  } catch (e) {
    console.warn("[OfferMate] 保存监控状态失败:", e);
  }
}

/**
 * 从 OfferMate 同步已启用的订阅列表
 * 离线时返回空数组
 * @returns {Promise<Array>}
 */
async function syncSubscriptions() {
  try {
    const resp = await fetch(SUBSCRIPTIONS_ENDPOINT, {
      method: "GET",
      mode: "cors",
      signal: AbortSignal.timeout(5000),
    });
    if (!resp.ok) return [];
    const data = await resp.json();
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.data)) return data.data;
    if (data && Array.isArray(data.subscriptions))
      return data.subscriptions;
    return [];
  } catch (e) {
    return [];
  }
}

/**
 * 根据平台 / 关键词 / 地点构建搜索 URL
 * @param {string} platform - boss/zhilian/lagou/51job/liepin/nowcoder
 * @param {string} keywords
 * @param {string} location
 * @param {string} [companies] - 预留参数（暂未使用，可附加到关键词）
 * @returns {string} 搜索 URL，未知平台返回空字符串
 */
function buildSearchUrl(platform, keywords, location, companies) {
  const kw = encodeURIComponent(keywords || "");
  const loc = encodeURIComponent(location || "");
  switch (platform) {
    case "boss":
      return `https://www.zhipin.com/web/geek/job?query=${kw}&city=${loc}`;
    case "zhilian":
      return `https://sou.zhaopin.com/?jl=${loc}&kw=${kw}`;
    case "lagou":
      return `https://www.lagou.com/wn/zhaopin?city=${loc}&pn=1&kd=${kw}`;
    case "51job":
      return `https://we.51job.com/pc/search?keyword=${kw}&searchType=2&jobArea=${loc}`;
    case "liepin":
      return `https://www.liepin.com/zhaopin/?key=${kw}&dq=${loc}`;
    case "nowcoder":
      return `https://www.nowcoder.com/jobs?keyword=${kw}&city=${loc}`;
    default:
      return "";
  }
}

/**
 * 等待指定标签页加载完成（status === "complete"）
 * @param {number} tabId
 * @param {number} [timeoutMs=15000]
 * @returns {Promise<boolean>} 加载完成返回 true，超时返回 false
 */
function waitForTabComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve) => {
    let resolved = false;
    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        try {
          chrome.tabs.onUpdated.removeListener(listener);
        } catch (_) {}
        resolve(false);
      }
    }, timeoutMs);

    function listener(id, changeInfo, tab) {
      if (id === tabId && tab.status === "complete") {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          try {
            chrome.tabs.onUpdated.removeListener(listener);
          } catch (_) {}
          resolve(true);
        }
      }
    }
    chrome.tabs.onUpdated.addListener(listener);

    // 标签页可能已经完成加载，立即检查一次
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          try {
            chrome.tabs.onUpdated.removeListener(listener);
          } catch (_) {}
          resolve(false);
        }
        return;
      }
      if (tab && tab.status === "complete" && !resolved) {
        resolved = true;
        clearTimeout(timer);
        try {
          chrome.tabs.onUpdated.removeListener(listener);
        } catch (_) {}
        resolve(true);
      }
    });
  });
}

/**
 * 对单个到期订阅执行一次列表页抓取
 * 流程：构建搜索 URL -> 打开后台标签页 -> 等待加载 -> 发送批量抓取消息 -> 导入 -> 关闭标签页
 * @param {Object} subscription
 * @returns {Promise<number>} 本次抓取到的岗位数量
 */
async function runSubscriptionScrape(subscription) {
  let tabId = null;
  try {
    const url = buildSearchUrl(
      subscription.platform,
      subscription.keywords,
      subscription.location,
      subscription.companies
    );
    if (!url) return 0;

    const tab = await chrome.tabs.create({ url, active: false });
    tabId = tab.id;

    const loaded = await waitForTabComplete(tabId, 15000);
    if (!loaded) {
      return 0;
    }

    // 给内容脚本一点时间完成注入与初始化
    await new Promise((r) => setTimeout(r, 1200));

    let response;
    try {
      response = await chrome.tabs.sendMessage(tabId, {
        type: "OFFERMATE_EXTRACT_BATCH",
      });
    } catch (e) {
      // 内容脚本未响应（可能未被注入到该页面）
      console.warn("[OfferMate] 批量抓取消息发送失败:", e);
      return 0;
    }

    const jobs =
      (response && response.success && Array.isArray(response.data) &&
        response.data) ||
      [];
    if (jobs.length === 0) {
      return 0;
    }

    // 将批量结果 POST 到 OfferMate 导入接口
    try {
      await fetch(IMPORT_BATCH_ENDPOINT, {
        method: "POST",
        mode: "cors",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jobs,
          subscription_id: subscription.id,
        }),
        signal: AbortSignal.timeout(10000),
      });
    } catch (e) {
      // 导入失败仍返回抓取数量，便于统计
      console.warn("[OfferMate] 批量导入失败:", e);
    }

    return jobs.length;
  } catch (e) {
    console.warn("[OfferMate] 订阅抓取失败:", e);
    return 0;
  } finally {
    if (tabId != null) {
      try {
        await chrome.tabs.remove(tabId);
      } catch (_) {
        // 标签页可能已被关闭
      }
    }
  }
}

/**
 * 主监控检查：检查 OfferMate 在线状态、同步订阅、对到期订阅执行抓取
 * @returns {Promise<{online:boolean, checked:number, newJobs:number}>}
 */
async function checkDueSubscriptions() {
  const online = await checkHealth();
  if (!online) {
    return { online: false, checked: 0, newJobs: 0 };
  }

  const subscriptions = await syncSubscriptions();
  if (!subscriptions || subscriptions.length === 0) {
    return { online: true, checked: 0, newJobs: 0 };
  }

  const state = await getMonitorState();
  if (!state.lastCheck) state.lastCheck = {};
  let totalNew = 0;
  let checkedCount = 0;
  const now = Date.now();

  for (const sub of subscriptions) {
    if (!sub || sub.enabled === false) continue;
    const intervalMs = (sub.interval_minutes || 30) * 60 * 1000;
    const last = state.lastCheck[sub.id] || 0;
    if (now - last < intervalMs) {
      continue; // 尚未到期
    }
    checkedCount++;
    const count = await runSubscriptionScrape(sub);
    state.lastCheck[sub.id] = now;
    if (count > 0) {
      totalNew += count;
    }
  }

  state.lastRun = now;
  await saveMonitorState(state);

  if (totalNew > 0) {
    notify(
      "OfferMate 订阅监控",
      `本次检查发现 ${totalNew} 个新岗位，已导入 OfferMate。`
    );
  }

  return { online: true, checked: checkedCount, newJobs: totalNew };
}

// ============================================================
// 消息监听
// ============================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 来自 content.js：检测到岗位信息
  if (message && message.type === "OFFERMATE_JOB_DETECTED") {
    // 静默处理，不发通知，仅缓存以备导入
    sendResponse({ success: true, received: true });
    return true;
  }

  // 来自 popup.js：请求导入当前岗位
  if (message && message.type === "OFFERMATE_IMPORT") {
    const jobInfo = message.data;
    if (!jobInfo) {
      sendResponse({ success: false, message: "没有可导入的岗位信息" });
      return true;
    }
    tryImport(jobInfo, true)
      .then((result) => sendResponse(result))
      .catch((e) =>
        sendResponse({ success: false, message: e.message || String(e) })
      );
    return true; // 异步响应
  }

  // 来自 popup.js：检查连接状态
  if (message && message.type === "OFFERMATE_CHECK_HEALTH") {
    checkHealth()
      .then((online) => sendResponse({ success: true, online }))
      .catch(() => sendResponse({ success: false, online: false }));
    return true;
  }

  // 来自 popup.js：请求待导入队列
  if (message && message.type === "OFFERMATE_GET_QUEUE") {
    getQueue()
      .then((queue) => sendResponse({ success: true, queue }))
      .catch(() => sendResponse({ success: false, queue: [] }));
    return true;
  }

  // 来自 popup.js：请求刷新队列
  if (message && message.type === "OFFERMATE_FLUSH_QUEUE") {
    flushQueue()
      .then(() => sendResponse({ success: true }))
      .catch((e) => sendResponse({ success: false, message: e.message }));
    return true;
  }

  // 来自 popup.js：查询订阅监控状态
  if (message && message.type === "OFFERMATE_MONITOR_STATUS") {
    getMonitorState()
      .then((state) => sendResponse({ success: true, state }))
      .catch(() => sendResponse({ success: false, state: null }));
    return true;
  }

  // 来自 popup.js：手动触发一次监控检查
  if (message && message.type === "OFFERMATE_MONITOR_TRIGGER") {
    checkDueSubscriptions()
      .then((result) => sendResponse({ success: true, result }))
      .catch((e) =>
        sendResponse({ success: false, error: e.message || String(e) })
      );
    return true;
  }
});

// ============================================================
// 扩展图标点击 - 当没有 popup 时作为后备（popup.html 存在时此事件不触发）
// ============================================================
chrome.action.onClicked.addListener(async (tab) => {
  // popup.html 已配置，此回调一般不触发；保留作为兜底
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "OFFERMATE_EXTRACT" });
  } catch (e) {
    notify("OfferMate", "请在支持的招聘网站页面使用本扩展。");
  }
});

// ============================================================
// 安装 / 启动事件
// ============================================================
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    notify(
      "OfferMate 岗位抓取助手已安装",
      "请在支持的招聘网站（Boss直聘、智联、牛客、拉勾、51job、猎聘）打开岗位页面，点击扩展图标即可抓取导入。"
    );
  }
  // 初始化空队列与历史（若不存在）
  chrome.storage.local.get([QUEUE_KEY, HISTORY_KEY], (result) => {
    if (!result[QUEUE_KEY]) chrome.storage.local.set({ [QUEUE_KEY]: [] });
    if (!result[HISTORY_KEY]) chrome.storage.local.set({ [HISTORY_KEY]: [] });
  });
  // 创建定时监控闹钟（每分钟检查一次到期订阅）
  chrome.alarms.create(ALARM_NAME, {
    delayInMinutes: 1,
    periodInMinutes: MONITOR_INTERVAL_MINUTES,
  });
});

// Service Worker 启动时尝试刷新队列，并恢复定时监控闹钟
chrome.runtime.onStartup.addListener(() => {
  flushQueue().catch(() => {});
  chrome.alarms.create(ALARM_NAME, {
    delayInMinutes: 1,
    periodInMinutes: MONITOR_INTERVAL_MINUTES,
  });
});

// ============================================================
// chrome.alarms 定时监控
// ============================================================
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    checkDueSubscriptions().catch(console.error);
  }
});

console.log("[OfferMate] 后台 Service Worker 已启动");
