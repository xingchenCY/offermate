/**
 * OfferMate 内容脚本 - 从招聘网页抓取岗位信息
 *
 * 支持站点：
 *   - Boss 直聘 (zhipin.com)
 *   - 智联招聘 (zhaopin.com)
 *   - 牛客网 (nowcoder.com)
 *   - 拉勾 (lagou.com)
 *   - 前程无忧 (51job.com)
 *   - 猎聘 (liepin.com)
 *   - 通用回退策略（meta 标签 + 常见选择器）
 *
 * 抓取结果统一为如下结构：
 *   { company, position, salary, location, description, requirements, source, url }
 */

(function () {
  "use strict";

  // ============================================================
  // 工具函数
  // ============================================================

  /**
   * 安全地获取元素的文本内容，找不到时返回空字符串
   * @param {string} selector - CSS 选择器
   * @param {string} [attr] - 可选，取属性值而非文本
   * @returns {string}
   */
  function getText(selector, attr) {
    try {
      const el = document.querySelector(selector);
      if (!el) return "";
      if (attr) {
        return (el.getAttribute(attr) || "").trim();
      }
      return (el.innerText || el.textContent || "").trim();
    } catch (e) {
      return "";
    }
  }

  /**
   * 尝试多个选择器，返回第一个命中的文本
   * @param {string[]} selectors - CSS 选择器数组
   * @returns {string}
   */
  function getTextFromAny(selectors) {
    for (const sel of selectors) {
      const text = getText(sel);
      if (text) return text;
    }
    return "";
  }

  /**
   * 从一段文本中清洗出更整洁的内容
   * @param {string} text
   * @returns {string}
   */
  function cleanText(text) {
    if (!text) return "";
    return text
      .replace(/\s+/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  /**
   * 获取当前页面来源标识
   * @returns {string}
   */
  function detectSource() {
    const host = location.hostname;
    if (host.includes("zhipin.com")) return "boss";
    if (host.includes("zhaopin.com")) return "zhilian";
    if (host.includes("nowcoder.com")) return "nowcoder";
    if (host.includes("lagou.com")) return "lagou";
    if (host.includes("51job.com")) return "51job";
    if (host.includes("liepin.com")) return "liepin";
    return "unknown";
  }

  /**
   * 从 JSON-LD 结构化数据中提取岗位信息（schema.org/JobPosting）
   * 很多招聘网站都在页面中嵌入了 JSON-LD，这是最可靠的数据源
   * @returns {{ company:string, position:string, salary:string, location:string, description:string }|null}
   */
  function extractFromJsonLd() {
    try {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const script of scripts) {
        const text = script.textContent || "";
        if (!text) continue;
        let data;
        try { data = JSON.parse(text); } catch (_) { continue; }
        if (!data) continue;

        const items = Array.isArray(data["@graph"]) ? data["@graph"] : [data];
        for (const item of items) {
          if (item["@type"] === "JobPosting" || (item["@type"] && item["@type"].includes("JobPosting"))) {
            const company = item.hiringOrganization
              ? (typeof item.hiringOrganization === "object"
                ? (item.hiringOrganization.name || "")
                : String(item.hiringOrganization))
              : "";
            const position = item.title || "";
            const description = cleanText(item.description || "");
            let salary = "";
            if (item.baseSalary && typeof item.baseSalary === "object") {
              const val = item.baseSalary.value || item.baseSalary;
              if (typeof val === "object") {
                salary = val.minValue && val.maxValue
                  ? `${val.minValue}-${val.maxValue}${val.unitText ? val.unitText : ""}`
                  : (val.value || "");
              } else {
                salary = String(val);
              }
            }
            let location = "";
            if (item.jobLocation && typeof item.jobLocation === "object") {
              const addr = item.jobLocation.address || item.jobLocation;
              if (typeof addr === "object") {
                location = addr.addressLocality || addr.addressRegion || "";
              } else {
                location = String(addr);
              }
            }
            if (company || position) {
              return { company, position, salary, location, description, requirements: "" };
            }
          }
        }
      }
    } catch (_) { /* 静默 */ }
    return null;
  }

  /**
   * 已知的招聘网站名称，用于过滤从标题中误提取的职位名
   */
  const SITE_NAMES = ["BOSS直聘", "boss直聘", "智联招聘", "拉勾网", "拉勾", "前程无忧", "猎聘", "牛客网", "LinkedIn", "Indeed"];

  /**
   * 判断提取到的文本是否是网站名称而非真实职位名
   * @param {string} text
   * @returns {boolean}
   */
  function isSiteName(text) {
    if (!text) return true;
    const trimmed = text.trim();
    return SITE_NAMES.some((name) => trimmed === name || trimmed === name.toLowerCase());
  }

  /**
   * 递归搜索 JSON 对象中包含岗位信息的节点
   * 查找包含 jobName/positionName + brandName/companyName 等常见字段的对象
   * @param {any} obj
   * @param {number} depth - 递归深度限制
   * @returns {{ company:string, position:string, salary:string, location:string, description:string, requirements:string }|null}
   */
  function findJobDataInJson(obj, depth) {
    if (!obj || typeof obj !== "object" || depth > 8) return null;

    // 检查当前对象是否包含岗位字段
    const positionKeys = ["jobName", "positionName", "jobTitle", "title", "position"];
    const companyKeys = ["brandName", "companyName", "brand", "company", "hireBrand", "employerName"];
    const salaryKeys = ["salaryDesc", "salary", "salaryStr", "pay"];
    const locationKeys = ["cityName", "city", "locationName", "location", "jobLocation"];
    const descKeys = ["jobDesc", "jobDescription", "description", "content", "postDescription"];
    const expKeys = ["jobExperience", "experience", "jobDegree", "degree"];

    function pickKey(obj, keys) {
      for (const k of keys) {
        if (obj[k] != null && String(obj[k]).trim()) return String(obj[k]).trim();
      }
      return "";
    }

    const position = pickKey(obj, positionKeys);
    const company = pickKey(obj, companyKeys);

    // 如果同时有职位和公司信息，认为找到了岗位数据
    if (position && company && !isSiteName(position)) {
      return {
        company,
        position,
        salary: pickKey(obj, salaryKeys),
        location: pickKey(obj, locationKeys),
        description: cleanText(pickKey(obj, descKeys)),
        requirements: pickKey(obj, expKeys),
      };
    }

    // 递归搜索子对象
    if (Array.isArray(obj)) {
      for (const item of obj) {
        const result = findJobDataInJson(item, depth + 1);
        if (result) return result;
      }
    } else {
      for (const key of Object.keys(obj)) {
        const val = obj[key];
        if (val && typeof val === "object") {
          const result = findJobDataInJson(val, depth + 1);
          if (result) return result;
        }
      }
    }
    return null;
  }

  /**
   * 从页面内嵌的 SSR 数据中提取岗位信息
   * 尝试 __NEXT_DATA__、window.__INITIAL_STATE__、script[type="application/json"] 等
   * @returns {{ company:string, position:string, salary:string, location:string, description:string, requirements:string }|null}
   */
  function extractFromSSRData() {
    try {
      // 1. __NEXT_DATA__（Next.js 站点）
      const nextDataScript = document.getElementById("__NEXT_DATA__");
      if (nextDataScript) {
        const text = nextDataScript.textContent || "";
        if (text) {
          try {
            const data = JSON.parse(text);
            const result = findJobDataInJson(data, 0);
            if (result) return result;
          } catch (_) { /* 解析失败，继续尝试 */ }
        }
      }

      // 2. 查找所有 <script type="application/json"> 标签
      const jsonScripts = document.querySelectorAll('script[type="application/json"]');
      for (const script of jsonScripts) {
        const text = script.textContent || "";
        if (!text || text.length < 20) continue;
        try {
          const data = JSON.parse(text);
          const result = findJobDataInJson(data, 0);
          if (result) return result;
        } catch (_) { /* 继续 */ }
      }

      // 3. 查找包含 __INITIAL_STATE__ 或 __STORE__ 的内联脚本
      const inlineScripts = document.querySelectorAll("script:not([src])");
      for (const script of inlineScripts) {
        const text = script.textContent || "";
        if (!text || !text.includes("brandName") && !text.includes("jobName") && !text.includes("companyName")) continue;
        // 尝试提取 JSON 片段
        const patterns = [
          /window\.__INITIAL_STATE__\s*=\s*(\{[\s\S]*?\});/,
          /window\.__STORE__\s*=\s*(\{[\s\S]*?\});/,
          /"jobInfo"\s*:\s*(\{[\s\S]*?\})\s*[,}]/,
        ];
        for (const pattern of patterns) {
          const match = text.match(pattern);
          if (match) {
            try {
              const data = JSON.parse(match[1]);
              const result = findJobDataInJson(data, 0);
              if (result) return result;
            } catch (_) { /* 继续 */ }
          }
        }
      }
    } catch (_) { /* 静默 */ }
    return null;
  }

  /**
   * 从 meta 标签提取信息（Open Graph 等）
   * @returns {{ position:string, description:string }|null}
   */
  function extractFromMeta() {
    const ogTitle = getText('meta[property="og:title"]', "content");
    const ogDesc = getText('meta[property="og:description"]', "content");
    const descMeta = getText('meta[name="description"]', "content");
    if (ogTitle || ogDesc || descMeta) {
      return {
        position: ogTitle || "",
        description: cleanText(ogDesc || descMeta || ""),
      };
    }
    return null;
  }

  // ============================================================
  // 各站点专属抓取函数
  // ============================================================

  /**
   * Boss 直聘抓取
   * 详情页：job-card / job-detail 结构
   * 兼容新旧版页面结构
   * 数据源优先级：SSR数据 > JSON-LD > CSS选择器 > 标题解析
   */
  function extractBoss() {
    // 1. 先尝试 SSR 数据（最可靠，直接从页面嵌入的 JSON 中提取）
    const ssrData = extractFromSSRData();

    // 2. 再尝试 JSON-LD 结构化数据
    const jsonLd = extractFromJsonLd();

    // 公司名称 - 兼容多版本页面结构
    const company =
      getTextFromAny([
        ".company-info .company-name",
        ".job-banner .company-info span",
        ".sider-company .name",
        "[data-type='company']",
        ".company-name a",
        ".info-company .name",
        ".job-detail .company-info .name",
        ".job-detail-company .name",
        ".company-section .name",
        "[class*='companyName']",
        "[class*='company-name']",
        ".job-side .company .name",
        // 更多可能的选择器
        ".company-card .name",
        ".boss-card .name",
        ".job-detail .company .name",
        ".job-sec .company-name",
      ]) ||
      ssrData?.company ||
      jsonLd?.company ||
      // 从页面标题中提取公司名（Boss 直聘标题格式：职位名-公司名-BOSS直聘）
      (() => {
        const titleParts = document.title.split(/[-_|·]/);
        if (titleParts.length >= 3) {
          const candidate = titleParts[1]?.trim();
          if (candidate && !isSiteName(candidate)) return candidate;
        }
        return "";
      })() ||
      "";

    // 职位名称
    let position =
      getTextFromAny([
        ".job-banner .name h1",
        ".job-banner .name .job-title",
        ".info-primary .name",
        ".job-title-text",
        ".job-name",
        "h1.name",
        ".job-detail .name h1",
        ".job-detail .job-title",
        "[class*='jobTitle']",
        "[class*='positionName']",
        ".job-sec .name",
        // 更多可能的选择器
        ".job-banner h1",
        ".name .job-name",
        ".job-detail .name",
        "h1.job-title",
      ]) ||
      ssrData?.position ||
      jsonLd?.position ||
      "";

    // 如果 CSS/SSR 都没找到，从标题提取（但不能是网站名）
    if (!position || isSiteName(position)) {
      const titlePart = document.title.split(/[-_|·]/)[0]?.trim();
      if (titlePart && !isSiteName(titlePart)) {
        position = titlePart;
      } else {
        position = "";
      }
    }

    // 薪资
    const salary =
      getTextFromAny([
        ".job-banner .salary",
        ".info-primary .salary",
        ".job-detail .salary",
        ".salary-text",
        ".job-detail .salary-text",
        "[class*='salary']",
        ".job-sec .salary",
        ".job-banner .salary-text",
        ".info-primary .salary-text",
      ]) ||
      ssrData?.salary ||
      jsonLd?.salary ||
      "";

    // 地点与经验要求
    const metaText = getTextFromAny([
      ".job-banner .info",
      ".info-primary p",
      ".job-detail .info-text",
      ".job-sec .job-requirements",
      ".job-detail .job-info",
      ".job-detail .info-primary",
      "[class*='jobInfo']",
      "[class*='jobTags']",
      ".job-banner .job-info",
      ".job-detail .job-tags",
    ]);

    const location =
      metaText.split(/[·|]/)[0]?.trim() ||
      ssrData?.location ||
      jsonLd?.location ||
      "";

    const experience = metaText || ssrData?.requirements || "";

    // 职位描述
    const description = cleanText(
      getTextFromAny([
        ".job-sec-text",
        ".job-detail-section .job-sec-text",
        ".text.fold-text",
        ".job-detail .content",
        ".job-description",
        ".job-detail .job-sec-text",
        ".job-detail-section .text",
        "[class*='jobDescribe']",
        "[class*='jobDesc']",
        "[class*='jobContent']",
        ".job-sec .text",
        ".job-detail .job-detail-content",
      ])
    ) || ssrData?.description || jsonLd?.description || "";

    return {
      company: company || "",
      position: position || "",
      salary: salary || "",
      location: location || "",
      description: description || "",
      requirements: experience || "",
    };
  }

  /**
   * 智联招聘抓取
   */
  function extractZhilian() {
    const company =
      getTextFromAny([
        ".iteminfo__companyName a",
        ".company__name",
        ".top-company__name",
        ".company-name a",
        "[class*='companyName'] a",
      ]) || "";

    const position =
      getTextFromAny([
        ".job-info h1",
        ".top-job__title",
        ".iteminfo__line2__jobname a",
        ".job-name",
        "h1[class*='title']",
      ]) || document.title.split("-")[0]?.trim() || "";

    const salary =
      getTextFromAny([
        ".job-info .salary",
        ".top-job__salary",
        ".iteminfo__line2__jobmoney",
        ".salary",
        "[class*='salary']",
      ]) || "";

    const metaText = getTextFromAny([
      ".job-info .summary",
      ".iteminfo__line2__jobdesc",
      ".top-job__summary",
    ]);
    const location = metaText.split(/\s+/)[0] || "";
    const experience = metaText || "";

    const description = cleanText(
      getTextFromAny([
        ".describtion",
        ".job-detail__content",
        ".jobinfo__content",
        ".job-description",
        "[class*='jobDetail'] [class*='content']",
      ])
    );

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements: experience,
    };
  }

  /**
   * 牛客网抓取
   */
  function extractNowcoder() {
    const company =
      getTextFromAny([
        ".company-name",
        ".job-company .name",
        ".nowcoder-job-company",
        "[class*='companyName']",
      ]) || "";

    const position =
      getTextFromAny([
        ".job-title",
        ".job-header h1",
        ".nowcoder-job-title",
        "h1[class*='title']",
      ]) || document.title.split("-")[0]?.trim() || "";

    const salary =
      getTextFromAny([
        ".job-salary",
        ".salary-text",
        "[class*='salary']",
      ]) || "";

    const metaText = getTextFromAny([
      ".job-info",
      ".job-meta",
      ".job-header .sub-info",
    ]);
    const location = metaText.split(/\s+/)[0] || "";
    const experience = metaText || "";

    const description = cleanText(
      getTextFromAny([
        ".job-description",
        ".job-detail-content",
        ".job-content",
        "[class*='jobDetail']",
      ])
    );

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements: experience,
    };
  }

  /**
   * 拉勾网抓取
   */
  function extractLagou() {
    const company =
      getTextFromAny([
        ".company-name a",
        ".job_company_name",
        ".item-detail .company",
        "[class*='companyName']",
      ]) || "";

    const position =
      getTextFromAny([
        ".job-name",
        ".position-head .name",
        ".item-info .name",
        "h1[class*='positionName']",
      ]) || document.title.split("-")[0]?.trim() || "";

    const salary =
      getTextFromAny([
        ".job-salary",
        ".salary",
        ".position-head .salary",
        "[class*='salary']",
      ]) || "";

    const metaText = getTextFromAny([
      ".job-request",
      ".position-head .position-labels",
      ".item-info .labels",
    ]);
    const location = metaText.split(/\s+/)[0] || "";
    const experience = metaText || "";

    const description = cleanText(
      getTextFromAny([
        ".job-detail",
        ".job_bt",
        ".position-content",
        ".job_description",
        "[class*='jobDetail']",
      ])
    );

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements: experience,
    };
  }

  /**
   * 前程无忧 (51job) 抓取
   */
  function extract51job() {
    const company =
      getTextFromAny([
        ".com-name",
        ".company_name a",
        ".tCompany_top .cn a",
        "[class*='companyName']",
      ]) || "";

    const position =
      getTextFromAny([
        ".job_title",
        ".tH h1",
        ".cn h1",
        ".position-name",
      ]) || document.title.split("-")[0]?.trim() || "";

    const salary =
      getTextFromAny([
        ".job_salary",
        ".cn strong",
        ".salary",
        "[class*='salary']",
      ]) || "";

    const metaText = getTextFromAny([
      ".job_tags",
      ".cn .msg",
      ".tCompany_top .info",
    ]);
    const location = metaText.split(/\s|·|｜/)[0] || "";
    const experience = metaText || "";

    const description = cleanText(
      getTextFromAny([
        ".job_detail",
        ".tCompany_main .job_msg",
        ".job-content",
        ".job_description",
        "[class*='jobDetail']",
      ])
    );

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements: experience,
    };
  }

  /**
   * 猎聘抓取
   */
  function extractLiepin() {
    const company =
      getTextFromAny([
        ".company-name",
        ".job-company-info .name",
        ".company-info .name",
        "[class*='companyName']",
      ]) || "";

    const position =
      getTextFromAny([
        ".job-title",
        ".job-info h1",
        ".header-title",
        "h1[class*='title']",
      ]) || document.title.split("-")[0]?.trim() || "";

    const salary =
      getTextFromAny([
        ".job-salary",
        ".salary-text",
        "[class*='salary']",
      ]) || "";

    const metaText = getTextFromAny([
      ".job-conditions",
      ".job-info .labels",
      ".job-meta",
    ]);
    const location = metaText.split(/\s+/)[0] || "";
    const experience = metaText || "";

    const description = cleanText(
      getTextFromAny([
        ".job-description",
        ".job-detail-content",
        ".content-inner",
        "[class*='jobDetail']",
      ])
    );

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements: experience,
    };
  }

  /**
   * 通用抓取策略
   * 利用 SSR 数据、meta 标签和常见 CSS 选择器尽可能提取信息
   */
  function extractGeneric() {
    // 先尝试 SSR 数据
    const ssrData = extractFromSSRData();
    const jsonLd = extractFromJsonLd();

    // 尝试从 meta 标签获取标题
    const ogTitle = getText('meta[property="og:title"]', "content");
    const ogDescription = getText(
      'meta[property="og:description"]',
      "content"
    );
    const descriptionMeta = getText('meta[name="description"]', "content");

    // 通用公司名选择器
    const company =
      getTextFromAny([
        '[class*="company"][class*="name"]',
        '[class*="companyName"]',
        '[data-company]',
        ".company-name",
        ".company a",
      ]) ||
      getText('[data-company]', "data-company") ||
      ssrData?.company ||
      jsonLd?.company ||
      "";

    // 通用职位选择器
    let position =
      getTextFromAny([
        'h1[class*="job"]',
        'h1[class*="position"]',
        'h1[class*="title"]',
        ".job-title",
        ".position-name",
        "h1",
      ]) ||
      ssrData?.position ||
      jsonLd?.position ||
      "";

    // 过滤网站名称，避免将 "BOSS直聘" 等误识别为职位
    if (!position || isSiteName(position)) {
      const titlePart = ogTitle || document.title.split(/[-_|·]/)[0]?.trim() || "";
      position = isSiteName(titlePart) ? "" : titlePart;
    }

    // 通用薪资选择器
    const salary =
      getTextFromAny([
        '[class*="salary"]',
        '[class*="money"]',
        '[data-salary]',
        ".salary",
      ]) ||
      getText('[data-salary]', "data-salary") ||
      ssrData?.salary ||
      jsonLd?.salary ||
      "";

    // 通用地点选择器
    const location =
      getTextFromAny([
        '[class*="location"]',
        '[class*="city"]',
        '[class*="area"]',
        ".job-location",
        ".location",
      ]) ||
      ssrData?.location ||
      jsonLd?.location ||
      "";

    // 通用描述选择器
    const description = cleanText(
      getTextFromAny([
        '[class*="job-detail"]',
        '[class*="job-desc"]',
        '[class*="job-content"]',
        '[class*="position-desc"]',
        '[class*="description"]',
        ".job-description",
      ]) ||
        ssrData?.description ||
        jsonLd?.description ||
        ogDescription ||
        descriptionMeta
    );

    // 通用要求选择器
    const requirements =
      getTextFromAny([
        '[class*="requirement"]',
        '[class*="qualification"]',
        '[class*="tag"]',
        ".job-tags",
      ]) ||
      ssrData?.requirements ||
      "";

    return {
      company,
      position,
      salary,
      location,
      description,
      requirements,
    };
  }

  // ============================================================
  // 主抓取入口
  // ============================================================

  /**
   * 抓取当前页面的岗位信息（对外暴露的全局函数）
   * @returns {{ company:string, position:string, salary:string, location:string, description:string, requirements:string, source:string, url:string }}
   */
  function extractJobInfo() {
    const source = detectSource();
    let info;

    try {
      switch (source) {
        case "boss":
          info = extractBoss();
          break;
        case "zhilian":
          info = extractZhilian();
          break;
        case "nowcoder":
          info = extractNowcoder();
          break;
        case "lagou":
          info = extractLagou();
          break;
        case "51job":
          info = extract51job();
          break;
        case "liepin":
          info = extractLiepin();
          break;
        default:
          info = extractGeneric();
      }
    } catch (e) {
      // 抓取异常时回退到通用策略
      console.warn("[OfferMate] 专属抓取失败，回退到通用策略:", e);
      info = extractGeneric();
    }

    // 如果专属抓取结果过少，补充通用策略
    const hasCoreInfo = info.company || info.position || info.description;
    if (!hasCoreInfo) {
      console.warn("[OfferMate] 专属抓取信息不足，补充通用策略");
      const generic = extractGeneric();
      info = {
        company: info.company || generic.company,
        position: info.position || generic.position,
        salary: info.salary || generic.salary,
        location: info.location || generic.location,
        description: info.description || generic.description,
        requirements: info.requirements || generic.requirements,
      };
    }

    return {
      company: info.company || "",
      position: info.position || "",
      salary: info.salary || "",
      location: info.location || "",
      description: info.description || "",
      requirements: info.requirements || "",
      source,
      url: location.href,
      timestamp: Date.now(),
    };
  }

  // 暴露到 window 供 popup / 调试使用
  window.extractJobInfo = extractJobInfo;

  // ============================================================
  // 批量列表页抓取（搜索结果页 / 列表页）
  // ============================================================

  /**
   * 在指定根元素内安全获取文本，找不到时返回空字符串
   * @param {Element} root - 根元素（卡片）
   * @param {string} selector - CSS 选择器
   * @param {string} [attr] - 可选，取属性值而非文本
   * @returns {string}
   */
  function getTextIn(root, selector, attr) {
    try {
      if (!root) return "";
      const el = root.querySelector(selector);
      if (!el) return "";
      if (attr) {
        return (el.getAttribute(attr) || "").trim();
      }
      return (el.innerText || el.textContent || "").trim();
    } catch (e) {
      return "";
    }
  }

  /**
   * 在指定根元素内尝试多个选择器，返回第一个命中的文本
   * @param {Element} root
   * @param {string[]} selectors
   * @returns {string}
   */
  function getTextFromAnyIn(root, selectors) {
    for (const sel of selectors) {
      const text = getTextIn(root, sel);
      if (text) return text;
    }
    return "";
  }

  /**
   * 从卡片元素中提取链接 href，处理相对路径
   * @param {Element} card
   * @returns {string}
   */
  function getCardUrl(card) {
    try {
      const link =
        card.querySelector("a[href]") || card.closest("a[href]");
      if (!link) return "";
      const href = link.getAttribute("href") || "";
      if (!href) return "";
      try {
        return new URL(href, location.href).href;
      } catch (_) {
        return href;
      }
    } catch (e) {
      return "";
    }
  }

  /**
   * 判断文本是否包含"远程"相关字样
   * @param {string} text
   * @returns {boolean}
   */
  function detectRemote(text) {
    if (!text) return false;
    return /远程|居家|在家|remote/i.test(text);
  }

  /**
   * Boss 直聘列表页批量抓取
   * 卡片：.job-card-wrapper 或 .search-job-result .job-card-body
   * @returns {Array}
   */
  function extractBossBatch() {
    const cards = Array.from(
      document.querySelectorAll(
        ".job-card-wrapper, .search-job-result .job-card-body"
      )
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".company-info .company-name",
            ".company-name a",
            ".company-name",
            ".info-company .name",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".job-name",
            ".job-title",
            ".job-card-name",
            ".primary-box .job-name a",
            ".job-title-text",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [".salary", ".red", ".job-salary"])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".job-area",
            ".job-info .job-area",
            ".info-primary p",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [".job-info", ".tag-list", ".info-desc"])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".job-time", ".time", ".publish-time"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "boss",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 智联招聘列表页批量抓取
   * 卡片：.joblist-box .joblist 或 .positionlist .joblist
   * @returns {Array}
   */
  function extractZhilianBatch() {
    const cards = Array.from(
      document.querySelectorAll(
        ".joblist-box .joblist, .positionlist .joblist"
      )
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".iteminfo__companyName a",
            ".company__name",
            ".company-name a",
            "[class*='companyName'] a",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".iteminfo__line2__jobname a",
            ".jobinfo__name",
            ".job-name",
            "[class*='jobname'] a",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            ".iteminfo__line2__jobmoney",
            ".jobinfo__salary",
            ".salary",
            "[class*='salary']",
          ])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".iteminfo__line2__jobdesc",
            ".jobinfo__area",
            "[class*='city']",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [
            ".iteminfo__line2__jobdesc",
            ".jobinfo__welfare",
            ".job-tags",
          ])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".time", ".date", ".update"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "zhilian",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 牛客网列表页批量抓取
   * 卡片：.job-item 或 .recruit-list .job-card
   * @returns {Array}
   */
  function extractNowcoderBatch() {
    const cards = Array.from(
      document.querySelectorAll(".job-item, .recruit-list .job-card")
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".company-name",
            ".job-company .name",
            "[class*='companyName']",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".job-title",
            ".job-name",
            ".nowcoder-job-title",
            "[class*='jobName']",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            ".job-salary",
            ".salary-text",
            "[class*='salary']",
          ])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".job-info",
            ".job-meta",
            ".job-area",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [".job-info", ".job-tags", ".labels"])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".time", ".date", ".publish-time"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "nowcoder",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 拉勾列表页批量抓取
   * 卡片：.item__10RTO 或 .position-list .item
   * @returns {Array}
   */
  function extractLagouBatch() {
    const cards = Array.from(
      document.querySelectorAll(".item__10RTO, .position-list .item")
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".company-name a",
            ".company__name",
            "[class*='companyName']",
            ".company_name",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".position-name",
            ".name",
            ".job-name",
            "[class*='positionName']",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            ".salary",
            ".money",
            ".position-list-item .salary",
            "[class*='salary']",
          ])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".position-info",
            ".city",
            ".work-city",
            "[class*='city']",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [
            ".position-labels",
            ".labels",
            ".pli__middle",
          ])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".format-time", ".time", ".date"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "lagou",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 51job 列表页批量抓取
   * 卡片：.j_joblist .e 或 .el .jobname
   * @returns {Array}
   */
  function extract51jobBatch() {
    const cards = Array.from(
      document.querySelectorAll(".j_joblist .e, .el .jobname")
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".cname a",
            ".company_name a",
            ".com-name",
            "[class*='companyName']",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".jname",
            ".jobname a",
            ".el .jobname",
            "[class*='jobName']",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            ".sal",
            ".salary",
            ".money",
            "[class*='salary']",
          ])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".info .name",
            ".job-area",
            ".area",
            "[class*='area']",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [".tags", ".info", ".d.at"])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".time", ".date", ".update"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "51job",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 猎聘列表页批量抓取
   * 卡片：.job-card 或 .job-list .job-item
   * @returns {Array}
   */
  function extractLiepinBatch() {
    const cards = Array.from(
      document.querySelectorAll(".job-card, .job-list .job-item")
    );
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            ".company-name",
            ".job-company-info .name",
            "[class*='companyName']",
            ".ellipsis-1",
          ])
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            ".job-title",
            ".job-info h3",
            "[class*='jobTitle']",
            ".ellipsis-1",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            ".job-salary",
            ".salary",
            "[class*='salary']",
          ])
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            ".job-area",
            ".area",
            ".dqs",
            "[class*='city']",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [
            ".job-conditions",
            ".labels",
            ".job-tags",
          ])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [".time", ".date", ".update"])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: "liepin",
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 通用列表页批量抓取（回退策略）
   * 卡片：[class*="job-card"]、[class*="job-item"]、[class*="position-item"]
   * @returns {Array}
   */
  function extractGenericBatch() {
    const cardSet = new Set();
    const selectors = [
      '[class*="job-card"]',
      '[class*="job-item"]',
      '[class*="position-item"]',
    ];
    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach((el) => cardSet.add(el));
    }
    const cards = Array.from(cardSet);
    return cards
      .map((card) => {
        const company = cleanText(
          getTextFromAnyIn(card, [
            '[class*="company"][class*="name"]',
            '[class*="companyName"]',
            "[data-company]",
            ".company-name",
            ".company a",
          ]) ||
            getTextIn(card, "[data-company]", "data-company")
        );
        const position = cleanText(
          getTextFromAnyIn(card, [
            'a[class*="job"]',
            'a[class*="position"]',
            'a[class*="title"]',
            ".job-title",
            ".position-name",
            "h3",
            "h4",
          ])
        );
        const salary = cleanText(
          getTextFromAnyIn(card, [
            '[class*="salary"]',
            '[class*="money"]',
            "[data-salary]",
            ".salary",
          ]) ||
            getTextIn(card, "[data-salary]", "data-salary")
        );
        const location = cleanText(
          getTextFromAnyIn(card, [
            '[class*="location"]',
            '[class*="city"]',
            '[class*="area"]',
            ".job-location",
            ".location",
          ])
        );
        if (!company && !position) return null;
        const url = getCardUrl(card);
        const metaText = cleanText(
          getTextFromAnyIn(card, [
            '[class*="tag"]',
            '[class*="label"]',
            ".job-tags",
          ])
        );
        const posted = cleanText(
          getTextFromAnyIn(card, [
            '[class*="time"]',
            '[class*="date"]',
            ".time",
          ])
        );
        return {
          company,
          position,
          salary,
          location,
          description: "",
          requirements: metaText,
          source: detectSource(),
          url,
          posted_at: posted,
          is_remote: detectRemote(
            `${position} ${location} ${metaText}`
          ),
        };
      })
      .filter(Boolean);
  }

  /**
   * 批量抓取当前列表页的所有岗位卡片（对外暴露的全局函数）
   * 自动检测来源平台并调用对应批量抓取函数。
   * 若当前页非列表页（未发现卡片），返回空数组。
   * @returns {Array<{company:string, position:string, salary:string, location:string, description:string, requirements:string, source:string, url:string, posted_at:string, is_remote:boolean}>}
   */
  function extractBatchJobs() {
    const source = detectSource();
    let jobs = [];

    try {
      switch (source) {
        case "boss":
          jobs = extractBossBatch();
          break;
        case "zhilian":
          jobs = extractZhilianBatch();
          break;
        case "nowcoder":
          jobs = extractNowcoderBatch();
          break;
        case "lagou":
          jobs = extractLagouBatch();
          break;
        case "51job":
          jobs = extract51jobBatch();
          break;
        case "liepin":
          jobs = extractLiepinBatch();
          break;
        default:
          jobs = extractGenericBatch();
      }
    } catch (e) {
      console.warn("[OfferMate] 批量抓取失败，回退到通用策略:", e);
      jobs = [];
    }

    // 专属抓取无结果时，尝试通用回退
    if ((!jobs || jobs.length === 0) && source !== "unknown") {
      try {
        const generic = extractGenericBatch();
        if (generic && generic.length > 0) jobs = generic;
      } catch (_) {
        // 忽略回退失败
      }
    }

    return jobs || [];
  }

  // 暴露到 window 供 popup / background / 调试使用
  window.extractBatchJobs = extractBatchJobs;

  // ============================================================
  // 消息监听 - 响应来自 popup / background 的抓取请求
  // ============================================================
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.type === "OFFERMATE_EXTRACT") {
      try {
        const jobInfo = extractJobInfo();
        sendResponse({ success: true, data: jobInfo });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
      return true; // 保持消息通道开启以支持异步响应
    }

    if (message && message.type === "OFFERMATE_EXTRACT_BATCH") {
      try {
        const jobs = extractBatchJobs();
        sendResponse({ success: true, data: jobs });
      } catch (e) {
        sendResponse({ success: false, error: e.message, data: [] });
      }
      return true;
    }

    if (message && message.type === "OFFERMATE_PING") {
      sendResponse({ success: true, pong: true, source: detectSource() });
      return true;
    }
  });

  // 页面加载完成后自动抓取一次并发送给 background（静默，不弹窗）
  // 仅当能抓到核心信息时才发送，避免噪音
  try {
    const jobInfo = extractJobInfo();
    if (jobInfo.company || jobInfo.position) {
      chrome.runtime.sendMessage({
        type: "OFFERMATE_JOB_DETECTED",
        data: jobInfo,
      });
    }
  } catch (e) {
    // 静默失败
    console.debug("[OfferMate] 自动检测岗位失败:", e);
  }

  console.log("[OfferMate] 内容脚本已加载，来源:", detectSource());
})();
